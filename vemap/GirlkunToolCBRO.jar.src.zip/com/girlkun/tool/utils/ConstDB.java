package com.girlkun.tool.utils;

public class ConstDB {
  public static final String GIRLKUN = "GIRLKUN";
}


/* Location:              D:\nro\server_luxu_nrp\vemap\GirlkunToolCBRO.jar!\com\girlkun\too\\utils\ConstDB.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */