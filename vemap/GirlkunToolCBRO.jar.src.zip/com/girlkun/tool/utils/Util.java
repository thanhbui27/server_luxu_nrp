/*     */ package com.girlkun.tool.utils;
/*     */ 
/*     */ import com.girlkun.database.GirlkunDB;
/*     */ import com.girlkun.result.GirlkunResultSet;
/*     */ import java.awt.Color;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.ImageObserver;
/*     */ import java.awt.image.WritableRaster;
/*     */ import java.io.File;
/*     */ import java.util.Random;
/*     */ import javax.imageio.ImageIO;
/*     */ import org.json.simple.JSONArray;
/*     */ import org.json.simple.JSONValue;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Util
/*     */ {
/*  27 */   public static Random rd = new Random();
/*     */   
/*     */   public static int range(int from, int to) {
/*  30 */     return from + rd.nextInt(to - from + 1);
/*     */   }
/*     */   
/*     */   public static BufferedImage flipImageX(BufferedImage image) {
/*  34 */     BufferedImage newImage = new BufferedImage(image.getWidth(), image.getHeight(), 2);
/*  35 */     Graphics2D g = newImage.createGraphics();
/*  36 */     g.drawImage(image, image.getWidth(), 0, -image.getWidth(), image.getHeight(), null);
/*  37 */     return newImage;
/*     */   }
/*     */   
/*     */   public static BufferedImage changeRed(BufferedImage img) {
/*  41 */     BufferedImage i = new BufferedImage(img.getWidth(), img.getHeight(), 2);
/*  42 */     Graphics2D gi = (Graphics2D)i.getGraphics();
/*  43 */     gi.drawImage(img, 0, 0, (ImageObserver)null);
/*     */     
/*  45 */     WritableRaster raster = i.getRaster();
/*     */     
/*  47 */     for (int xx = 0; xx < i.getWidth(); xx++) {
/*  48 */       for (int yy = 0; yy < i.getHeight(); yy++) {
/*  49 */         int[] pixels = raster.getPixel(xx, yy, (int[])null);
/*  50 */         pixels[0] = 255;
/*  51 */         pixels[1] = 0;
/*  52 */         pixels[2] = 0;
/*  53 */         raster.setPixel(xx, yy, pixels);
/*     */       } 
/*     */     } 
/*  56 */     return i;
/*     */   }
/*     */   
/*     */   public static BufferedImage resizeImage(BufferedImage ori, int w, int h) {
/*  60 */     BufferedImage tThumbImage = new BufferedImage(w, h, 1);
/*  61 */     Graphics2D tGraphics2D = tThumbImage.createGraphics();
/*  62 */     tGraphics2D.setBackground(Color.WHITE);
/*  63 */     tGraphics2D.setPaint(Color.WHITE);
/*  64 */     tGraphics2D.fillRect(0, 0, w, h);
/*  65 */     tGraphics2D.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
/*  66 */     tGraphics2D.drawImage(ori, 0, 0, w, h, null);
/*  67 */     return tThumbImage;
/*     */   }
/*     */   
/*     */   public static boolean canDoLastTime(long lastTime, int timeDo) {
/*  71 */     return (System.currentTimeMillis() - lastTime >= timeDo);
/*     */   }
/*     */   
/*     */   public static BufferedImage getImageById(int id, int zoomSize) throws Exception {
/*  75 */     BufferedImage image = ImageIO.read(new File("data/girlkun/icon/x" + zoomSize + "/" + id + ".png"));
/*  76 */     return image;
/*     */   }
/*     */   
/*     */   public static BufferedImage getBgImageById(int id, int zoomSize) throws Exception {
/*  80 */     BufferedImage image = ImageIO.read(new File("data/girlkun/item_bg_temp/x" + zoomSize + "/" + id + ".png"));
/*  81 */     return image;
/*     */   }
/*     */   
/*     */   public static BufferedImage getImageMobById(int id, int f) throws Exception {
/*  85 */     BufferedImage image = ImageIO.read(new File("data/mob/" + id + "/" + id + "_" + f + ".png"));
/*  86 */     return image;
/*     */   }
/*     */   
/*     */   public static BufferedImage getImageEffectById(int id) throws Exception {
/*  90 */     BufferedImage image = ImageIO.read(new File("data/effect/" + id + "/" + Character.MIN_VALUE + ".png"));
/*  91 */     return image;
/*     */   }
/*     */   
/*     */   public static BufferedImage getImageByPath(String path) throws Exception {
/*  95 */     BufferedImage image = ImageIO.read(new File(path));
/*  96 */     return image;
/*     */   }
/*     */   
/*     */   public static BufferedImage getImageBEffectByType(int typeEff) throws Exception {
/* 100 */     BufferedImage img = null;
/* 101 */     if (typeEff == 1) {
/* 102 */       img = getImageByPath("data/bg/lacay.png");
/* 103 */     } else if (typeEff == 2) {
/* 104 */       img = getImageByPath("data/bg/lacay2.png");
/* 105 */     } else if (typeEff == 5) {
/* 106 */       img = getImageByPath("data/bg/lacay3.png");
/* 107 */     } else if (typeEff == 6) {
/* 108 */       img = getImageByPath("data/bg/lacay4.png");
/* 109 */     } else if (typeEff == 7) {
/* 110 */       img = getImageByPath("data/bg/lacay5.png");
/* 111 */     } else if (typeEff == 11) {
/* 112 */       img = getImageByPath("data/bg/tuyet.png");
/* 113 */     } else if (typeEff == 4) {
/* 114 */       img = getImageByPath("data/bg/sao.png");
/* 115 */     } else if (typeEff == 12) {
/* 116 */       img = getImageByPath("data/bg/mua1.png");
/*     */     } 
/* 118 */     return img;
/*     */   }
/*     */   
/*     */   public static void main(String[] args) {
/*     */     try {
/* 123 */       GirlkunResultSet rs = GirlkunDB.executeQuery("GIRLKUN", "select npcs from map_template");
/* 124 */       JSONValue jv = new JSONValue();
/* 125 */       while (rs.next()) {
/* 126 */         JSONArray dataArray = (JSONArray)JSONValue.parse(rs.getString("npcs").replaceAll("\\\"", ""));
/* 127 */         if (dataArray.size() != 0) {
/* 128 */           for (int i = 0; i < dataArray.size(); i++) {
/* 129 */             JSONArray npc = (JSONArray)JSONValue.parse(String.valueOf(dataArray.get(i)));
/* 130 */             int id = Integer.parseInt(String.valueOf(npc.get(0)));
/* 131 */             int avatar = Integer.parseInt(String.valueOf(npc.get(3)));
/* 132 */             GirlkunDB.executeUpdate("GIRLKUN", "update npc_template set avatar = ? where id = ?", new Object[] { Integer.valueOf(avatar), Integer.valueOf(id) });
/*     */           } 
/*     */         }
/*     */       } 
/* 136 */     } catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */   
/*     */   public static BufferedImage trimImage(BufferedImage image) {
/* 141 */     WritableRaster raster = image.getAlphaRaster();
/* 142 */     int width = raster.getWidth();
/* 143 */     int height = raster.getHeight();
/* 144 */     int left = 0;
/* 145 */     int top = 0;
/* 146 */     int right = width - 1;
/* 147 */     int bottom = height - 1;
/* 148 */     int minRight = width - 1;
/* 149 */     int minBottom = height - 1;
/*     */ 
/*     */     
/* 152 */     label53: for (; top <= bottom; top++) {
/* 153 */       for (int x = 0; x < width; x++) {
/* 154 */         if (raster.getSample(x, top, 0) != 0) {
/* 155 */           minRight = x;
/* 156 */           minBottom = top;
/*     */           
/*     */           break label53;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 163 */     label54: for (; left < minRight; left++) {
/* 164 */       for (int y = height - 1; y > top; y--) {
/* 165 */         if (raster.getSample(left, y, 0) != 0) {
/* 166 */           minBottom = y;
/*     */           
/*     */           break label54;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 173 */     label55: for (; bottom > minBottom; bottom--) {
/* 174 */       for (int x = width - 1; x >= left; x--) {
/* 175 */         if (raster.getSample(x, bottom, 0) != 0) {
/* 176 */           minRight = x;
/*     */           
/*     */           break label55;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 183 */     label52: for (; right > minRight; right--) {
/* 184 */       for (int y = bottom; y >= top; y--) {
/* 185 */         if (raster.getSample(right, y, 0) != 0) {
/*     */           break label52;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/*     */     try {
/* 192 */       return image.getSubimage(left, top, right - left + 1, bottom - top + 1);
/* 193 */     } catch (Exception e) {
/* 194 */       return image;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\nro\server_luxu_nrp\vemap\GirlkunToolCBRO.jar!\com\girlkun\too\\utils\Util.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */