/*     */ package com.girlkun.tool.main;
/*     */ 
/*     */ import com.girlkun.database.GirlkunDB;
/*     */ import com.girlkun.result.GirlkunResultSet;
/*     */ import com.girlkun.tool.entities.EffectTemplate;
/*     */ import com.girlkun.tool.entities.item.ItemOptionTemplate;
/*     */ import com.girlkun.tool.entities.item.ItemTemplate;
/*     */ import com.girlkun.tool.entities.map.BgItemTemplate;
/*     */ import com.girlkun.tool.entities.map.HeadAvatar;
/*     */ import com.girlkun.tool.entities.map.MapTemplate;
/*     */ import com.girlkun.tool.entities.map.MobTemplate;
/*     */ import com.girlkun.tool.entities.map.NpcTemplate;
/*     */ import com.girlkun.tool.entities.map.TilesetType;
/*     */ import com.girlkun.tool.utils.Logger;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.FileInputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.imageio.ImageIO;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JOptionPane;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Manager
/*     */ {
/*     */   private static Manager I;
/*     */   
/*     */   public static Manager gI() {
/*  37 */     if (I == null) {
/*  38 */       I = new Manager();
/*     */     }
/*  40 */     return I;
/*     */   }
/*     */   private List<ItemTemplate> itemTemplates; private List<ItemOptionTemplate> itemOptionTemplates; private List<NpcTemplate> npcTemplates; private List<HeadAvatar> headAvatars;
/*  43 */   private List<TilesetType> tile_set_type = new ArrayList<>(); private List<BgItemTemplate> bgItemTemplates; private List<MobTemplate> mobTemplates; private List<EffectTemplate> effectTemplates; private List<MapTemplate> mapTemplates; public List<TilesetType> getTile_set_type() { return this.tile_set_type; }
/*     */   
/*  45 */   public List<ItemTemplate> getItemTemplates() { return this.itemTemplates; }
/*  46 */   public List<ItemOptionTemplate> getItemOptionTemplates() { return this.itemOptionTemplates; }
/*  47 */   public List<NpcTemplate> getNpcTemplates() { return this.npcTemplates; }
/*  48 */   public List<HeadAvatar> getHeadAvatars() { return this.headAvatars; }
/*  49 */   public List<BgItemTemplate> getBgItemTemplates() { return this.bgItemTemplates; }
/*  50 */   public List<MobTemplate> getMobTemplates() { return this.mobTemplates; }
/*  51 */   public List<EffectTemplate> getEffectTemplates() { return this.effectTemplates; } public List<MapTemplate> getMapTemplates() {
/*  52 */     return this.mapTemplates;
/*     */   }
/*     */   private Manager() {
/*  55 */     (new Thread(() -> {
/*     */           load();
/*     */           Logger.warning("Load dữ liệu hoàn tất!\n");
/*  58 */         })).start();
/*     */   }
/*     */ 
/*     */   
/*     */   private void load() {
/*  63 */     loadMapTemplate();
/*  64 */     loadItemTemplate();
/*  65 */     loadItemOptionTemplate();
/*  66 */     loadNpcTemplate();
/*     */     
/*  68 */     loadHeadAvatar();
/*  69 */     loadBgItemTemplate();
/*  70 */     loadMobTemplate();
/*     */     
/*  72 */     loadTileType();
/*  73 */     loadEffectTemplate();
/*     */   }
/*     */   
/*     */   private void loadMapTemplate() {
/*  77 */     this.mapTemplates = new ArrayList<>();
/*     */     try {
/*  79 */       GirlkunResultSet rs = GirlkunDB.executeQuery("GIRLKUN", "select * from map_template");
/*  80 */       while (rs.next()) {
/*  81 */         this.mapTemplates.add(new MapTemplate(rs.getInt("id"), rs.getString("name")));
/*     */       }
/*  83 */       Logger.success("Load dữ liệu map template thành công (" + this.mapTemplates.size() + ")\n");
/*  84 */     } catch (Exception e) {
/*  85 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void loadEffectTemplate() {
/*  90 */     this.effectTemplates = new ArrayList<>();
/*     */     try {
/*  92 */       for (int i = 0; i < 750; i++) {
/*  93 */         EffectTemplate eff = readEff(i);
/*  94 */         if (eff != null && eff.getSizeFrame() > 0) {
/*  95 */           this.effectTemplates.add(eff);
/*     */         }
/*     */       } 
/*  98 */       Logger.success("Load dữ liệu effect template thành công (" + this.effectTemplates.size() + ")\n");
/*  99 */     } catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */   
/*     */   public EffectTemplate readEff(int id) {
/* 104 */     EffectTemplate eff = null;
/*     */     try {
/* 106 */       DataInputStream dis = new DataInputStream(new FileInputStream("data/girlkun/effdata/x1/" + id));
/* 107 */       dis.readShort();
/* 108 */       byte[] data = new byte[dis.readInt()];
/* 109 */       dis.read(data);
/* 110 */       byte[] dataImage = new byte[dis.readInt()];
/* 111 */       dis.read(dataImage);
/* 112 */       ByteArrayInputStream bis = new ByteArrayInputStream(dataImage);
/* 113 */       BufferedImage oriImage = ImageIO.read(bis);
/* 114 */       eff = new EffectTemplate();
/* 115 */       eff.setId(id);
/* 116 */       eff.setImageOri(oriImage);
/* 117 */       readDataEffect(data, 1, oriImage, eff, id);
/* 118 */     } catch (Exception exception) {}
/*     */ 
/*     */     
/* 121 */     return eff;
/*     */   }
/*     */   
/*     */   private void readDataEffect(byte[] data, int zoom, BufferedImage oriImage, EffectTemplate eff, int idEff) {
/*     */     try {
/* 126 */       ByteArrayInputStream bis = new ByteArrayInputStream(data);
/* 127 */       DataInputStream dis = new DataInputStream(bis);
/*     */       
/* 129 */       int nImageInfo = dis.readByte();
/* 130 */       BufferedImage[] imageInfo = new BufferedImage[nImageInfo];
/* 131 */       eff.setAxisSubImage(new int[nImageInfo][]);
/* 132 */       for (int i = 0; i < nImageInfo; i++) {
/* 133 */         eff.getAxisSubImage()[i] = new int[5];
/* 134 */         int id = dis.readByte();
/* 135 */         int x = dis.readUnsignedByte();
/* 136 */         int y = dis.readUnsignedByte();
/* 137 */         int w = dis.readUnsignedByte();
/* 138 */         int h = dis.readUnsignedByte();
/*     */         try {
/* 140 */           if (y + h > oriImage.getHeight()) {
/* 141 */             h = oriImage.getHeight() - y;
/*     */           }
/* 143 */           if (x + w > oriImage.getWidth()) {
/* 144 */             w = oriImage.getWidth() - x;
/*     */           }
/* 146 */           x = Math.abs(x);
/* 147 */           y = Math.abs(y);
/* 148 */           h = Math.abs(h);
/* 149 */           w = Math.abs(w);
/*     */           
/* 151 */           eff.getAxisSubImage()[i][0] = id;
/* 152 */           eff.getAxisSubImage()[i][1] = x;
/* 153 */           eff.getAxisSubImage()[i][2] = y;
/* 154 */           eff.getAxisSubImage()[i][3] = w;
/* 155 */           eff.getAxisSubImage()[i][4] = h;
/* 156 */         } catch (Exception e) {
/* 157 */           e.printStackTrace();
/* 158 */           System.out.println(oriImage.getWidth() + " : " + x + " : " + w + " -");
/* 159 */           JOptionPane.showMessageDialog(Main.I, null, null, 1, new ImageIcon(oriImage));
/*     */         } 
/*     */       } 
/*     */       
/* 163 */       int nFrame = dis.readShort();
/* 164 */       eff.setAxisFrame(new int[nFrame][][]);
/*     */       
/* 166 */       for (int j = 0; j < nFrame; j++) {
/*     */ 
/*     */         
/* 169 */         int nF = dis.readByte();
/* 170 */         eff.getAxisFrame()[j] = new int[nF][];
/* 171 */         for (int m = 0; m < nF; m++) {
/* 172 */           eff.getAxisFrame()[j][m] = new int[3];
/* 173 */           int dx = dis.readShort() * zoom;
/* 174 */           int dy = dis.readShort() * zoom;
/* 175 */           int idImage = dis.readByte();
/* 176 */           eff.getAxisFrame()[j][m][0] = dx;
/* 177 */           eff.getAxisFrame()[j][m][1] = dy;
/* 178 */           eff.getAxisFrame()[j][m][2] = idImage;
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 188 */       int arrF = dis.readShort();
/* 189 */       for (int k = 0; k < arrF; k++);
/*     */ 
/*     */     
/*     */     }
/* 193 */     catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void loadItemTemplate() {
/* 200 */     this.itemTemplates = new ArrayList<>();
/*     */     try {
/* 202 */       GirlkunResultSet rs = GirlkunDB.executeQuery("GIRLKUN", "select * from item_template");
/* 203 */       while (rs.next()) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 215 */         ItemTemplate itemTemplate = new ItemTemplate(rs.getInt("id"), rs.getInt("type"), rs.getInt("gender"), rs.getString("name"), rs.getString("description"), rs.getInt("icon_id"), rs.getInt("part"), rs.getBoolean("is_up_to_up"), rs.getInt("power_require"), rs.getInt("gold"), rs.getInt("gem"));
/* 216 */         this.itemTemplates.add(itemTemplate);
/*     */       } 
/* 218 */       Logger.success("Load dữ liệu item template thành công (" + this.itemTemplates.size() + ")\n");
/* 219 */     } catch (Exception e) {
/* 220 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void loadItemOptionTemplate() {
/* 225 */     this.itemOptionTemplates = new ArrayList<>();
/*     */     
/*     */     try {
/* 228 */       GirlkunResultSet rs = GirlkunDB.executeQuery("GIRLKUN", "select * from item_option_template");
/* 229 */       while (rs.next()) {
/* 230 */         ItemOptionTemplate itemOptionTemplate = new ItemOptionTemplate(rs.getInt("id"), rs.getString("name"));
/* 231 */         this.itemOptionTemplates.add(itemOptionTemplate);
/*     */       } 
/* 233 */       Logger.success("Load dữ liệu item option template thành công (" + this.itemOptionTemplates.size() + ")\n");
/* 234 */     } catch (Exception e) {
/* 235 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void loadNpcTemplate() {
/* 240 */     this.npcTemplates = new ArrayList<>();
/*     */     try {
/* 242 */       GirlkunResultSet rs = GirlkunDB.executeQuery("GIRLKUN", "select * from npc_template");
/* 243 */       while (rs.next()) {
/*     */         
/* 245 */         NpcTemplate npcTemplate = new NpcTemplate(rs.getInt("id"), rs.getString("name"), rs.getInt("head"), rs.getInt("body"), rs.getInt("leg"), rs.getInt("avatar"));
/* 246 */         this.npcTemplates.add(npcTemplate);
/*     */       } 
/* 248 */       Logger.success("Load dữ liệu npc template thành công (" + this.npcTemplates.size() + ")\n");
/* 249 */     } catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */   
/*     */   private void loadHeadAvatar() {
/* 254 */     this.headAvatars = new ArrayList<>();
/*     */     try {
/* 256 */       GirlkunResultSet rs = GirlkunDB.executeQuery("GIRLKUN", "select * from head_avatar");
/* 257 */       while (rs.next()) {
/* 258 */         HeadAvatar headAvatar = new HeadAvatar(rs.getInt("head_id"), rs.getInt("avatar_id"));
/* 259 */         this.headAvatars.add(headAvatar);
/*     */       } 
/* 261 */       Logger.success("Load dữ liệu head avatar thành công (" + this.headAvatars.size() + ")\n");
/* 262 */     } catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */   
/*     */   private void loadBgItemTemplate() {
/* 267 */     this.bgItemTemplates = new ArrayList<>();
/*     */     try {
/* 269 */       GirlkunResultSet rs = GirlkunDB.executeQuery("GIRLKUN", "select * from bg_item_template");
/* 270 */       while (rs.next()) {
/* 271 */         BgItemTemplate bgItemTemplate = new BgItemTemplate(rs.getInt("id"), rs.getInt("image_id"), rs.getInt("layer"), rs.getInt("dx"), rs.getInt("dy"));
/* 272 */         this.bgItemTemplates.add(bgItemTemplate);
/*     */       } 
/* 274 */       Logger.success("Load dữ liệu background item template thành công (" + this.bgItemTemplates.size() + ")\n");
/* 275 */     } catch (Exception e) {
/* 276 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void loadMobTemplate() {
/* 281 */     this.mobTemplates = new ArrayList<>();
/*     */     try {
/* 283 */       GirlkunResultSet rs = GirlkunDB.executeQuery("GIRLKUN", "select * from mob_template");
/* 284 */       while (rs.next()) {
/* 285 */         MobTemplate mobTemplate = new MobTemplate(rs.getInt("id"), rs.getInt("type"), rs.getString("name"), rs.getInt("range_move"), rs.getInt("speed"));
/* 286 */         this.mobTemplates.add(mobTemplate);
/*     */       } 
/* 288 */       Logger.success("Load dữ liệu mob template thành công (" + this.mobTemplates.size() + ")\n");
/* 289 */     } catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */   
/*     */   private void loadTileType() {
/*     */     try {
/* 295 */       DataInputStream dis = new DataInputStream(new FileInputStream("data/girlkun/map/tile_set_info"));
/* 296 */       int nTileset = dis.readByte();
/* 297 */       for (int i = 0; i < nTileset; i++) {
/* 298 */         TilesetType t = new TilesetType();
/* 299 */         t.id = i + 1;
/* 300 */         int n = dis.readByte();
/* 301 */         for (int j = 0; j < n; j++) {
/* 302 */           int tileType = dis.readInt();
/* 303 */           int nTile = dis.readByte();
/* 304 */           for (int k = 0; k < nTile; k++) {
/* 305 */             int tileIndex = dis.readByte();
/* 306 */             List<Integer> list = (List<Integer>)t.tileType.get(Integer.valueOf(tileIndex));
/* 307 */             if (list != null) {
/* 308 */               list.add(Integer.valueOf(tileType));
/*     */             }
/*     */           } 
/*     */         } 
/* 312 */         this.tile_set_type.add(t);
/*     */       } 
/* 314 */       Logger.success("Load dữ liệu tile set type thành công (" + this.tile_set_type.size() + ")\n");
/* 315 */     } catch (Exception e) {
/* 316 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void ____________________________________________________________() {}
/*     */ 
/*     */   
/*     */   public NpcTemplate getNpcTemplateById(int npcId) throws Exception {
/* 325 */     for (NpcTemplate npc : this.npcTemplates) {
/* 326 */       if (npc.getId() == npcId) {
/* 327 */         return npc;
/*     */       }
/*     */     } 
/* 330 */     throw new Exception("Không tìm thấy npc " + npcId);
/*     */   }
/*     */   
/*     */   public HeadAvatar getHeadAvatarByHeadId(int headId) throws Exception {
/* 334 */     for (HeadAvatar ha : this.headAvatars) {
/* 335 */       if (ha.getHead() == headId) {
/* 336 */         return ha;
/*     */       }
/*     */     } 
/* 339 */     throw new Exception("Không tìm thấy head avatar " + headId);
/*     */   }
/*     */   
/*     */   public EffectTemplate getEffectTemplateById(int id) throws Exception {
/* 343 */     for (EffectTemplate eff : this.effectTemplates) {
/* 344 */       if (eff.getId() == id) {
/* 345 */         return eff;
/*     */       }
/*     */     } 
/* 348 */     throw new Exception("Không tìm thấy effect " + id);
/*     */   }
/*     */ }


/* Location:              D:\nro\server_luxu_nrp\vemap\GirlkunToolCBRO.jar!\com\girlkun\tool\main\Manager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */