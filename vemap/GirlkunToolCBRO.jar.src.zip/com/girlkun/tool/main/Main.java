/*     */ package com.girlkun.tool.main;
/*     */ 
/*     */ import com.girlkun.button.Button;
/*     */ import com.girlkun.tool.screens.create_eff_template_scr.CreateEffectTemplateScr;
/*     */ import com.girlkun.tool.screens.part_scr.PartScr;
/*     */ import com.girlkun.tool.screens.shop_scr.ShopScr;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import javax.swing.GroupLayout;
/*     */ import javax.swing.JDesktopPane;
/*     */ import javax.swing.JMenu;
/*     */ import javax.swing.JMenuBar;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollBar;
/*     */ import javax.swing.JToolBar;
/*     */ import javax.swing.KeyStroke;
/*     */ 
/*     */ public class Main extends JFrame {
/*     */   public static Main I;
/*     */   
/*  24 */   public void setFullScr(boolean fullScr) { this.fullScr = fullScr; } public void setUnFullScreen(Color unFullScreen) { this.unFullScreen = unFullScreen; } public void setFullScreen(Color fullScreen) { this.fullScreen = fullScreen; } public void setCX(int cX) { this.cX = cX; } public void setCY(int cY) { this.cY = cY; } public void setCW(int cW) { this.cW = cW; } public void setCH(int cH) { this.cH = cH; } public void setBtnDrawMap(JMenuItem btnDrawMap) { this.btnDrawMap = btnDrawMap; } public void setBtnPart(JMenuItem btnPart) { this.btnPart = btnPart; } public void setBtnPart1(JMenuItem btnPart1) { this.btnPart1 = btnPart1; } public void setBtnPart2(JMenuItem btnPart2) { this.btnPart2 = btnPart2; } public void setBtnPart3(JMenuItem btnPart3) { this.btnPart3 = btnPart3; } public void setBtnPart4(JMenuItem btnPart4) { this.btnPart4 = btnPart4; } public void setBtnShop(JMenuItem btnShop) { this.btnShop = btnShop; } public void setButton1(Button button1) { this.button1 = button1; } public void setDesktop(JDesktopPane desktop) { this.desktop = desktop; } public void setJMenu1(JMenu jMenu1) { this.jMenu1 = jMenu1; } public void setJMenu2(JMenu jMenu2) { this.jMenu2 = jMenu2; } public void setJMenuBar1(JMenuBar jMenuBar1) { this.jMenuBar1 = jMenuBar1; } public void setJPanel1(JPanel jPanel1) { this.jPanel1 = jPanel1; } public void setJScrollPane1(JScrollPane jScrollPane1) { this.jScrollPane1 = jScrollPane1; } public void setJToolBar1(JToolBar jToolBar1) { this.jToolBar1 = jToolBar1; } public boolean equals(Object o) { if (o == this) return true;  if (!(o instanceof Main)) return false;  Main other = (Main)o; if (!other.canEqual(this)) return false;  if (isFullScr() != other.isFullScr()) return false;  if (getCX() != other.getCX()) return false;  if (getCY() != other.getCY()) return false;  if (getCW() != other.getCW()) return false;  if (getCH() != other.getCH()) return false;  Object this$unFullScreen = getUnFullScreen(), other$unFullScreen = other.getUnFullScreen(); if ((this$unFullScreen == null) ? (other$unFullScreen != null) : !this$unFullScreen.equals(other$unFullScreen)) return false;  Object this$fullScreen = getFullScreen(), other$fullScreen = other.getFullScreen(); if ((this$fullScreen == null) ? (other$fullScreen != null) : !this$fullScreen.equals(other$fullScreen)) return false;  Object this$btnDrawMap = getBtnDrawMap(), other$btnDrawMap = other.getBtnDrawMap(); if ((this$btnDrawMap == null) ? (other$btnDrawMap != null) : !this$btnDrawMap.equals(other$btnDrawMap)) return false;  Object this$btnPart = getBtnPart(), other$btnPart = other.getBtnPart(); if ((this$btnPart == null) ? (other$btnPart != null) : !this$btnPart.equals(other$btnPart)) return false;  Object this$btnPart1 = getBtnPart1(), other$btnPart1 = other.getBtnPart1(); if ((this$btnPart1 == null) ? (other$btnPart1 != null) : !this$btnPart1.equals(other$btnPart1)) return false;  Object this$btnPart2 = getBtnPart2(), other$btnPart2 = other.getBtnPart2(); if ((this$btnPart2 == null) ? (other$btnPart2 != null) : !this$btnPart2.equals(other$btnPart2)) return false;  Object this$btnPart3 = getBtnPart3(), other$btnPart3 = other.getBtnPart3(); if ((this$btnPart3 == null) ? (other$btnPart3 != null) : !this$btnPart3.equals(other$btnPart3)) return false;  Object this$btnPart4 = getBtnPart4(), other$btnPart4 = other.getBtnPart4(); if ((this$btnPart4 == null) ? (other$btnPart4 != null) : !this$btnPart4.equals(other$btnPart4)) return false;  Object this$btnShop = getBtnShop(), other$btnShop = other.getBtnShop(); if ((this$btnShop == null) ? (other$btnShop != null) : !this$btnShop.equals(other$btnShop)) return false;  Object this$button1 = getButton1(), other$button1 = other.getButton1(); if ((this$button1 == null) ? (other$button1 != null) : !this$button1.equals(other$button1)) return false;  Object this$desktop = getDesktop(), other$desktop = other.getDesktop(); if ((this$desktop == null) ? (other$desktop != null) : !this$desktop.equals(other$desktop)) return false;  Object this$jMenu1 = getJMenu1(), other$jMenu1 = other.getJMenu1(); if ((this$jMenu1 == null) ? (other$jMenu1 != null) : !this$jMenu1.equals(other$jMenu1)) return false;  Object this$jMenu2 = getJMenu2(), other$jMenu2 = other.getJMenu2(); if ((this$jMenu2 == null) ? (other$jMenu2 != null) : !this$jMenu2.equals(other$jMenu2)) return false;  Object this$jMenuBar1 = getJMenuBar1(), other$jMenuBar1 = other.getJMenuBar1(); if ((this$jMenuBar1 == null) ? (other$jMenuBar1 != null) : !this$jMenuBar1.equals(other$jMenuBar1)) return false;  Object this$jPanel1 = getJPanel1(), other$jPanel1 = other.getJPanel1(); if ((this$jPanel1 == null) ? (other$jPanel1 != null) : !this$jPanel1.equals(other$jPanel1)) return false;  Object this$jScrollPane1 = getJScrollPane1(), other$jScrollPane1 = other.getJScrollPane1(); if ((this$jScrollPane1 == null) ? (other$jScrollPane1 != null) : !this$jScrollPane1.equals(other$jScrollPane1)) return false;  Object this$jToolBar1 = getJToolBar1(), other$jToolBar1 = other.getJToolBar1(); return !((this$jToolBar1 == null) ? (other$jToolBar1 != null) : !this$jToolBar1.equals(other$jToolBar1)); } protected boolean canEqual(Object other) { return other instanceof Main; } public int hashCode() { int PRIME = 59; result = 1; result = result * 59 + (isFullScr() ? 79 : 97); result = result * 59 + getCX(); result = result * 59 + getCY(); result = result * 59 + getCW(); result = result * 59 + getCH(); Object $unFullScreen = getUnFullScreen(); result = result * 59 + (($unFullScreen == null) ? 43 : $unFullScreen.hashCode()); Object $fullScreen = getFullScreen(); result = result * 59 + (($fullScreen == null) ? 43 : $fullScreen.hashCode()); Object $btnDrawMap = getBtnDrawMap(); result = result * 59 + (($btnDrawMap == null) ? 43 : $btnDrawMap.hashCode()); Object $btnPart = getBtnPart(); result = result * 59 + (($btnPart == null) ? 43 : $btnPart.hashCode()); Object $btnPart1 = getBtnPart1(); result = result * 59 + (($btnPart1 == null) ? 43 : $btnPart1.hashCode()); Object $btnPart2 = getBtnPart2(); result = result * 59 + (($btnPart2 == null) ? 43 : $btnPart2.hashCode()); Object $btnPart3 = getBtnPart3(); result = result * 59 + (($btnPart3 == null) ? 43 : $btnPart3.hashCode()); Object $btnPart4 = getBtnPart4(); result = result * 59 + (($btnPart4 == null) ? 43 : $btnPart4.hashCode()); Object $btnShop = getBtnShop(); result = result * 59 + (($btnShop == null) ? 43 : $btnShop.hashCode()); Object $button1 = getButton1(); result = result * 59 + (($button1 == null) ? 43 : $button1.hashCode()); Object $desktop = getDesktop(); result = result * 59 + (($desktop == null) ? 43 : $desktop.hashCode()); Object $jMenu1 = getJMenu1(); result = result * 59 + (($jMenu1 == null) ? 43 : $jMenu1.hashCode()); Object $jMenu2 = getJMenu2(); result = result * 59 + (($jMenu2 == null) ? 43 : $jMenu2.hashCode()); Object $jMenuBar1 = getJMenuBar1(); result = result * 59 + (($jMenuBar1 == null) ? 43 : $jMenuBar1.hashCode()); Object $jPanel1 = getJPanel1(); result = result * 59 + (($jPanel1 == null) ? 43 : $jPanel1.hashCode()); Object $jScrollPane1 = getJScrollPane1(); result = result * 59 + (($jScrollPane1 == null) ? 43 : $jScrollPane1.hashCode()); Object $jToolBar1 = getJToolBar1(); return result * 59 + (($jToolBar1 == null) ? 43 : $jToolBar1.hashCode()); } public String toString() { return "Main(fullScr=" + isFullScr() + ", unFullScreen=" + getUnFullScreen() + ", fullScreen=" + getFullScreen() + ", cX=" + getCX() + ", cY=" + getCY() + ", cW=" + getCW() + ", cH=" + getCH() + ", btnDrawMap=" + getBtnDrawMap() + ", btnPart=" + getBtnPart() + ", btnPart1=" + getBtnPart1() + ", btnPart2=" + getBtnPart2() + ", btnPart3=" + getBtnPart3() + ", btnPart4=" + getBtnPart4() + ", btnShop=" + getBtnShop() + ", button1=" + getButton1() + ", desktop=" + getDesktop() + ", jMenu1=" + getJMenu1() + ", jMenu2=" + getJMenu2() + ", jMenuBar1=" + getJMenuBar1() + ", jPanel1=" + getJPanel1() + ", jScrollPane1=" + getJScrollPane1() + ", jToolBar1=" + getJToolBar1() + ")"; }
/*     */   
/*     */   private boolean fullScr = false;
/*     */   
/*     */   public boolean isFullScr() {
/*  29 */     return this.fullScr;
/*  30 */   } private Color unFullScreen = new Color(204, 204, 255); public Color getUnFullScreen() { return this.unFullScreen; }
/*  31 */    private Color fullScreen = new Color(255, 0, 204); private int cX; private int cY; private int cW; private int cH; private JMenuItem btnDrawMap; private JMenuItem btnPart; private JMenuItem btnPart1; private JMenuItem btnPart2; private JMenuItem btnPart3; public Color getFullScreen() { return this.fullScreen; }
/*     */    private JMenuItem btnPart4; private JMenuItem btnShop; private Button button1; private JDesktopPane desktop; private JMenu jMenu1; private JMenu jMenu2; private JMenuBar jMenuBar1; private JPanel jPanel1; private JScrollPane jScrollPane1; private JToolBar jToolBar1;
/*     */   public Main() {
/*  34 */     initComponents();
/*  35 */     setup();
/*  36 */     addWindowListener(new WindowAdapter()
/*     */         {
/*     */           public void windowClosing(WindowEvent windowEvent) {
/*  39 */             GirlkunDB.close();
/*     */           }
/*     */         });
/*  42 */     I = this;
/*  43 */     Manager.gI().setSignature((ISignature)new Signature());
/*  44 */     Manager.gI().start();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initComponents() {
/*  51 */     this.jToolBar1 = new JToolBar();
/*  52 */     this.button1 = new Button();
/*  53 */     this.jScrollPane1 = new JScrollPane();
/*  54 */     this.jPanel1 = new JPanel();
/*  55 */     this.desktop = new JDesktopPane();
/*  56 */     this.jMenuBar1 = new JMenuBar();
/*  57 */     this.jMenu1 = new JMenu();
/*  58 */     this.btnShop = new JMenuItem();
/*  59 */     this.btnDrawMap = new JMenuItem();
/*  60 */     this.btnPart = new JMenuItem();
/*  61 */     this.btnPart1 = new JMenuItem();
/*  62 */     this.btnPart2 = new JMenuItem();
/*  63 */     this.btnPart3 = new JMenuItem();
/*  64 */     this.btnPart4 = new JMenuItem();
/*  65 */     this.jMenu2 = new JMenu();
/*     */     
/*  67 */     setDefaultCloseOperation(3);
/*     */     
/*  69 */     this.jToolBar1.setFloatable(false);
/*  70 */     this.jToolBar1.setOrientation(1);
/*  71 */     this.jToolBar1.setRollover(true);
/*     */     
/*  73 */     this.button1.setBackground(new Color(255, 0, 204));
/*  74 */     this.button1.setForeground(new Color(255, 255, 255));
/*  75 */     this.button1.setText("   Full screen    ");
/*  76 */     this.button1.setFocusable(false);
/*  77 */     this.button1.setFont(new Font("SansSerif", 1, 14));
/*  78 */     this.button1.setHorizontalTextPosition(0);
/*  79 */     this.button1.setVerticalTextPosition(3);
/*  80 */     this.button1.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/*  82 */             Main.this.button1ActionPerformed(evt);
/*     */           }
/*     */         });
/*  85 */     this.jToolBar1.add((Component)this.button1);
/*     */     
/*  87 */     this.jPanel1.setPreferredSize(new Dimension(32767, 700));
/*  88 */     this.jPanel1.setLayout(new BorderLayout());
/*     */     
/*  90 */     this.desktop.setCursor(new Cursor(0));
/*  91 */     this.desktop.setPreferredSize(new Dimension(100000, 950));
/*     */     
/*  93 */     GroupLayout desktopLayout = new GroupLayout(this.desktop);
/*  94 */     this.desktop.setLayout(desktopLayout);
/*  95 */     desktopLayout.setHorizontalGroup(desktopLayout
/*  96 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/*  97 */         .addGap(0, 32767, 32767));
/*     */     
/*  99 */     desktopLayout.setVerticalGroup(desktopLayout
/* 100 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 101 */         .addGap(0, 853, 32767));
/*     */ 
/*     */     
/* 104 */     this.jPanel1.add(this.desktop, "Center");
/*     */     
/* 106 */     this.jScrollPane1.setViewportView(this.jPanel1);
/*     */     
/* 108 */     this.jMenu1.setText("Quản lý");
/*     */     
/* 110 */     this.btnShop.setAccelerator(KeyStroke.getKeyStroke(83, 2));
/* 111 */     this.btnShop.setText("Shop");
/* 112 */     this.btnShop.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/* 114 */             Main.this.btnShopActionPerformed(evt);
/*     */           }
/*     */         });
/* 117 */     this.jMenu1.add(this.btnShop);
/*     */     
/* 119 */     this.btnDrawMap.setAccelerator(KeyStroke.getKeyStroke(68, 2));
/* 120 */     this.btnDrawMap.setText("Draw map");
/* 121 */     this.btnDrawMap.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/* 123 */             Main.this.btnDrawMapActionPerformed(evt);
/*     */           }
/*     */         });
/* 126 */     this.jMenu1.add(this.btnDrawMap);
/*     */     
/* 128 */     this.btnPart.setAccelerator(KeyStroke.getKeyStroke(80, 2));
/* 129 */     this.btnPart.setText("Part");
/* 130 */     this.btnPart.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/* 132 */             Main.this.btnPartActionPerformed(evt);
/*     */           }
/*     */         });
/* 135 */     this.jMenu1.add(this.btnPart);
/*     */     
/* 137 */     this.btnPart1.setAccelerator(KeyStroke.getKeyStroke(77, 2));
/* 138 */     this.btnPart1.setText("Mob reward");
/* 139 */     this.btnPart1.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/* 141 */             Main.this.btnPart1ActionPerformed(evt);
/*     */           }
/*     */         });
/* 144 */     this.jMenu1.add(this.btnPart1);
/*     */     
/* 146 */     this.btnPart2.setAccelerator(KeyStroke.getKeyStroke(76, 2));
/* 147 */     this.btnPart2.setText("Lucky round reward");
/* 148 */     this.btnPart2.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/* 150 */             Main.this.btnPart2ActionPerformed(evt);
/*     */           }
/*     */         });
/* 153 */     this.jMenu1.add(this.btnPart2);
/*     */     
/* 155 */     this.btnPart3.setAccelerator(KeyStroke.getKeyStroke(69, 2));
/* 156 */     this.btnPart3.setText("Create effect template");
/* 157 */     this.btnPart3.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/* 159 */             Main.this.btnPart3ActionPerformed(evt);
/*     */           }
/*     */         });
/* 162 */     this.jMenu1.add(this.btnPart3);
/*     */     
/* 164 */     this.btnPart4.setAccelerator(KeyStroke.getKeyStroke(73, 2));
/* 165 */     this.btnPart4.setText("Create item json");
/* 166 */     this.btnPart4.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/* 168 */             Main.this.btnPart4ActionPerformed(evt);
/*     */           }
/*     */         });
/* 171 */     this.jMenu1.add(this.btnPart4);
/*     */     
/* 173 */     this.jMenuBar1.add(this.jMenu1);
/*     */     
/* 175 */     this.jMenu2.setText("Edit");
/* 176 */     this.jMenuBar1.add(this.jMenu2);
/*     */     
/* 178 */     setJMenuBar(this.jMenuBar1);
/*     */     
/* 180 */     GroupLayout layout = new GroupLayout(getContentPane());
/* 181 */     getContentPane().setLayout(layout);
/* 182 */     layout.setHorizontalGroup(layout
/* 183 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 184 */         .addGroup(layout.createSequentialGroup()
/* 185 */           .addComponent(this.jToolBar1, -2, 112, -2)
/* 186 */           .addGap(0, 0, 0)
/* 187 */           .addComponent(this.jScrollPane1, -1, 1669, 32767)));
/*     */     
/* 189 */     layout.setVerticalGroup(layout
/* 190 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 191 */         .addComponent(this.jScrollPane1, -1, 872, 32767)
/* 192 */         .addGroup(GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
/* 193 */           .addContainerGap()
/* 194 */           .addComponent(this.jToolBar1, -1, -1, 32767)));
/*     */ 
/*     */     
/* 197 */     pack();
/*     */   }
/*     */   
/* 200 */   public int getCX() { return this.cX; } public int getCY() { return this.cY; } public int getCW() { return this.cW; } public int getCH() { return this.cH; }
/*     */   
/*     */   private void button1ActionPerformed(ActionEvent evt) {
/* 203 */     this.fullScr = !this.fullScr;
/* 204 */     if (this.fullScr) {
/* 205 */       this.cX = getX();
/* 206 */       this.cY = getY();
/* 207 */       this.cW = getWidth();
/* 208 */       this.cH = getHeight();
/* 209 */       setExtendedState(6);
/* 210 */       this.button1.setBackground(this.unFullScreen);
/*     */     } else {
/* 212 */       setSize(new Dimension(this.cW, this.cH));
/* 213 */       setLocation(this.cX, this.cY);
/* 214 */       this.button1.setBackground(this.fullScreen);
/*     */     } 
/* 216 */     dispose();
/* 217 */     setUndecorated(this.fullScr);
/* 218 */     setVisible(true);
/*     */   }
/*     */   
/*     */   private void btnPart1ActionPerformed(ActionEvent evt) {
/* 222 */     MobRewardScr mobRewardScr = new MobRewardScr();
/* 223 */     this.desktop.add((Component)mobRewardScr);
/* 224 */     JScrollBar bar = this.jScrollPane1.getHorizontalScrollBar();
/* 225 */     mobRewardScr.setLocation(bar.getValue(), 0);
/* 226 */     mobRewardScr.setVisible(true);
/*     */   }
/*     */   
/*     */   private void btnPart2ActionPerformed(ActionEvent evt) {
/* 230 */     LuckyRoundRewardScr luckyRoundRewardScr = new LuckyRoundRewardScr();
/* 231 */     this.desktop.add((Component)luckyRoundRewardScr);
/* 232 */     JScrollBar bar = this.jScrollPane1.getHorizontalScrollBar();
/* 233 */     luckyRoundRewardScr.setLocation(bar.getValue(), 0);
/* 234 */     luckyRoundRewardScr.setVisible(true);
/*     */   }
/*     */   
/*     */   private void btnPart4ActionPerformed(ActionEvent evt) {
/* 238 */     CreateItemJsonScr createItemJsonScr = new CreateItemJsonScr();
/* 239 */     this.desktop.add((Component)createItemJsonScr);
/* 240 */     JScrollBar bar = this.jScrollPane1.getHorizontalScrollBar();
/* 241 */     createItemJsonScr.setLocation(bar.getValue(), 0);
/* 242 */     createItemJsonScr.setVisible(true);
/*     */   }
/*     */   
/*     */   private void btnPart3ActionPerformed(ActionEvent evt) {
/* 246 */     CreateEffectTemplateScr createEffectTemplateScr = new CreateEffectTemplateScr();
/* 247 */     this.desktop.add((Component)createEffectTemplateScr);
/* 248 */     JScrollBar bar = this.jScrollPane1.getHorizontalScrollBar();
/* 249 */     createEffectTemplateScr.setLocation(bar.getValue(), 0);
/* 250 */     createEffectTemplateScr.setVisible(true);
/*     */   }
/*     */   
/*     */   private void btnPartActionPerformed(ActionEvent evt) {
/* 254 */     PartScr partScr = new PartScr();
/* 255 */     this.desktop.add((Component)partScr);
/* 256 */     JScrollBar bar = this.jScrollPane1.getHorizontalScrollBar();
/* 257 */     partScr.setLocation(bar.getValue(), 0);
/* 258 */     partScr.setVisible(true);
/*     */   }
/*     */   
/*     */   private void btnDrawMapActionPerformed(ActionEvent evt) {
/* 262 */     DrawMapScr drawMapScr = new DrawMapScr();
/* 263 */     this.desktop.add((Component)drawMapScr);
/* 264 */     JScrollBar bar = this.jScrollPane1.getHorizontalScrollBar();
/* 265 */     drawMapScr.setLocation(bar.getValue(), 0);
/* 266 */     drawMapScr.setVisible(true);
/*     */   }
/*     */   
/*     */   private void btnShopActionPerformed(ActionEvent evt) {
/* 270 */     ShopScr shopScr = new ShopScr();
/* 271 */     this.desktop.add((Component)shopScr);
/* 272 */     JScrollBar bar = this.jScrollPane1.getHorizontalScrollBar();
/* 273 */     shopScr.setLocation(bar.getValue(), 0);
/* 274 */     shopScr.setVisible(true);
/*     */   }
/*     */ 
/*     */   
/*     */   private void setup() {
/* 279 */     setTitle("GIRLKUN75");
/* 280 */     setLocationRelativeTo((Component)null);
/* 281 */     setLocation(getX(), getY());
/*     */     
/* 283 */     this.jScrollPane1.getHorizontalScrollBar().setUnitIncrement(64);
/* 284 */     this.jScrollPane1.getVerticalScrollBar().setUnitIncrement(64);
/*     */   }
/*     */   
/*     */   public static void main(String[] args) {
/* 288 */     FlatDarkPurpleIJTheme.setup();
/* 289 */     EventQueue.invokeLater(new Runnable() {
/*     */           public void run() {
/* 291 */             Manager.gI();
/* 292 */             (new Main()).setVisible(true);
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   public JMenuItem getBtnDrawMap() {
/* 298 */     return this.btnDrawMap;
/* 299 */   } public JMenuItem getBtnPart() { return this.btnPart; }
/* 300 */   public JMenuItem getBtnPart1() { return this.btnPart1; }
/* 301 */   public JMenuItem getBtnPart2() { return this.btnPart2; }
/* 302 */   public JMenuItem getBtnPart3() { return this.btnPart3; }
/* 303 */   public JMenuItem getBtnPart4() { return this.btnPart4; }
/* 304 */   public JMenuItem getBtnShop() { return this.btnShop; }
/* 305 */   public Button getButton1() { return this.button1; }
/* 306 */   public JDesktopPane getDesktop() { return this.desktop; }
/* 307 */   public JMenu getJMenu1() { return this.jMenu1; }
/* 308 */   public JMenu getJMenu2() { return this.jMenu2; }
/* 309 */   public JMenuBar getJMenuBar1() { return this.jMenuBar1; }
/* 310 */   public JPanel getJPanel1() { return this.jPanel1; }
/* 311 */   public JScrollPane getJScrollPane1() { return this.jScrollPane1; } public JToolBar getJToolBar1() {
/* 312 */     return this.jToolBar1;
/*     */   }
/*     */ }


/* Location:              D:\nro\server_luxu_nrp\vemap\GirlkunToolCBRO.jar!\com\girlkun\tool\main\Main.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */