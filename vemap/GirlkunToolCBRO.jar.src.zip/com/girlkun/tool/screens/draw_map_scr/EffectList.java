/*     */ package com.girlkun.tool.screens.draw_map_scr;
/*     */ import com.girlkun.button.Button;
/*     */ import com.girlkun.tool.screens.draw_map_scr.models.EffectMap;
/*     */ import com.girlkun.tool.screens.draw_map_scr.models.SubEffectMap;
/*     */ import com.girlkun.tool.utils.Util;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Font;
/*     */ import java.awt.Image;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.KeyAdapter;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import javax.swing.GroupLayout;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.LayoutStyle;
/*     */ import javax.swing.table.DefaultTableModel;
/*     */ import org.json.simple.JSONArray;
/*     */ import org.json.simple.JSONValue;
/*     */ 
/*     */ public class EffectList extends JFrame {
/*     */   private DrawMapScr drawMapScr;
/*     */   private DefaultTableModel model1;
/*     */   private int index;
/*     */   private Button button1;
/*     */   private Button button2;
/*     */   private JLabel jLabel1;
/*     */   private JLabel jLabel2;
/*     */   private JLabel jLabel3;
/*     */   private JLabel jLabel4;
/*     */   private JLabel jLabel5;
/*     */   private JLabel jLabel6;
/*     */   
/*     */   public EffectList(DrawMapScr drawMapScr) {
/*  42 */     this.drawMapScr = drawMapScr;
/*  43 */     initComponents();
/*  44 */     setup();
/*  45 */     setDefaultCloseOperation(2);
/*  46 */     setTitle("Girlkun75 - List effect map");
/*  47 */     setAlwaysOnTop(true);
/*     */   }
/*     */   private JLabel jLabel7; private JLabel jLabel8; private JScrollPane jScrollPane2; private JTable tbl1;
/*     */   private JTextField txtFrom;
/*     */   private JTextField txtLayer;
/*     */   
/*     */   private void initComponents() {
/*  54 */     this.jScrollPane2 = new JScrollPane();
/*  55 */     this.tbl1 = new JTable();
/*  56 */     this.button1 = new Button();
/*  57 */     this.button2 = new Button();
/*  58 */     this.jLabel1 = new JLabel();
/*  59 */     this.txtX = new JTextField();
/*  60 */     this.txtY = new JTextField();
/*  61 */     this.jLabel2 = new JLabel();
/*  62 */     this.txtLayer = new JTextField();
/*  63 */     this.jLabel3 = new JLabel();
/*  64 */     this.txtLoop = new JTextField();
/*  65 */     this.jLabel4 = new JLabel();
/*  66 */     this.txtLoopCount = new JTextField();
/*  67 */     this.jLabel5 = new JLabel();
/*  68 */     this.txtFrom = new JTextField();
/*  69 */     this.jLabel6 = new JLabel();
/*  70 */     this.jLabel7 = new JLabel();
/*  71 */     this.txtTo = new JTextField();
/*  72 */     this.jLabel8 = new JLabel();
/*  73 */     this.txtType = new JTextField();
/*     */     
/*  75 */     setDefaultCloseOperation(3);
/*     */     
/*  77 */     this.tbl1.setModel(new DefaultTableModel(new Object[0][], (Object[])new String[0]));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  85 */     this.tbl1.setSelectionMode(0);
/*  86 */     this.tbl1.addMouseListener(new MouseAdapter() {
/*     */           public void mouseClicked(MouseEvent evt) {
/*  88 */             EffectList.this.tbl1MouseClicked(evt);
/*     */           }
/*     */         });
/*  91 */     this.tbl1.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/*  93 */             EffectList.this.tbl1KeyPressed(evt);
/*     */           }
/*     */           public void keyReleased(KeyEvent evt) {
/*  96 */             EffectList.this.tbl1KeyReleased(evt);
/*     */           }
/*     */         });
/*  99 */     this.jScrollPane2.setViewportView(this.tbl1);
/*     */     
/* 101 */     this.button1.setBackground(new Color(255, 0, 0));
/* 102 */     this.button1.setForeground(new Color(255, 255, 255));
/* 103 */     this.button1.setText("Clear all");
/* 104 */     this.button1.setFont(new Font("SansSerif", 1, 14));
/* 105 */     this.button1.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/* 107 */             EffectList.this.button1ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     
/* 111 */     this.button2.setBackground(new Color(255, 0, 0));
/* 112 */     this.button2.setForeground(new Color(255, 255, 255));
/* 113 */     this.button2.setText("Remove");
/* 114 */     this.button2.setFont(new Font("SansSerif", 1, 14));
/* 115 */     this.button2.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/* 117 */             EffectList.this.button2ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     
/* 121 */     this.jLabel1.setFont(new Font("SansSerif", 1, 12));
/* 122 */     this.jLabel1.setHorizontalAlignment(0);
/* 123 */     this.jLabel1.setText("x");
/*     */     
/* 125 */     this.txtX.setFont(new Font("SansSerif", 1, 12));
/* 126 */     this.txtX.addKeyListener(new KeyAdapter() {
/*     */           public void keyReleased(KeyEvent evt) {
/* 128 */             EffectList.this.txtXKeyReleased(evt);
/*     */           }
/*     */         });
/*     */     
/* 132 */     this.txtY.setFont(new Font("SansSerif", 1, 12));
/* 133 */     this.txtY.addKeyListener(new KeyAdapter() {
/*     */           public void keyReleased(KeyEvent evt) {
/* 135 */             EffectList.this.txtYKeyReleased(evt);
/*     */           }
/*     */         });
/*     */     
/* 139 */     this.jLabel2.setFont(new Font("SansSerif", 1, 12));
/* 140 */     this.jLabel2.setHorizontalAlignment(0);
/* 141 */     this.jLabel2.setText("y");
/*     */     
/* 143 */     this.txtLayer.setFont(new Font("SansSerif", 1, 12));
/* 144 */     this.txtLayer.addKeyListener(new KeyAdapter() {
/*     */           public void keyReleased(KeyEvent evt) {
/* 146 */             EffectList.this.txtLayerKeyReleased(evt);
/*     */           }
/*     */         });
/*     */     
/* 150 */     this.jLabel3.setFont(new Font("SansSerif", 1, 12));
/* 151 */     this.jLabel3.setHorizontalAlignment(0);
/* 152 */     this.jLabel3.setText("layer");
/*     */     
/* 154 */     this.txtLoop.setFont(new Font("SansSerif", 1, 12));
/* 155 */     this.txtLoop.addKeyListener(new KeyAdapter() {
/*     */           public void keyReleased(KeyEvent evt) {
/* 157 */             EffectList.this.txtLoopKeyReleased(evt);
/*     */           }
/*     */         });
/*     */     
/* 161 */     this.jLabel4.setFont(new Font("SansSerif", 1, 12));
/* 162 */     this.jLabel4.setHorizontalAlignment(0);
/* 163 */     this.jLabel4.setText("loop");
/*     */     
/* 165 */     this.txtLoopCount.setFont(new Font("SansSerif", 1, 12));
/* 166 */     this.txtLoopCount.addKeyListener(new KeyAdapter() {
/*     */           public void keyReleased(KeyEvent evt) {
/* 168 */             EffectList.this.txtLoopCountKeyReleased(evt);
/*     */           }
/*     */         });
/*     */     
/* 172 */     this.jLabel5.setFont(new Font("SansSerif", 1, 12));
/* 173 */     this.jLabel5.setHorizontalAlignment(0);
/* 174 */     this.jLabel5.setText("count");
/*     */     
/* 176 */     this.txtFrom.setFont(new Font("SansSerif", 1, 12));
/* 177 */     this.txtFrom.addKeyListener(new KeyAdapter() {
/*     */           public void keyReleased(KeyEvent evt) {
/* 179 */             EffectList.this.txtFromKeyReleased(evt);
/*     */           }
/*     */         });
/*     */     
/* 183 */     this.jLabel6.setFont(new Font("SansSerif", 1, 12));
/* 184 */     this.jLabel6.setHorizontalAlignment(0);
/* 185 */     this.jLabel6.setText("from");
/*     */     
/* 187 */     this.jLabel7.setFont(new Font("SansSerif", 1, 12));
/* 188 */     this.jLabel7.setHorizontalAlignment(0);
/* 189 */     this.jLabel7.setText("to");
/*     */     
/* 191 */     this.txtTo.setFont(new Font("SansSerif", 1, 12));
/* 192 */     this.txtTo.addKeyListener(new KeyAdapter() {
/*     */           public void keyReleased(KeyEvent evt) {
/* 194 */             EffectList.this.txtToKeyReleased(evt);
/*     */           }
/*     */         });
/*     */     
/* 198 */     this.jLabel8.setFont(new Font("SansSerif", 1, 12));
/* 199 */     this.jLabel8.setHorizontalAlignment(0);
/* 200 */     this.jLabel8.setText("type");
/*     */     
/* 202 */     this.txtType.setFont(new Font("SansSerif", 1, 12));
/* 203 */     this.txtType.addKeyListener(new KeyAdapter() {
/*     */           public void keyReleased(KeyEvent evt) {
/* 205 */             EffectList.this.txtTypeKeyReleased(evt);
/*     */           }
/*     */         });
/*     */     
/* 209 */     GroupLayout layout = new GroupLayout(getContentPane());
/* 210 */     getContentPane().setLayout(layout);
/* 211 */     layout.setHorizontalGroup(layout
/* 212 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 213 */         .addGroup(layout.createSequentialGroup()
/* 214 */           .addComponent(this.jScrollPane2, -2, 508, -2)
/* 215 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 216 */           .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 217 */             .addComponent((Component)this.button1, -1, 208, 32767)
/* 218 */             .addComponent((Component)this.button2, -1, 208, 32767)
/* 219 */             .addGroup(layout.createSequentialGroup()
/* 220 */               .addComponent(this.jLabel1, -2, 57, -2)
/* 221 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 222 */               .addComponent(this.txtX))
/* 223 */             .addGroup(layout.createSequentialGroup()
/* 224 */               .addComponent(this.jLabel2, -2, 57, -2)
/* 225 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 226 */               .addComponent(this.txtY))
/* 227 */             .addGroup(layout.createSequentialGroup()
/* 228 */               .addComponent(this.jLabel3, -2, 57, -2)
/* 229 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 230 */               .addComponent(this.txtLayer))
/* 231 */             .addGroup(layout.createSequentialGroup()
/* 232 */               .addComponent(this.jLabel4, -2, 57, -2)
/* 233 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 234 */               .addComponent(this.txtLoop))
/* 235 */             .addGroup(layout.createSequentialGroup()
/* 236 */               .addComponent(this.jLabel5, -2, 57, -2)
/* 237 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 238 */               .addComponent(this.txtLoopCount))
/* 239 */             .addGroup(layout.createSequentialGroup()
/* 240 */               .addComponent(this.jLabel6, -2, 57, -2)
/* 241 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 242 */               .addComponent(this.txtFrom))
/* 243 */             .addGroup(layout.createSequentialGroup()
/* 244 */               .addComponent(this.jLabel7, -2, 57, -2)
/* 245 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 246 */               .addComponent(this.txtTo))
/* 247 */             .addGroup(layout.createSequentialGroup()
/* 248 */               .addComponent(this.jLabel8, -2, 57, -2)
/* 249 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 250 */               .addComponent(this.txtType)))));
/*     */     
/* 252 */     layout.setVerticalGroup(layout
/* 253 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 254 */         .addGroup(layout.createSequentialGroup()
/* 255 */           .addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false)
/* 256 */             .addComponent(this.jScrollPane2, GroupLayout.Alignment.LEADING, -2, 0, 32767)
/* 257 */             .addGroup(layout.createSequentialGroup()
/* 258 */               .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 259 */                 .addComponent(this.jLabel1, -1, -1, 32767)
/* 260 */                 .addComponent(this.txtX, -1, 33, 32767))
/* 261 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 262 */               .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 263 */                 .addComponent(this.jLabel2, -2, 33, -2)
/* 264 */                 .addComponent(this.txtY, -2, 33, -2))
/* 265 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 266 */               .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 267 */                 .addComponent(this.jLabel3, -2, 33, -2)
/* 268 */                 .addComponent(this.txtLayer, -2, 33, -2))
/* 269 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 270 */               .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 271 */                 .addComponent(this.jLabel4, -2, 33, -2)
/* 272 */                 .addComponent(this.txtLoop, -2, 33, -2))
/* 273 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 274 */               .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 275 */                 .addComponent(this.jLabel5, -2, 33, -2)
/* 276 */                 .addComponent(this.txtLoopCount, -2, 33, -2))
/* 277 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 278 */               .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 279 */                 .addComponent(this.jLabel6, -2, 33, -2)
/* 280 */                 .addComponent(this.txtFrom, -2, 33, -2))
/* 281 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 282 */               .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 283 */                 .addComponent(this.jLabel7, -2, 33, -2)
/* 284 */                 .addComponent(this.txtTo, -2, 33, -2))
/* 285 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 286 */               .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 287 */                 .addComponent(this.jLabel8, -2, 33, -2)
/* 288 */                 .addComponent(this.txtType, -2, 33, -2))
/* 289 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 290 */               .addComponent((Component)this.button2, -2, 36, -2)
/* 291 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 292 */               .addComponent((Component)this.button1, -2, 36, -2)))
/* 293 */           .addGap(0, 0, 0)));
/*     */ 
/*     */     
/* 296 */     pack();
/*     */   }
/*     */   private JTextField txtLoop; private JTextField txtLoopCount; private JTextField txtTo; private JTextField txtType; private JTextField txtX; private JTextField txtY;
/*     */   private void tbl1MouseClicked(MouseEvent evt) {
/* 300 */     this.index = this.tbl1.getSelectedRow();
/* 301 */     if (this.index != -1) {
/*     */       try {
/* 303 */         this.drawMapScr.setEffectMapChoes(this.drawMapScr.effectMaps.get(this.index));
/* 304 */         this.txtX.setText(this.drawMapScr.effChose.getX() + "");
/* 305 */         this.txtY.setText(this.drawMapScr.effChose.getY() + "");
/* 306 */         this.txtLayer.setText(this.drawMapScr.effChose.getLayer() + "");
/* 307 */         this.txtLoop.setText(this.drawMapScr.effChose.getLoop() + "");
/* 308 */         this.txtLoopCount.setText(this.drawMapScr.effChose.getLoopCount() + "");
/* 309 */         this.txtFrom.setText(this.drawMapScr.effChose.getIndexFrom() + "");
/* 310 */         this.txtTo.setText(this.drawMapScr.effChose.getIndexTo() + "");
/* 311 */         this.txtType.setText(this.drawMapScr.effChose.getType() + "");
/* 312 */       } catch (Exception e) {
/* 313 */         this.drawMapScr.setEffectMapChoes((EffectMap)this.drawMapScr.subEffectMaps.get(this.index - this.drawMapScr.effectMaps.size()));
/*     */         
/* 315 */         this.drawMapScr.setEffectMapChoes(this.drawMapScr.effectMaps.get(this.index));
/* 316 */         this.txtX.setText("");
/* 317 */         this.txtY.setText("");
/* 318 */         this.txtLayer.setText("");
/* 319 */         this.txtLoop.setText("");
/* 320 */         this.txtLoopCount.setText("");
/* 321 */         this.txtFrom.setText("");
/* 322 */         this.txtTo.setText("");
/* 323 */         this.txtType.setText("");
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private void tbl1KeyPressed(KeyEvent evt) {
/* 329 */     this.index = this.tbl1.getSelectedRow();
/* 330 */     if (this.index != -1) {
/*     */       try {
/* 332 */         this.drawMapScr.setEffectMapChoes(this.drawMapScr.effectMaps.get(this.index));
/* 333 */         this.txtX.setText(this.drawMapScr.effChose.getX() + "");
/* 334 */         this.txtY.setText(this.drawMapScr.effChose.getY() + "");
/* 335 */         this.txtLayer.setText(this.drawMapScr.effChose.getLayer() + "");
/* 336 */         this.txtLoop.setText(this.drawMapScr.effChose.getLoop() + "");
/* 337 */         this.txtLoopCount.setText(this.drawMapScr.effChose.getLoopCount() + "");
/* 338 */         this.txtFrom.setText(this.drawMapScr.effChose.getIndexFrom() + "");
/* 339 */         this.txtTo.setText(this.drawMapScr.effChose.getIndexTo() + "");
/* 340 */         this.txtType.setText(this.drawMapScr.effChose.getType() + "");
/* 341 */       } catch (Exception e) {
/* 342 */         this.drawMapScr.setEffectMapChoes((EffectMap)this.drawMapScr.subEffectMaps.get(this.index - this.drawMapScr.effectMaps.size()));
/*     */         
/* 344 */         this.drawMapScr.setEffectMapChoes(this.drawMapScr.effectMaps.get(this.index));
/* 345 */         this.txtX.setText("");
/* 346 */         this.txtY.setText("");
/* 347 */         this.txtLayer.setText("");
/* 348 */         this.txtLoop.setText("");
/* 349 */         this.txtLoopCount.setText("");
/* 350 */         this.txtFrom.setText("");
/* 351 */         this.txtTo.setText("");
/* 352 */         this.txtType.setText("");
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private void tbl1KeyReleased(KeyEvent evt) {
/* 358 */     this.index = this.tbl1.getSelectedRow();
/* 359 */     if (this.index != -1) {
/*     */       try {
/* 361 */         this.drawMapScr.setEffectMapChoes(this.drawMapScr.effectMaps.get(this.index));
/* 362 */         this.txtX.setText(this.drawMapScr.effChose.getX() + "");
/* 363 */         this.txtY.setText(this.drawMapScr.effChose.getY() + "");
/* 364 */         this.txtLayer.setText(this.drawMapScr.effChose.getLayer() + "");
/* 365 */         this.txtLoop.setText(this.drawMapScr.effChose.getLoop() + "");
/* 366 */         this.txtLoopCount.setText(this.drawMapScr.effChose.getLoopCount() + "");
/* 367 */         this.txtFrom.setText(this.drawMapScr.effChose.getIndexFrom() + "");
/* 368 */         this.txtTo.setText(this.drawMapScr.effChose.getIndexTo() + "");
/* 369 */         this.txtType.setText(this.drawMapScr.effChose.getType() + "");
/* 370 */       } catch (Exception e) {
/* 371 */         this.drawMapScr.setEffectMapChoes((EffectMap)this.drawMapScr.subEffectMaps.get(this.index - this.drawMapScr.effectMaps.size()));
/*     */         
/* 373 */         this.drawMapScr.setEffectMapChoes(this.drawMapScr.effectMaps.get(this.index));
/* 374 */         this.txtX.setText("");
/* 375 */         this.txtY.setText("");
/* 376 */         this.txtLayer.setText("");
/* 377 */         this.txtLoop.setText("");
/* 378 */         this.txtLoopCount.setText("");
/* 379 */         this.txtFrom.setText("");
/* 380 */         this.txtTo.setText("");
/* 381 */         this.txtType.setText("");
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private void button1ActionPerformed(ActionEvent evt) {
/* 387 */     this.drawMapScr.effectMaps.clear();
/* 388 */     this.drawMapScr.subEffectMaps.clear();
/* 389 */     fillToTable();
/*     */   }
/*     */   
/*     */   private void button2ActionPerformed(ActionEvent evt) {
/* 393 */     this.drawMapScr.effectMaps.remove(this.drawMapScr.effChose);
/* 394 */     this.drawMapScr.subEffectMaps.remove(this.drawMapScr.effChose);
/* 395 */     fillToTable();
/*     */   }
/*     */   
/*     */   private void txtXKeyReleased(KeyEvent evt) {
/*     */     try {
/* 400 */       this.drawMapScr.effChose.setX(Integer.parseInt(this.txtX.getText()));
/* 401 */       fillToTable();
/* 402 */     } catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */   
/*     */   private void txtYKeyReleased(KeyEvent evt) {
/*     */     try {
/* 408 */       this.drawMapScr.effChose.setY(Integer.parseInt(this.txtY.getText()));
/* 409 */       fillToTable();
/* 410 */     } catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */   
/*     */   private void txtLayerKeyReleased(KeyEvent evt) {
/*     */     try {
/* 416 */       this.drawMapScr.effChose.setLayer(Integer.parseInt(this.txtLayer.getText()));
/* 417 */       fillToTable();
/* 418 */     } catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */   
/*     */   private void txtLoopKeyReleased(KeyEvent evt) {
/*     */     try {
/* 424 */       this.drawMapScr.effChose.setLoop(Integer.parseInt(this.txtLoop.getText()));
/* 425 */       fillToTable();
/* 426 */     } catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */   
/*     */   private void txtLoopCountKeyReleased(KeyEvent evt) {
/*     */     try {
/* 432 */       this.drawMapScr.effChose.setLoopCount(Integer.parseInt(this.txtLoopCount.getText()));
/* 433 */       fillToTable();
/* 434 */     } catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */   
/*     */   private void txtFromKeyReleased(KeyEvent evt) {
/*     */     try {
/* 440 */       this.drawMapScr.effChose.setIndexFrom(Integer.parseInt(this.txtFrom.getText()));
/* 441 */       fillToTable();
/* 442 */     } catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */   
/*     */   private void txtToKeyReleased(KeyEvent evt) {
/*     */     try {
/* 448 */       this.drawMapScr.effChose.setIndexTo(Integer.parseInt(this.txtTo.getText()));
/* 449 */       fillToTable();
/* 450 */     } catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */   
/*     */   private void txtTypeKeyReleased(KeyEvent evt) {
/*     */     try {
/* 456 */       this.drawMapScr.effChose.setType(Integer.parseInt(this.txtType.getText()));
/* 457 */       fillToTable();
/* 458 */     } catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */   
/*     */   public void readTextMob(String data) {
/*     */     try {
/* 464 */       this.model1.setRowCount(0);
/* 465 */       this.drawMapScr.mobs.clear();
/* 466 */       JSONValue jv = new JSONValue();
/* 467 */       JSONArray dataArray = null;
/* 468 */       dataArray = (JSONArray)JSONValue.parse(data);
/* 469 */       for (int j = 0; j < dataArray.size(); j++) {
/* 470 */         JSONArray dtm = (JSONArray)JSONValue.parse(String.valueOf(dataArray.get(j)));
/* 471 */         int temp = Byte.parseByte(String.valueOf(dtm.get(0)));
/* 472 */         int level = Byte.parseByte(String.valueOf(dtm.get(1)));
/* 473 */         int hp = Integer.parseInt(String.valueOf(dtm.get(2)));
/* 474 */         int x = Short.parseShort(String.valueOf(dtm.get(3)));
/* 475 */         int y = Short.parseShort(String.valueOf(dtm.get(4)));
/* 476 */         this.drawMapScr.mobs.add(new MobMap(Manager.gI().getMobTemplates().get(temp), x, y, level, hp));
/* 477 */         dtm.clear();
/*     */       } 
/* 479 */       fillToTable();
/* 480 */     } catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void fillToTable() {
/* 487 */     this.model1.setRowCount(0);
/*     */     try {
/* 489 */       for (EffectMap eff : this.drawMapScr.effectMaps) {
/* 490 */         this.model1.addRow(new Object[] {
/* 491 */               Integer.valueOf(eff.getTemp().getId()), Integer.valueOf(eff.getTemp().getId()), Integer.valueOf(eff.getX()), Integer.valueOf(eff.getY()), Integer.valueOf(eff.getLayer()), 
/* 492 */               Integer.valueOf(eff.getLoop()), Integer.valueOf(eff.getLoopCount()), Integer.valueOf(eff.getIndexFrom()), Integer.valueOf(eff.getIndexTo()), Integer.valueOf(eff.getType())
/*     */             });
/*     */       } 
/* 495 */       for (SubEffectMap eff : this.drawMapScr.subEffectMaps) {
/* 496 */         this.model1.addRow(new Object[] {
/* 497 */               Integer.valueOf(eff.getTypeEff()), "beff-" + eff.getTypeEff()
/*     */             });
/*     */       } 
/* 500 */     } catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void setup() {
/* 506 */     setResizable(false);
/* 507 */     setLocationRelativeTo(null);
/*     */     
/* 509 */     this.model1 = new DefaultTableModel((Object[])new String[] { "ID", "Image", "x", "y", "Layer", "Loop", "Loop count", "From", "To", "Type" }, 0)
/*     */       {
/*     */         public boolean isCellEditable(int row, int column) {
/* 512 */           return false;
/*     */         }
/*     */       };
/* 515 */     this.tbl1.setModel(this.model1);
/* 516 */     this.tbl1.setRowHeight(50);
/* 517 */     this.tbl1.getColumnModel().getColumn(1).setCellRenderer(new ImageRender());
/* 518 */     fillToTable();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class ImageRender
/*     */     extends DefaultTableCellRenderer
/*     */   {
/*     */     private ImageRender() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
/* 548 */       ImageIcon icon = null;
/* 549 */       String vl = value.toString();
/*     */       try {
/* 551 */         Image image = null;
/* 552 */         if (vl.startsWith("beff-")) {
/* 553 */           image = Util.getImageBEffectByType(Integer.parseInt(vl.replaceAll("beff-", "")));
/* 554 */           image = image.getScaledInstance(40, 40, 4);
/*     */         } else {
/* 556 */           image = Util.getImageEffectById(Integer.parseInt(vl));
/* 557 */           image = image.getScaledInstance(40, 40, 4);
/*     */         } 
/* 559 */         icon = new ImageIcon(image);
/* 560 */       } catch (Exception ex) {
/* 561 */         ex.printStackTrace();
/* 562 */         return new JLabel(vl);
/*     */       } 
/* 564 */       return new JLabel(icon);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\nro\server_luxu_nrp\vemap\GirlkunToolCBRO.jar!\com\girlkun\tool\screens\draw_map_scr\EffectList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */