package com.girlkun.tool.screens.draw_map_scr;

import java.awt.event.KeyEvent;

public interface InputDrawMap {
  void keyPress(KeyEvent paramKeyEvent);
  
  void keyRelease(KeyEvent paramKeyEvent);
}


/* Location:              D:\nro\server_luxu_nrp\vemap\GirlkunToolCBRO.jar!\com\girlkun\tool\screens\draw_map_scr\InputDrawMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */