/*     */ package com.girlkun.tool.screens.draw_map_scr;
/*     */ import com.girlkun.button.Button;
/*     */ import com.girlkun.tool.screens.draw_map_scr.models.Waypoint;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Font;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.KeyAdapter;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import javax.swing.GroupLayout;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.JTextArea;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.LayoutStyle;
/*     */ import javax.swing.table.DefaultTableModel;
/*     */ import org.json.simple.JSONArray;
/*     */ import org.json.simple.JSONValue;
/*     */ 
/*     */ public class WaypointList extends JFrame {
/*     */   private DrawMapScr drawMapScr;
/*     */   private DefaultTableModel model1;
/*     */   private int index;
/*     */   private Button button1;
/*     */   private Button button2;
/*     */   private Button button3;
/*     */   private JCheckBox chkEnter;
/*     */   private JCheckBox chkOffline;
/*     */   private JLabel jLabel1;
/*     */   private JLabel jLabel2;
/*     */   private JLabel jLabel3;
/*     */   private JLabel jLabel4;
/*     */   private JLabel jLabel5;
/*     */   private JLabel jLabel6;
/*     */   
/*     */   public WaypointList(DrawMapScr drawMapScr) {
/*  43 */     this.drawMapScr = drawMapScr;
/*  44 */     initComponents();
/*  45 */     setup();
/*  46 */     setDefaultCloseOperation(2);
/*  47 */     setTitle("Girlkun75 - List mob map");
/*  48 */     setAlwaysOnTop(true);
/*     */   }
/*     */   private JLabel jLabel7; private JLabel jLabel8; private JScrollPane jScrollPane1; private JScrollPane jScrollPane2; private JTable tbl1;
/*     */   private JTextField txtGoX;
/*     */   private JTextField txtGoY;
/*     */   
/*     */   private void initComponents() {
/*  55 */     this.jScrollPane2 = new JScrollPane();
/*  56 */     this.tbl1 = new JTable();
/*  57 */     this.button1 = new Button();
/*  58 */     this.button2 = new Button();
/*  59 */     this.jScrollPane1 = new JScrollPane();
/*  60 */     this.txtText = new JTextArea();
/*  61 */     this.jLabel1 = new JLabel();
/*  62 */     this.txtName = new JTextField();
/*  63 */     this.txtMapgo = new JTextField();
/*  64 */     this.jLabel3 = new JLabel();
/*  65 */     this.txtGoX = new JTextField();
/*  66 */     this.jLabel4 = new JLabel();
/*  67 */     this.txtGoY = new JTextField();
/*  68 */     this.jLabel5 = new JLabel();
/*  69 */     this.chkEnter = new JCheckBox();
/*  70 */     this.chkOffline = new JCheckBox();
/*  71 */     this.txtX = new JTextField();
/*  72 */     this.jLabel2 = new JLabel();
/*  73 */     this.jLabel6 = new JLabel();
/*  74 */     this.txtY = new JTextField();
/*  75 */     this.txtW = new JTextField();
/*  76 */     this.jLabel7 = new JLabel();
/*  77 */     this.jLabel8 = new JLabel();
/*  78 */     this.txtH = new JTextField();
/*  79 */     this.button3 = new Button();
/*     */     
/*  81 */     setDefaultCloseOperation(3);
/*     */     
/*  83 */     this.tbl1.setModel(new DefaultTableModel(new Object[0][], (Object[])new String[0]));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  91 */     this.tbl1.setSelectionMode(0);
/*  92 */     this.tbl1.addMouseListener(new MouseAdapter() {
/*     */           public void mouseClicked(MouseEvent evt) {
/*  94 */             WaypointList.this.tbl1MouseClicked(evt);
/*     */           }
/*     */         });
/*  97 */     this.tbl1.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/*  99 */             WaypointList.this.tbl1KeyPressed(evt);
/*     */           }
/*     */           public void keyReleased(KeyEvent evt) {
/* 102 */             WaypointList.this.tbl1KeyReleased(evt);
/*     */           }
/*     */         });
/* 105 */     this.jScrollPane2.setViewportView(this.tbl1);
/*     */     
/* 107 */     this.button1.setBackground(new Color(255, 0, 0));
/* 108 */     this.button1.setForeground(new Color(255, 255, 255));
/* 109 */     this.button1.setText("Clear all");
/* 110 */     this.button1.setFont(new Font("SansSerif", 1, 14));
/* 111 */     this.button1.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/* 113 */             WaypointList.this.button1ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     
/* 117 */     this.button2.setBackground(new Color(0, 204, 0));
/* 118 */     this.button2.setForeground(new Color(255, 255, 255));
/* 119 */     this.button2.setText("Save");
/* 120 */     this.button2.setFont(new Font("SansSerif", 1, 14));
/* 121 */     this.button2.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/* 123 */             WaypointList.this.button2ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     
/* 127 */     this.txtText.setColumns(20);
/* 128 */     this.txtText.setFont(new Font("SansSerif", 1, 14));
/* 129 */     this.txtText.setLineWrap(true);
/* 130 */     this.txtText.setRows(5);
/* 131 */     this.txtText.setWrapStyleWord(true);
/* 132 */     this.txtText.addKeyListener(new KeyAdapter() {
/*     */           public void keyReleased(KeyEvent evt) {
/* 134 */             WaypointList.this.txtTextKeyReleased(evt);
/*     */           }
/*     */         });
/* 137 */     this.jScrollPane1.setViewportView(this.txtText);
/*     */     
/* 139 */     this.jLabel1.setFont(new Font("SansSerif", 1, 12));
/* 140 */     this.jLabel1.setText("Name");
/*     */     
/* 142 */     this.txtName.setFont(new Font("SansSerif", 1, 12));
/* 143 */     this.txtName.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/* 145 */             WaypointList.this.txtNameKeyPressed(evt);
/*     */           }
/*     */           public void keyReleased(KeyEvent evt) {
/* 148 */             WaypointList.this.txtNameKeyReleased(evt);
/*     */           }
/*     */         });
/*     */     
/* 152 */     this.txtMapgo.setFont(new Font("SansSerif", 1, 12));
/* 153 */     this.txtMapgo.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/* 155 */             WaypointList.this.txtMapgoKeyPressed(evt);
/*     */           }
/*     */           public void keyReleased(KeyEvent evt) {
/* 158 */             WaypointList.this.txtMapgoKeyReleased(evt);
/*     */           }
/*     */         });
/*     */     
/* 162 */     this.jLabel3.setFont(new Font("SansSerif", 1, 12));
/* 163 */     this.jLabel3.setText("Map go");
/*     */     
/* 165 */     this.txtGoX.setFont(new Font("SansSerif", 1, 12));
/* 166 */     this.txtGoX.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/* 168 */             WaypointList.this.txtGoXKeyPressed(evt);
/*     */           }
/*     */           public void keyReleased(KeyEvent evt) {
/* 171 */             WaypointList.this.txtGoXKeyReleased(evt);
/*     */           }
/*     */         });
/*     */     
/* 175 */     this.jLabel4.setFont(new Font("SansSerif", 1, 12));
/* 176 */     this.jLabel4.setText("Go x");
/*     */     
/* 178 */     this.txtGoY.setFont(new Font("SansSerif", 1, 12));
/* 179 */     this.txtGoY.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/* 181 */             WaypointList.this.txtGoYKeyPressed(evt);
/*     */           }
/*     */           public void keyReleased(KeyEvent evt) {
/* 184 */             WaypointList.this.txtGoYKeyReleased(evt);
/*     */           }
/*     */         });
/*     */     
/* 188 */     this.jLabel5.setFont(new Font("SansSerif", 1, 12));
/* 189 */     this.jLabel5.setText("Go y");
/*     */     
/* 191 */     this.chkEnter.setFont(new Font("SansSerif", 1, 12));
/* 192 */     this.chkEnter.setText("Is enter");
/* 193 */     this.chkEnter.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/* 195 */             WaypointList.this.chkEnterActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     
/* 199 */     this.chkOffline.setFont(new Font("SansSerif", 1, 12));
/* 200 */     this.chkOffline.setText("Is offline");
/* 201 */     this.chkOffline.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/* 203 */             WaypointList.this.chkOfflineActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     
/* 207 */     this.txtX.setFont(new Font("SansSerif", 1, 12));
/* 208 */     this.txtX.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/* 210 */             WaypointList.this.txtXKeyPressed(evt);
/*     */           }
/*     */           public void keyReleased(KeyEvent evt) {
/* 213 */             WaypointList.this.txtXKeyReleased(evt);
/*     */           }
/*     */         });
/*     */     
/* 217 */     this.jLabel2.setFont(new Font("SansSerif", 1, 12));
/* 218 */     this.jLabel2.setText("X");
/*     */     
/* 220 */     this.jLabel6.setFont(new Font("SansSerif", 1, 12));
/* 221 */     this.jLabel6.setText("Y");
/*     */     
/* 223 */     this.txtY.setFont(new Font("SansSerif", 1, 12));
/* 224 */     this.txtY.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/* 226 */             WaypointList.this.txtYKeyPressed(evt);
/*     */           }
/*     */           public void keyReleased(KeyEvent evt) {
/* 229 */             WaypointList.this.txtYKeyReleased(evt);
/*     */           }
/*     */         });
/*     */     
/* 233 */     this.txtW.setFont(new Font("SansSerif", 1, 12));
/* 234 */     this.txtW.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/* 236 */             WaypointList.this.txtWKeyPressed(evt);
/*     */           }
/*     */           public void keyReleased(KeyEvent evt) {
/* 239 */             WaypointList.this.txtWKeyReleased(evt);
/*     */           }
/*     */         });
/*     */     
/* 243 */     this.jLabel7.setFont(new Font("SansSerif", 1, 12));
/* 244 */     this.jLabel7.setText("Width");
/*     */     
/* 246 */     this.jLabel8.setFont(new Font("SansSerif", 1, 12));
/* 247 */     this.jLabel8.setText("Height");
/*     */     
/* 249 */     this.txtH.setFont(new Font("SansSerif", 1, 12));
/* 250 */     this.txtH.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/* 252 */             WaypointList.this.txtHKeyPressed(evt);
/*     */           }
/*     */           public void keyReleased(KeyEvent evt) {
/* 255 */             WaypointList.this.txtHKeyReleased(evt);
/*     */           }
/*     */         });
/*     */     
/* 259 */     this.button3.setBackground(new Color(255, 0, 0));
/* 260 */     this.button3.setForeground(new Color(255, 255, 255));
/* 261 */     this.button3.setText("Remove");
/* 262 */     this.button3.setFont(new Font("SansSerif", 1, 14));
/* 263 */     this.button3.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/* 265 */             WaypointList.this.button3ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     
/* 269 */     GroupLayout layout = new GroupLayout(getContentPane());
/* 270 */     getContentPane().setLayout(layout);
/* 271 */     layout.setHorizontalGroup(layout
/* 272 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 273 */         .addGroup(layout.createSequentialGroup()
/* 274 */           .addComponent(this.jScrollPane2, -2, 423, -2)
/* 275 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 276 */           .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 277 */             .addGroup(GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
/* 278 */               .addGap(0, 61, 32767)
/* 279 */               .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 280 */                 .addComponent(this.chkOffline, -2, 304, -2)
/* 281 */                 .addComponent(this.chkEnter, -2, 304, -2))
/* 282 */               .addContainerGap())
/* 283 */             .addGroup(layout.createSequentialGroup()
/* 284 */               .addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false)
/* 285 */                 .addComponent(this.jLabel3, -1, -1, 32767)
/* 286 */                 .addComponent(this.jLabel1, -1, 55, 32767)
/* 287 */                 .addComponent(this.jLabel4, -1, -1, 32767)
/* 288 */                 .addComponent(this.jLabel5, -1, -1, 32767)
/* 289 */                 .addComponent(this.jLabel2, -1, 55, 32767)
/* 290 */                 .addComponent(this.jLabel6, -1, 55, 32767))
/* 291 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 292 */               .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 293 */                 .addComponent((Component)this.button1, GroupLayout.Alignment.TRAILING, -1, -1, 32767)
/* 294 */                 .addComponent((Component)this.button2, GroupLayout.Alignment.TRAILING, -1, -1, 32767)
/* 295 */                 .addComponent(this.txtGoX)
/* 296 */                 .addComponent(this.txtGoY)
/* 297 */                 .addComponent(this.txtName)
/* 298 */                 .addGroup(layout.createSequentialGroup()
/* 299 */                   .addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false)
/* 300 */                     .addComponent(this.txtY, GroupLayout.Alignment.LEADING, -1, 103, 32767)
/* 301 */                     .addComponent(this.txtX, GroupLayout.Alignment.LEADING))
/* 302 */                   .addGap(26, 26, 26)
/* 303 */                   .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 304 */                     .addGroup(layout.createSequentialGroup()
/* 305 */                       .addComponent(this.jLabel8, -2, 36, -2)
/* 306 */                       .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 307 */                       .addComponent(this.txtH))
/* 308 */                     .addGroup(layout.createSequentialGroup()
/* 309 */                       .addComponent(this.jLabel7, -2, 36, -2)
/* 310 */                       .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 311 */                       .addComponent(this.txtW))))
/* 312 */                 .addComponent(this.txtMapgo)
/* 313 */                 .addComponent((Component)this.button3, GroupLayout.Alignment.TRAILING, -1, -1, 32767)))))
/* 314 */         .addComponent(this.jScrollPane1));
/*     */     
/* 316 */     layout.setVerticalGroup(layout
/* 317 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 318 */         .addGroup(layout.createSequentialGroup()
/* 319 */           .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 320 */             .addGroup(layout.createSequentialGroup()
/* 321 */               .addContainerGap()
/* 322 */               .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 323 */                 .addComponent(this.txtName, -1, 42, 32767)
/* 324 */                 .addComponent(this.jLabel1, -2, 42, -2))
/* 325 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 326 */               .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 327 */                 .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 328 */                   .addComponent(this.txtX)
/* 329 */                   .addComponent(this.jLabel7, -2, 42, -2)
/* 330 */                   .addComponent(this.txtW, -2, 42, -2))
/* 331 */                 .addComponent(this.jLabel2, -2, 42, -2))
/* 332 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 333 */               .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 334 */                 .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 335 */                   .addComponent(this.txtY)
/* 336 */                   .addComponent(this.jLabel8, -2, 42, -2)
/* 337 */                   .addComponent(this.txtH, -2, 42, -2))
/* 338 */                 .addComponent(this.jLabel6, -2, 42, -2))
/* 339 */               .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
/* 340 */               .addComponent(this.chkEnter)
/* 341 */               .addGap(4, 4, 4)
/* 342 */               .addComponent(this.chkOffline)
/* 343 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 344 */               .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 345 */                 .addComponent(this.jLabel3, -2, 42, -2)
/* 346 */                 .addComponent(this.txtMapgo))
/* 347 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 348 */               .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 349 */                 .addComponent(this.jLabel4, -2, 42, -2)
/* 350 */                 .addComponent(this.txtGoX))
/* 351 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 352 */               .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 353 */                 .addComponent(this.jLabel5, -2, 42, -2)
/* 354 */                 .addComponent(this.txtGoY))
/* 355 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 356 */               .addComponent((Component)this.button2, -2, 36, -2)
/* 357 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 358 */               .addComponent((Component)this.button3, -2, 36, -2)
/* 359 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 360 */               .addComponent((Component)this.button1, -2, 36, -2))
/* 361 */             .addComponent(this.jScrollPane2))
/* 362 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 363 */           .addComponent(this.jScrollPane1, -2, -1, -2)
/* 364 */           .addContainerGap()));
/*     */ 
/*     */     
/* 367 */     layout.linkSize(1, new Component[] { this.chkEnter, this.chkOffline });
/*     */     
/* 369 */     layout.linkSize(1, new Component[] { this.txtGoX, this.txtGoY, this.txtMapgo, this.txtName });
/*     */     
/* 371 */     layout.linkSize(1, new Component[] { this.txtH, this.txtX, this.txtY });
/*     */     
/* 373 */     pack();
/*     */   }
/*     */   private JTextField txtH; private JTextField txtMapgo; private JTextField txtName; private JTextArea txtText; private JTextField txtW; private JTextField txtX; private JTextField txtY;
/*     */   private void tbl1MouseClicked(MouseEvent evt) {
/* 377 */     this.index = this.tbl1.getSelectedRow();
/* 378 */     if (this.index != -1) {
/* 379 */       this.drawMapScr.setWaypointChose(this.drawMapScr.waypoints.get(this.index));
/* 380 */       this.txtName.setText(this.drawMapScr.wpChose.getName());
/* 381 */       this.chkEnter.setSelected(this.drawMapScr.wpChose.isEnter());
/* 382 */       this.chkOffline.setSelected(this.drawMapScr.wpChose.isOffline());
/* 383 */       this.txtMapgo.setText(this.drawMapScr.wpChose.getMapGo() + "");
/* 384 */       this.txtGoX.setText(this.drawMapScr.wpChose.getGoX() + "");
/* 385 */       this.txtGoY.setText(this.drawMapScr.wpChose.getGoY() + "");
/* 386 */       this.txtX.setText(this.drawMapScr.wpChose.getX() + "");
/* 387 */       this.txtY.setText(this.drawMapScr.wpChose.getY() + "");
/* 388 */       this.txtW.setText(this.drawMapScr.wpChose.getW() + "");
/* 389 */       this.txtH.setText(this.drawMapScr.wpChose.getH() + "");
/*     */     } 
/*     */   }
/*     */   
/*     */   private void tbl1KeyPressed(KeyEvent evt) {
/* 394 */     this.index = this.tbl1.getSelectedRow();
/* 395 */     if (this.index != -1) {
/* 396 */       this.drawMapScr.setWaypointChose(this.drawMapScr.waypoints.get(this.index));
/* 397 */       this.txtName.setText(this.drawMapScr.wpChose.getName());
/* 398 */       this.chkEnter.setSelected(this.drawMapScr.wpChose.isEnter());
/* 399 */       this.chkOffline.setSelected(this.drawMapScr.wpChose.isOffline());
/* 400 */       this.txtMapgo.setText(this.drawMapScr.wpChose.getMapGo() + "");
/* 401 */       this.txtGoX.setText(this.drawMapScr.wpChose.getGoX() + "");
/* 402 */       this.txtGoY.setText(this.drawMapScr.wpChose.getGoY() + "");
/*     */       
/* 404 */       this.txtX.setText(this.drawMapScr.wpChose.getX() + "");
/* 405 */       this.txtY.setText(this.drawMapScr.wpChose.getY() + "");
/* 406 */       this.txtW.setText(this.drawMapScr.wpChose.getW() + "");
/* 407 */       this.txtH.setText(this.drawMapScr.wpChose.getH() + "");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void tbl1KeyReleased(KeyEvent evt) {
/* 413 */     this.index = this.tbl1.getSelectedRow();
/* 414 */     if (this.index != -1) {
/* 415 */       this.drawMapScr.setWaypointChose(this.drawMapScr.waypoints.get(this.index));
/* 416 */       this.txtName.setText(this.drawMapScr.wpChose.getName());
/* 417 */       this.chkEnter.setSelected(this.drawMapScr.wpChose.isEnter());
/* 418 */       this.chkOffline.setSelected(this.drawMapScr.wpChose.isOffline());
/* 419 */       this.txtMapgo.setText(this.drawMapScr.wpChose.getMapGo() + "");
/* 420 */       this.txtGoX.setText(this.drawMapScr.wpChose.getGoX() + "");
/* 421 */       this.txtGoY.setText(this.drawMapScr.wpChose.getGoY() + "");
/* 422 */       this.txtX.setText(this.drawMapScr.wpChose.getX() + "");
/* 423 */       this.txtY.setText(this.drawMapScr.wpChose.getY() + "");
/* 424 */       this.txtW.setText(this.drawMapScr.wpChose.getW() + "");
/* 425 */       this.txtH.setText(this.drawMapScr.wpChose.getH() + "");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void button1ActionPerformed(ActionEvent evt) {
/* 431 */     this.drawMapScr.waypoints.clear();
/* 432 */     fillToTable();
/*     */   }
/*     */   
/*     */   private void button2ActionPerformed(ActionEvent evt) {
/*     */     try {
/* 437 */       System.out.println(this.txtText.getText());
/* 438 */       GirlkunDB.executeUpdate("GIRLKUN", "update map_template set waypoints = ? where id = ?", new Object[] { this.txtText.getText(), Integer.valueOf(this.drawMapScr.mapId) });
/* 439 */       NotifyUtil.showMessageDialog(this, "Lưu thành công!");
/* 440 */     } catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void txtNameKeyPressed(KeyEvent evt) {}
/*     */ 
/*     */   
/*     */   private void txtNameKeyReleased(KeyEvent evt) {
/* 449 */     if (this.drawMapScr.wpChose != null) {
/*     */       try {
/* 451 */         this.drawMapScr.wpChose.setName(this.txtName.getText());
/* 452 */       } catch (Exception exception) {}
/*     */       
/* 454 */       fillToTable();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void txtMapgoKeyPressed(KeyEvent evt) {}
/*     */ 
/*     */   
/*     */   private void txtMapgoKeyReleased(KeyEvent evt) {
/* 463 */     if (this.drawMapScr.wpChose != null) {
/*     */       try {
/* 465 */         this.drawMapScr.wpChose.setMapGo(Integer.parseInt(this.txtMapgo.getText()));
/* 466 */       } catch (Exception exception) {}
/*     */       
/* 468 */       fillToTable();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void txtGoXKeyPressed(KeyEvent evt) {}
/*     */ 
/*     */   
/*     */   private void txtGoXKeyReleased(KeyEvent evt) {
/* 477 */     if (this.drawMapScr.wpChose != null) {
/*     */       try {
/* 479 */         this.drawMapScr.wpChose.setGoX(Integer.parseInt(this.txtGoX.getText()));
/* 480 */       } catch (Exception exception) {}
/*     */       
/* 482 */       fillToTable();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void txtGoYKeyPressed(KeyEvent evt) {}
/*     */ 
/*     */   
/*     */   private void txtGoYKeyReleased(KeyEvent evt) {
/* 491 */     if (this.drawMapScr.wpChose != null) {
/*     */       try {
/* 493 */         this.drawMapScr.wpChose.setGoY(Integer.parseInt(this.txtGoY.getText()));
/* 494 */       } catch (Exception exception) {}
/*     */       
/* 496 */       fillToTable();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void txtTextKeyReleased(KeyEvent evt) {
/* 501 */     if (evt.getKeyCode() == 10)
/* 502 */       readTextWaypoint(this.txtText.getText()); 
/*     */   }
/*     */   
/*     */   public void readTextWaypoint(String data) {
/*     */     try {
/* 507 */       this.model1.setRowCount(0);
/* 508 */       this.drawMapScr.waypoints.clear();
/* 509 */       JSONValue jv = new JSONValue();
/* 510 */       JSONArray dataArray = null;
/* 511 */       dataArray = (JSONArray)JSONValue.parse(data
/* 512 */           .replaceAll("\\[\"\\[", "[[")
/* 513 */           .replaceAll("\\]\"\\]", "]]")
/* 514 */           .replaceAll("\",\"", ","));
/* 515 */       for (int j = 0; j < dataArray.size(); j++) {
/* 516 */         JSONArray dtwp = (JSONArray)JSONValue.parse(String.valueOf(dataArray.get(j)));
/* 517 */         String name = String.valueOf(dtwp.get(0));
/* 518 */         int x = Short.parseShort(String.valueOf(dtwp.get(1)));
/* 519 */         int y = Short.parseShort(String.valueOf(dtwp.get(2)));
/* 520 */         int x1 = Short.parseShort(String.valueOf(dtwp.get(3)));
/* 521 */         int y1 = Short.parseShort(String.valueOf(dtwp.get(4)));
/* 522 */         boolean enter = (Byte.parseByte(String.valueOf(dtwp.get(5))) == 1);
/* 523 */         boolean off = (Byte.parseByte(String.valueOf(dtwp.get(6))) == 1);
/* 524 */         int goMap = Short.parseShort(String.valueOf(dtwp.get(7)));
/* 525 */         int goX = Short.parseShort(String.valueOf(dtwp.get(8)));
/* 526 */         int goY = Short.parseShort(String.valueOf(dtwp.get(9)));
/* 527 */         this.drawMapScr.waypoints.add(new Waypoint(name, x, y, x1 - x, y1 - y, enter, off, goMap, goX, goY));
/* 528 */         dtwp.clear();
/*     */       } 
/* 530 */       fillToTable();
/* 531 */     } catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */   
/*     */   private void chkEnterActionPerformed(ActionEvent evt) {
/* 536 */     if (this.drawMapScr.wpChose != null) {
/* 537 */       this.drawMapScr.wpChose.setEnter(this.chkEnter.isSelected());
/* 538 */       fillToTable();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void chkOfflineActionPerformed(ActionEvent evt) {
/* 543 */     if (this.drawMapScr.wpChose != null) {
/* 544 */       this.drawMapScr.wpChose.setOffline(this.chkOffline.isSelected());
/* 545 */       fillToTable();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void txtXKeyPressed(KeyEvent evt) {}
/*     */ 
/*     */   
/*     */   private void txtXKeyReleased(KeyEvent evt) {
/* 554 */     if (this.drawMapScr.wpChose != null) {
/*     */       try {
/* 556 */         this.drawMapScr.wpChose.setX(Integer.parseInt(this.txtX.getText()));
/* 557 */       } catch (Exception exception) {}
/*     */       
/* 559 */       fillToTable();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void txtYKeyPressed(KeyEvent evt) {}
/*     */ 
/*     */   
/*     */   private void txtYKeyReleased(KeyEvent evt) {
/* 568 */     if (this.drawMapScr.wpChose != null) {
/*     */       try {
/* 570 */         this.drawMapScr.wpChose.setY(Integer.parseInt(this.txtY.getText()));
/* 571 */       } catch (Exception exception) {}
/*     */       
/* 573 */       fillToTable();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void txtWKeyPressed(KeyEvent evt) {}
/*     */ 
/*     */   
/*     */   private void txtWKeyReleased(KeyEvent evt) {
/* 582 */     if (this.drawMapScr.wpChose != null) {
/*     */       try {
/* 584 */         this.drawMapScr.wpChose.setW(Integer.parseInt(this.txtW.getText()));
/* 585 */       } catch (Exception exception) {}
/*     */       
/* 587 */       fillToTable();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void txtHKeyPressed(KeyEvent evt) {}
/*     */ 
/*     */   
/*     */   private void txtHKeyReleased(KeyEvent evt) {
/* 596 */     if (this.drawMapScr.wpChose != null) {
/*     */       try {
/* 598 */         this.drawMapScr.wpChose.setH(Integer.parseInt(this.txtH.getText()));
/* 599 */       } catch (Exception exception) {}
/*     */       
/* 601 */       fillToTable();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void button3ActionPerformed(ActionEvent evt) {
/* 606 */     this.drawMapScr.waypoints.remove(this.drawMapScr.wpChose);
/* 607 */     fillToTable();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void fillToTable() {
/* 613 */     this.model1.setRowCount(0);
/*     */     
/* 615 */     JSONArray dataArray = new JSONArray();
/* 616 */     for (Waypoint wp : this.drawMapScr.waypoints) {
/* 617 */       JSONArray ja = new JSONArray();
/* 618 */       ja.add(wp.getName());
/* 619 */       ja.add(Integer.valueOf(wp.getX()));
/* 620 */       ja.add(Integer.valueOf(wp.getY()));
/* 621 */       ja.add(Integer.valueOf(wp.getW() + wp.getX()));
/* 622 */       ja.add(Integer.valueOf(wp.getH() + wp.getY()));
/* 623 */       ja.add(Integer.valueOf(wp.isEnter() ? 1 : 0));
/* 624 */       ja.add(Integer.valueOf(wp.isOffline() ? 1 : 0));
/* 625 */       ja.add(Integer.valueOf(wp.getMapGo()));
/* 626 */       ja.add(Integer.valueOf(wp.getGoX()));
/* 627 */       ja.add(Integer.valueOf(wp.getGoY()));
/* 628 */       dataArray.add(ja.toJSONString());
/* 629 */       this.model1.addRow(new Object[] { wp
/* 630 */             .getName(), Integer.valueOf(wp.getX()), Integer.valueOf(wp.getY()), Integer.valueOf(wp.getW()), Integer.valueOf(wp.getH()), Boolean.valueOf(wp.isEnter()), Boolean.valueOf(wp.isOffline()), Integer.valueOf(wp.getMapGo()), Integer.valueOf(wp.getGoX()), Integer.valueOf(wp.getGoY()) });
/*     */     } 
/*     */     
/* 633 */     this.txtText.setText(dataArray.toJSONString()
/* 634 */         .replaceAll("\\\\", "")
/* 635 */         .replaceAll("\\[\\\"\\[", "[[")
/* 636 */         .replaceAll("\\]\\\"\\,\\\"\\[", "],[")
/* 637 */         .replaceAll("\\]\\\"\\]", "]]"));
/*     */   }
/*     */ 
/*     */   
/*     */   private void setup() {
/* 642 */     setResizable(false);
/* 643 */     setLocationRelativeTo(null);
/*     */     
/* 645 */     this.model1 = new DefaultTableModel((Object[])new String[] { "Name", "X", "Y", "W", "H", "Enter", "Offline", "Map go", "GoX", "GoY" }, 0)
/*     */       {
/*     */         public boolean isCellEditable(int row, int column) {
/* 648 */           return false;
/*     */         }
/*     */       };
/* 651 */     this.tbl1.setModel(this.model1);
/* 652 */     fillToTable();
/*     */   }
/*     */ }


/* Location:              D:\nro\server_luxu_nrp\vemap\GirlkunToolCBRO.jar!\com\girlkun\tool\screens\draw_map_scr\WaypointList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */