/*    */ package com.girlkun.tool.screens.draw_map_scr.models;
/*    */ 
/*    */ import com.girlkun.tool.entities.map.NpcTemplate;
/*    */ import com.girlkun.tool.utils.CharInfo;
/*    */ import com.girlkun.tool.utils.Util;
/*    */ import java.awt.Graphics2D;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NpcMap
/*    */ {
/*    */   private NpcTemplate temp;
/*    */   private int x;
/*    */   private int y;
/*    */   private long lastTimeUpdate;
/*    */   
/*    */   public void setTemp(NpcTemplate temp) {
/* 20 */     this.temp = temp; } public void setX(int x) { this.x = x; } public void setY(int y) { this.y = y; } public void setLastTimeUpdate(long lastTimeUpdate) { this.lastTimeUpdate = lastTimeUpdate; } public void setTimeUpdate(int timeUpdate) { this.timeUpdate = timeUpdate; } public void setDY(int dY) { this.dY = dY; } public boolean equals(Object o) { if (o == this) return true;  if (!(o instanceof NpcMap)) return false;  NpcMap other = (NpcMap)o; if (!other.canEqual(this)) return false;  if (getX() != other.getX()) return false;  if (getY() != other.getY()) return false;  if (getLastTimeUpdate() != other.getLastTimeUpdate()) return false;  if (getTimeUpdate() != other.getTimeUpdate()) return false;  if (getDY() != other.getDY()) return false;  Object this$temp = getTemp(), other$temp = other.getTemp(); return !((this$temp == null) ? (other$temp != null) : !this$temp.equals(other$temp)); } protected boolean canEqual(Object other) { return other instanceof NpcMap; } public int hashCode() { int PRIME = 59; result = 1; result = result * 59 + getX(); result = result * 59 + getY(); long $lastTimeUpdate = getLastTimeUpdate(); result = result * 59 + (int)($lastTimeUpdate >>> 32L ^ $lastTimeUpdate); result = result * 59 + getTimeUpdate(); result = result * 59 + getDY(); Object $temp = getTemp(); return result * 59 + (($temp == null) ? 43 : $temp.hashCode()); } public String toString() { return "NpcMap(temp=" + getTemp() + ", x=" + getX() + ", y=" + getY() + ", lastTimeUpdate=" + getLastTimeUpdate() + ", timeUpdate=" + getTimeUpdate() + ", dY=" + getDY() + ")"; }
/*    */   
/*    */   public NpcTemplate getTemp() {
/* 23 */     return this.temp;
/*    */   } public int getX() {
/* 25 */     return this.x;
/*    */   } public int getY() {
/* 27 */     return this.y;
/*    */   } public long getLastTimeUpdate() {
/* 29 */     return this.lastTimeUpdate;
/* 30 */   } private int timeUpdate = 150; private int dY; public int getTimeUpdate() { return this.timeUpdate; } public int getDY() {
/* 31 */     return this.dY;
/*    */   }
/*    */   public NpcMap(NpcTemplate temp, int x, int y) {
/* 34 */     this.temp = temp;
/* 35 */     this.x = x;
/* 36 */     this.y = y;
/*    */   }
/*    */   
/*    */   public void paint(Graphics2D g, boolean changeColor) {
/* 40 */     if (Util.canDoLastTime(this.lastTimeUpdate, this.timeUpdate)) {
/* 41 */       this.lastTimeUpdate = System.currentTimeMillis();
/* 42 */       this.dY++;
/* 43 */       if (this.dY > 2) {
/* 44 */         this.dY = 0;
/*    */       }
/*    */     } 
/*    */     try {
/* 48 */       g.drawImage(changeColor ? Util.changeRed(this.temp.getILeg()) : this.temp.getILeg(), this.x + this.temp
/* 49 */           .getPLeg().getPi()[1].getDx(), this.y - CharInfo.CharInfo[0][1][2] + this.temp
/*    */ 
/*    */           
/* 52 */           .getPLeg().getPi()[1].getDy(), null);
/*    */ 
/*    */       
/* 55 */       g.drawImage(changeColor ? Util.changeRed(this.temp.getIBody()) : this.temp.getIBody(), this.x + this.temp
/* 56 */           .getPBody().getPi()[1].getDx(), this.y - CharInfo.CharInfo[0][2][2] + this.temp
/*    */           
/* 58 */           .getPBody().getPi()[1].getDy() + this.dY, null);
/*    */       
/* 60 */       g.drawImage(changeColor ? Util.changeRed(this.temp.getIHead()) : this.temp.getIHead(), this.x + this.temp
/* 61 */           .getPHead().getPi()[0].getDx() - 4, this.y - CharInfo.CharInfo[0][0][2] + this.temp
/*    */           
/* 63 */           .getPHead().getPi()[0].getDy() + this.dY, null);
/*    */     }
/* 65 */     catch (Exception exception) {}
/*    */   }
/*    */ }


/* Location:              D:\nro\server_luxu_nrp\vemap\GirlkunToolCBRO.jar!\com\girlkun\tool\screens\draw_map_scr\models\NpcMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */