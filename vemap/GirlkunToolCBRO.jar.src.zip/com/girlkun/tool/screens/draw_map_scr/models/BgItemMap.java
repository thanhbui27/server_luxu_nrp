/*    */ package com.girlkun.tool.screens.draw_map_scr.models;
/*    */ 
/*    */ import com.girlkun.tool.entities.map.BgItemTemplate;
/*    */ import com.girlkun.tool.screens.draw_map_scr.DrawMapScr;
/*    */ import com.girlkun.tool.utils.Util;
/*    */ import java.awt.Graphics2D;
/*    */ import java.awt.image.BufferedImage;
/*    */ 
/*    */ public class BgItemMap {
/*    */   private BgItemTemplate temp;
/*    */   private int x;
/*    */   private int y;
/*    */   
/*    */   public void setTemp(BgItemTemplate temp) {
/* 15 */     this.temp = temp; } public void setX(int x) { this.x = x; } public void setY(int y) { this.y = y; } public boolean equals(Object o) { if (o == this) return true;  if (!(o instanceof BgItemMap)) return false;  BgItemMap other = (BgItemMap)o; if (!other.canEqual(this)) return false;  if (getX() != other.getX()) return false;  if (getY() != other.getY()) return false;  Object this$temp = getTemp(), other$temp = other.getTemp(); return !((this$temp == null) ? (other$temp != null) : !this$temp.equals(other$temp)); } protected boolean canEqual(Object other) { return other instanceof BgItemMap; } public int hashCode() { int PRIME = 59; result = 1; result = result * 59 + getX(); result = result * 59 + getY(); Object $temp = getTemp(); return result * 59 + (($temp == null) ? 43 : $temp.hashCode()); } public String toString() { return "BgItemMap(temp=" + getTemp() + ", x=" + getX() + ", y=" + getY() + ")"; }
/*    */   
/*    */   public BgItemTemplate getTemp() {
/* 18 */     return this.temp;
/*    */   } public int getX() {
/* 20 */     return this.x;
/*    */   } public int getY() {
/* 22 */     return this.y;
/*    */   }
/*    */   public BgItemMap(BgItemTemplate temp, int x, int y) {
/* 25 */     this.temp = temp;
/* 26 */     this.x = x;
/* 27 */     this.y = y;
/*    */   }
/*    */   
/*    */   public void draw(Graphics2D g, DrawMapScr drawMapScr) {
/* 31 */     if (this.temp != null)
/* 32 */       if (this.temp.getLayer() == 4 && drawMapScr.is3D) {
/* 33 */         g.drawImage(this.temp.getImage(), this.x + this.temp.getDx() - drawMapScr.camera.camX / 10, this.y + this.temp.getDy(), null);
/*    */       } else {
/* 35 */         g.drawImage(this.temp.getImage(), this.x + this.temp.getDx(), this.y + this.temp.getDy(), null);
/* 36 */         if (this.temp.getLayer() == 1 && drawMapScr.isMapDouble) {
/* 37 */           BufferedImage image = this.temp.getImage();
/* 38 */           g.drawImage(Util.flipImageX(image), drawMapScr.mapWidth - this.x + this.temp.getDx() - image.getWidth(), this.y + this.temp.getDy(), null);
/*    */         } 
/*    */       }  
/*    */   }
/*    */ }


/* Location:              D:\nro\server_luxu_nrp\vemap\GirlkunToolCBRO.jar!\com\girlkun\tool\screens\draw_map_scr\models\BgItemMap.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */