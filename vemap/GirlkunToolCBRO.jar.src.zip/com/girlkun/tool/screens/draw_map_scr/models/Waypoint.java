/*    */ package com.girlkun.tool.screens.draw_map_scr.models;
/*    */ 
/*    */ public class Waypoint {
/*    */   private String name;
/*    */   private int x;
/*    */   private int y;
/*    */   private int w;
/*    */   private int h;
/*    */   
/*    */   public void setName(String name) {
/* 11 */     this.name = name; } private boolean enter; private boolean offline; private int mapGo; private int goX; private int goY; public void setX(int x) { this.x = x; } public void setY(int y) { this.y = y; } public void setW(int w) { this.w = w; } public void setH(int h) { this.h = h; } public void setEnter(boolean enter) { this.enter = enter; } public void setOffline(boolean offline) { this.offline = offline; } public void setMapGo(int mapGo) { this.mapGo = mapGo; } public void setGoX(int goX) { this.goX = goX; } public void setGoY(int goY) { this.goY = goY; } public boolean equals(Object o) { if (o == this) return true;  if (!(o instanceof Waypoint)) return false;  Waypoint other = (Waypoint)o; if (!other.canEqual(this)) return false;  if (getX() != other.getX()) return false;  if (getY() != other.getY()) return false;  if (getW() != other.getW()) return false;  if (getH() != other.getH()) return false;  if (isEnter() != other.isEnter()) return false;  if (isOffline() != other.isOffline()) return false;  if (getMapGo() != other.getMapGo()) return false;  if (getGoX() != other.getGoX()) return false;  if (getGoY() != other.getGoY()) return false;  Object this$name = getName(), other$name = other.getName(); return !((this$name == null) ? (other$name != null) : !this$name.equals(other$name)); } protected boolean canEqual(Object other) { return other instanceof Waypoint; } public int hashCode() { int PRIME = 59; result = 1; result = result * 59 + getX(); result = result * 59 + getY(); result = result * 59 + getW(); result = result * 59 + getH(); result = result * 59 + (isEnter() ? 79 : 97); result = result * 59 + (isOffline() ? 79 : 97); result = result * 59 + getMapGo(); result = result * 59 + getGoX(); result = result * 59 + getGoY(); Object $name = getName(); return result * 59 + (($name == null) ? 43 : $name.hashCode()); } public String toString() { return "Waypoint(name=" + getName() + ", x=" + getX() + ", y=" + getY() + ", w=" + getW() + ", h=" + getH() + ", enter=" + isEnter() + ", offline=" + isOffline() + ", mapGo=" + getMapGo() + ", goX=" + getGoX() + ", goY=" + getGoY() + ")"; } public Waypoint(String name, int x, int y, int w, int h, boolean enter, boolean offline, int mapGo, int goX, int goY) {
/* 12 */     this.name = name; this.x = x; this.y = y; this.w = w; this.h = h; this.enter = enter; this.offline = offline; this.mapGo = mapGo; this.goX = goX; this.goY = goY;
/*    */   }
/*    */   
/* 15 */   public String getName() { return this.name; }
/* 16 */   public int getX() { return this.x; }
/* 17 */   public int getY() { return this.y; }
/* 18 */   public int getW() { return this.w; }
/* 19 */   public int getH() { return this.h; }
/* 20 */   public boolean isEnter() { return this.enter; }
/* 21 */   public boolean isOffline() { return this.offline; }
/* 22 */   public int getMapGo() { return this.mapGo; }
/* 23 */   public int getGoX() { return this.goX; } public int getGoY() {
/* 24 */     return this.goY;
/*    */   }
/*    */ }


/* Location:              D:\nro\server_luxu_nrp\vemap\GirlkunToolCBRO.jar!\com\girlkun\tool\screens\draw_map_scr\models\Waypoint.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */