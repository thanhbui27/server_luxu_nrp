/*     */ package com.girlkun.tool.screens.draw_map_scr;
/*     */ import com.girlkun.button.Button;
/*     */ import com.girlkun.tool.screens.draw_map_scr.models.NpcMap;
/*     */ import com.girlkun.tool.utils.Util;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Font;
/*     */ import java.awt.Image;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.KeyAdapter;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import javax.swing.GroupLayout;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.JTextArea;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.LayoutStyle;
/*     */ import javax.swing.table.DefaultTableModel;
/*     */ import org.json.simple.JSONArray;
/*     */ import org.json.simple.JSONValue;
/*     */ 
/*     */ public class NpcList extends JFrame {
/*     */   private DrawMapScr drawMapScr;
/*     */   private DefaultTableModel model1;
/*     */   private int index;
/*     */   
/*     */   public NpcList(DrawMapScr drawMapScr) {
/*  33 */     this.drawMapScr = drawMapScr;
/*  34 */     initComponents();
/*  35 */     setup();
/*  36 */     setDefaultCloseOperation(2);
/*  37 */     setTitle("Girlkun75 - List npc map");
/*  38 */     setAlwaysOnTop(true);
/*     */   }
/*     */   private Button button1; private Button button2; private Button button3; private JLabel jLabel1; private JLabel jLabel2; private JScrollPane jScrollPane1; private JScrollPane jScrollPane2; private JTable tbl1; private JTextArea txtText;
/*     */   private JTextField txtX;
/*     */   private JTextField txtY;
/*     */   
/*     */   private void initComponents() {
/*  45 */     this.jScrollPane2 = new JScrollPane();
/*  46 */     this.tbl1 = new JTable();
/*  47 */     this.button1 = new Button();
/*  48 */     this.button2 = new Button();
/*  49 */     this.jScrollPane1 = new JScrollPane();
/*  50 */     this.txtText = new JTextArea();
/*  51 */     this.jLabel1 = new JLabel();
/*  52 */     this.txtX = new JTextField();
/*  53 */     this.txtY = new JTextField();
/*  54 */     this.jLabel2 = new JLabel();
/*  55 */     this.button3 = new Button();
/*     */     
/*  57 */     setDefaultCloseOperation(3);
/*     */     
/*  59 */     this.tbl1.setModel(new DefaultTableModel(new Object[0][], (Object[])new String[0]));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  67 */     this.tbl1.setSelectionMode(0);
/*  68 */     this.tbl1.addMouseListener(new MouseAdapter() {
/*     */           public void mouseClicked(MouseEvent evt) {
/*  70 */             NpcList.this.tbl1MouseClicked(evt);
/*     */           }
/*     */         });
/*  73 */     this.tbl1.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/*  75 */             NpcList.this.tbl1KeyPressed(evt);
/*     */           }
/*     */           public void keyReleased(KeyEvent evt) {
/*  78 */             NpcList.this.tbl1KeyReleased(evt);
/*     */           }
/*     */         });
/*  81 */     this.jScrollPane2.setViewportView(this.tbl1);
/*     */     
/*  83 */     this.button1.setBackground(new Color(255, 0, 0));
/*  84 */     this.button1.setForeground(new Color(255, 255, 255));
/*  85 */     this.button1.setText("Clear all");
/*  86 */     this.button1.setFont(new Font("SansSerif", 1, 14));
/*  87 */     this.button1.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/*  89 */             NpcList.this.button1ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     
/*  93 */     this.button2.setBackground(new Color(0, 204, 0));
/*  94 */     this.button2.setForeground(new Color(255, 255, 255));
/*  95 */     this.button2.setText("Save");
/*  96 */     this.button2.setFont(new Font("SansSerif", 1, 14));
/*  97 */     this.button2.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/*  99 */             NpcList.this.button2ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     
/* 103 */     this.txtText.setColumns(20);
/* 104 */     this.txtText.setFont(new Font("SansSerif", 1, 14));
/* 105 */     this.txtText.setLineWrap(true);
/* 106 */     this.txtText.setRows(5);
/* 107 */     this.txtText.setWrapStyleWord(true);
/* 108 */     this.txtText.addKeyListener(new KeyAdapter() {
/*     */           public void keyReleased(KeyEvent evt) {
/* 110 */             NpcList.this.txtTextKeyReleased(evt);
/*     */           }
/*     */         });
/* 113 */     this.jScrollPane1.setViewportView(this.txtText);
/*     */     
/* 115 */     this.jLabel1.setFont(new Font("SansSerif", 1, 12));
/* 116 */     this.jLabel1.setHorizontalAlignment(0);
/* 117 */     this.jLabel1.setText("X");
/*     */     
/* 119 */     this.txtX.setFont(new Font("SansSerif", 1, 12));
/* 120 */     this.txtX.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/* 122 */             NpcList.this.txtXKeyPressed(evt);
/*     */           }
/*     */           public void keyReleased(KeyEvent evt) {
/* 125 */             NpcList.this.txtXKeyReleased(evt);
/*     */           }
/*     */         });
/*     */     
/* 129 */     this.txtY.setFont(new Font("SansSerif", 1, 12));
/* 130 */     this.txtY.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/* 132 */             NpcList.this.txtYKeyPressed(evt);
/*     */           }
/*     */           public void keyReleased(KeyEvent evt) {
/* 135 */             NpcList.this.txtYKeyReleased(evt);
/*     */           }
/*     */         });
/*     */     
/* 139 */     this.jLabel2.setFont(new Font("SansSerif", 1, 12));
/* 140 */     this.jLabel2.setHorizontalAlignment(0);
/* 141 */     this.jLabel2.setText("Y");
/*     */     
/* 143 */     this.button3.setBackground(new Color(255, 0, 0));
/* 144 */     this.button3.setForeground(new Color(255, 255, 255));
/* 145 */     this.button3.setText("Remove");
/* 146 */     this.button3.setFont(new Font("SansSerif", 1, 14));
/* 147 */     this.button3.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/* 149 */             NpcList.this.button3ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     
/* 153 */     GroupLayout layout = new GroupLayout(getContentPane());
/* 154 */     getContentPane().setLayout(layout);
/* 155 */     layout.setHorizontalGroup(layout
/* 156 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 157 */         .addGroup(layout.createSequentialGroup()
/* 158 */           .addComponent(this.jScrollPane2, -2, 423, -2)
/* 159 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 160 */           .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 161 */             .addComponent((Component)this.button1, -1, 201, 32767)
/* 162 */             .addComponent((Component)this.button2, -1, 201, 32767)
/* 163 */             .addGroup(layout.createSequentialGroup()
/* 164 */               .addComponent(this.jLabel1, -2, 39, -2)
/* 165 */               .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
/* 166 */               .addComponent(this.txtX))
/* 167 */             .addGroup(layout.createSequentialGroup()
/* 168 */               .addComponent(this.jLabel2, -2, 39, -2)
/* 169 */               .addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
/* 170 */               .addComponent(this.txtY))
/* 171 */             .addComponent((Component)this.button3, -1, 201, 32767)))
/* 172 */         .addComponent(this.jScrollPane1));
/*     */     
/* 174 */     layout.setVerticalGroup(layout
/* 175 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 176 */         .addGroup(layout.createSequentialGroup()
/* 177 */           .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 178 */             .addComponent(this.jScrollPane2, -2, 274, -2)
/* 179 */             .addGroup(layout.createSequentialGroup()
/* 180 */               .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 181 */                 .addComponent(this.jLabel1, -1, -1, 32767)
/* 182 */                 .addComponent(this.txtX, -1, 38, 32767))
/* 183 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 184 */               .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 185 */                 .addComponent(this.jLabel2, -1, -1, 32767)
/* 186 */                 .addComponent(this.txtY, -1, 38, 32767))
/* 187 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, -1, 32767)
/* 188 */               .addComponent((Component)this.button2, -2, 36, -2)
/* 189 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 190 */               .addComponent((Component)this.button3, -2, 36, -2)
/* 191 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 192 */               .addComponent((Component)this.button1, -2, 36, -2)))
/* 193 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 194 */           .addComponent(this.jScrollPane1, -2, -1, -2)));
/*     */ 
/*     */     
/* 197 */     pack();
/*     */   }
/*     */   
/*     */   private void tbl1MouseClicked(MouseEvent evt) {
/* 201 */     this.index = this.tbl1.getSelectedRow();
/* 202 */     if (this.index != -1) {
/* 203 */       this.drawMapScr.setNpcMapChose(this.drawMapScr.npcs.get(this.index));
/* 204 */       this.txtX.setText(((NpcMap)this.drawMapScr.npcs.get(this.index)).getX() + "");
/* 205 */       this.txtY.setText(((NpcMap)this.drawMapScr.npcs.get(this.index)).getY() + "");
/*     */     } 
/*     */   }
/*     */   
/*     */   private void tbl1KeyPressed(KeyEvent evt) {
/* 210 */     this.index = this.tbl1.getSelectedRow();
/* 211 */     if (this.index != -1) {
/* 212 */       this.drawMapScr.setNpcMapChose(this.drawMapScr.npcs.get(this.index));
/* 213 */       this.txtX.setText(((NpcMap)this.drawMapScr.npcs.get(this.index)).getX() + "");
/* 214 */       this.txtY.setText(((NpcMap)this.drawMapScr.npcs.get(this.index)).getY() + "");
/*     */     } 
/*     */   }
/*     */   
/*     */   private void tbl1KeyReleased(KeyEvent evt) {
/* 219 */     this.index = this.tbl1.getSelectedRow();
/* 220 */     if (this.index != -1) {
/* 221 */       this.drawMapScr.setNpcMapChose(this.drawMapScr.npcs.get(this.index));
/* 222 */       this.txtX.setText(((NpcMap)this.drawMapScr.npcs.get(this.index)).getX() + "");
/* 223 */       this.txtY.setText(((NpcMap)this.drawMapScr.npcs.get(this.index)).getY() + "");
/*     */     } 
/*     */   }
/*     */   
/*     */   private void button1ActionPerformed(ActionEvent evt) {
/* 228 */     this.drawMapScr.npcs.clear();
/* 229 */     fillToTable();
/*     */   }
/*     */   
/*     */   private void button2ActionPerformed(ActionEvent evt) {
/*     */     try {
/* 234 */       System.out.println(this.txtText.getText());
/* 235 */       GirlkunDB.executeUpdate("GIRLKUN", "update map_template set npcs = ? where id = ?", new Object[] { this.txtText.getText(), Integer.valueOf(this.drawMapScr.mapId) });
/* 236 */       NotifyUtil.showMessageDialog(this, "Lưu thành công!");
/* 237 */     } catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */   
/*     */   public void readDataNpc(String data) {
/*     */     try {
/* 243 */       this.model1.setRowCount(0);
/* 244 */       this.drawMapScr.npcs.clear();
/* 245 */       JSONValue jv = new JSONValue();
/* 246 */       JSONArray dataArray = null;
/* 247 */       dataArray = (JSONArray)JSONValue.parse(data);
/* 248 */       for (int j = 0; j < dataArray.size(); j++) {
/* 249 */         JSONArray dtn = (JSONArray)JSONValue.parse(String.valueOf(dataArray.get(j)));
/* 250 */         int temp = Byte.parseByte(String.valueOf(dtn.get(0)));
/* 251 */         int x = Short.parseShort(String.valueOf(dtn.get(1)));
/* 252 */         int y = Short.parseShort(String.valueOf(dtn.get(2)));
/* 253 */         this.drawMapScr.npcs.add(new NpcMap(Manager.gI().getNpcTemplateById(temp), x, y));
/* 254 */         dtn.clear();
/*     */       } 
/* 256 */       fillToTable();
/* 257 */     } catch (Exception exception) {}
/*     */   }
/*     */   
/*     */   private void txtTextKeyReleased(KeyEvent evt) {
/* 261 */     if (evt.getKeyCode() == 10) {
/* 262 */       readDataNpc(this.txtText.getText());
/*     */     }
/*     */   }
/*     */   
/*     */   private void txtXKeyPressed(KeyEvent evt) {
/*     */     try {
/* 268 */       ((NpcMap)this.drawMapScr.npcs.get(this.index)).setX(Integer.parseInt(this.txtX.getText()));
/* 269 */       fillToTable();
/* 270 */     } catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */   
/*     */   private void txtXKeyReleased(KeyEvent evt) {
/*     */     try {
/* 276 */       ((NpcMap)this.drawMapScr.npcs.get(this.index)).setX(Integer.parseInt(this.txtX.getText()));
/* 277 */       fillToTable();
/* 278 */     } catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */   
/*     */   private void txtYKeyPressed(KeyEvent evt) {
/*     */     try {
/* 284 */       ((NpcMap)this.drawMapScr.npcs.get(this.index)).setY(Integer.parseInt(this.txtY.getText()));
/* 285 */       fillToTable();
/* 286 */     } catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */   
/*     */   private void txtYKeyReleased(KeyEvent evt) {
/*     */     try {
/* 292 */       ((NpcMap)this.drawMapScr.npcs.get(this.index)).setY(Integer.parseInt(this.txtY.getText()));
/* 293 */       fillToTable();
/* 294 */     } catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void button3ActionPerformed(ActionEvent evt) {
/* 300 */     this.drawMapScr.npcs.remove(this.drawMapScr.npcMapChose);
/* 301 */     fillToTable();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void fillToTable() {
/* 307 */     this.model1.setRowCount(0);
/*     */     
/* 309 */     JSONArray dataArray = new JSONArray();
/* 310 */     for (NpcMap npc : this.drawMapScr.npcs) {
/* 311 */       JSONArray ja = new JSONArray();
/* 312 */       ja.add(Integer.valueOf(npc.getTemp().getId()));
/* 313 */       ja.add(Integer.valueOf(npc.getX()));
/* 314 */       ja.add(Integer.valueOf(npc.getY()));
/* 315 */       dataArray.add(ja.toJSONString());
/* 316 */       this.model1.addRow(new Object[] {
/* 317 */             Integer.valueOf(npc.getTemp().getId()), npc.getTemp().getName(), Integer.valueOf(npc.getTemp().getAvatar()), Integer.valueOf(npc.getX()), Integer.valueOf(npc.getY())
/*     */           });
/*     */     } 
/* 320 */     this.txtText.setText(dataArray.toJSONString()
/* 321 */         .replaceAll("\\\\", "")
/* 322 */         .replaceAll("\\[\\\"\\[", "[[")
/* 323 */         .replaceAll("\\]\\\"\\,\\\"\\[", "],[")
/* 324 */         .replaceAll("\\]\\\"\\]", "]]"));
/*     */   }
/*     */   
/*     */   private void setup() {
/* 328 */     setResizable(false);
/* 329 */     setLocationRelativeTo(null);
/*     */     
/* 331 */     this.model1 = new DefaultTableModel((Object[])new String[] { "ID", "Name", "Avatar", "x", "y" }, 0)
/*     */       {
/*     */         public boolean isCellEditable(int row, int column) {
/* 334 */           return false;
/*     */         }
/*     */       };
/* 337 */     this.tbl1.setModel(this.model1);
/* 338 */     this.tbl1.setRowHeight(50);
/* 339 */     this.tbl1.getColumnModel().getColumn(2).setCellRenderer(new ImageRender());
/* 340 */     fillToTable();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class ImageRender
/*     */     extends DefaultTableCellRenderer
/*     */   {
/*     */     private ImageRender() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
/* 384 */       ImageIcon icon = null;
/*     */       try {
/* 386 */         String id = value.toString();
/* 387 */         Image image = Util.getImageById(Integer.parseInt(id), 2);
/* 388 */         image = image.getScaledInstance(40, 40, 4);
/* 389 */         icon = new ImageIcon(image);
/* 390 */       } catch (Exception exception) {}
/*     */       
/* 392 */       return new JLabel(icon);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\nro\server_luxu_nrp\vemap\GirlkunToolCBRO.jar!\com\girlkun\tool\screens\draw_map_scr\NpcList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */