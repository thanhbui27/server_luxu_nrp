/*     */ package com.girlkun.tool.screens.draw_map_scr;
/*     */ 
/*     */ import com.girlkun.tool.entities.map.NpcTemplate;
/*     */ import com.girlkun.tool.main.Manager;
/*     */ import com.girlkun.tool.utils.Util;
/*     */ import java.awt.Component;
/*     */ import java.awt.EventQueue;
/*     */ import java.awt.Image;
/*     */ import java.awt.event.KeyAdapter;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.swing.GroupLayout;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.UnsupportedLookAndFeelException;
/*     */ import javax.swing.table.DefaultTableCellRenderer;
/*     */ import javax.swing.table.DefaultTableModel;
/*     */ 
/*     */ public class NpcTable extends JFrame {
/*     */   private DrawMapScr drawMapScr;
/*     */   private DefaultTableModel model1;
/*     */   private JScrollPane jScrollPane2;
/*     */   private JTable tbl1;
/*     */   
/*     */   public NpcTable(DrawMapScr drawMapScr) {
/*  33 */     this.drawMapScr = drawMapScr;
/*  34 */     initComponents();
/*  35 */     setup();
/*  36 */     setDefaultCloseOperation(2);
/*  37 */     setTitle("Girlkun75 - Npc template");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initComponents() {
/*  44 */     this.jScrollPane2 = new JScrollPane();
/*  45 */     this.tbl1 = new JTable();
/*     */     
/*  47 */     setDefaultCloseOperation(3);
/*     */     
/*  49 */     this.tbl1.setModel(new DefaultTableModel(new Object[0][], (Object[])new String[0]));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  57 */     this.tbl1.setSelectionMode(0);
/*  58 */     this.tbl1.addMouseListener(new MouseAdapter() {
/*     */           public void mouseClicked(MouseEvent evt) {
/*  60 */             NpcTable.this.tbl1MouseClicked(evt);
/*     */           }
/*     */         });
/*  63 */     this.tbl1.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/*  65 */             NpcTable.this.tbl1KeyPressed(evt);
/*     */           }
/*     */           public void keyReleased(KeyEvent evt) {
/*  68 */             NpcTable.this.tbl1KeyReleased(evt);
/*     */           }
/*     */         });
/*  71 */     this.jScrollPane2.setViewportView(this.tbl1);
/*     */     
/*  73 */     GroupLayout layout = new GroupLayout(getContentPane());
/*  74 */     getContentPane().setLayout(layout);
/*  75 */     layout.setHorizontalGroup(layout
/*  76 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/*  77 */         .addComponent(this.jScrollPane2, -2, -1, -2));
/*     */     
/*  79 */     layout.setVerticalGroup(layout
/*  80 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/*  81 */         .addComponent(this.jScrollPane2, -2, 274, -2));
/*     */ 
/*     */     
/*  84 */     pack();
/*     */   }
/*     */   
/*     */   private void tbl1MouseClicked(MouseEvent evt) {
/*  88 */     int index = this.tbl1.getSelectedRow();
/*  89 */     if (index != -1) {
/*  90 */       this.drawMapScr.setNpcTemplateChoose(Manager.gI().getNpcTemplates().get(index));
/*     */     }
/*     */   }
/*     */   
/*     */   private void tbl1KeyPressed(KeyEvent evt) {
/*  95 */     int index = this.tbl1.getSelectedRow();
/*  96 */     if (index != -1) {
/*  97 */       this.drawMapScr.setNpcTemplateChoose(Manager.gI().getNpcTemplates().get(index));
/*     */     }
/*     */   }
/*     */   
/*     */   private void tbl1KeyReleased(KeyEvent evt) {
/* 102 */     int index = this.tbl1.getSelectedRow();
/* 103 */     if (index != -1) {
/* 104 */       this.drawMapScr.setNpcTemplateChoose(Manager.gI().getNpcTemplates().get(index));
/*     */     }
/*     */   }
/*     */   
/*     */   private void fillToTable() {
/* 109 */     this.model1.setRowCount(0);
/*     */     
/* 111 */     for (NpcTemplate npc : Manager.gI().getNpcTemplates()) {
/*     */       
/* 113 */       this.model1.addRow(new Object[] {
/* 114 */             Integer.valueOf(npc.getId()), npc.getName(), Integer.valueOf(npc.getAvatar())
/*     */           });
/*     */     } 
/*     */   }
/*     */   
/*     */   private void setup() {
/* 120 */     setResizable(false);
/* 121 */     setLocationRelativeTo(null);
/*     */     
/* 123 */     this.model1 = new DefaultTableModel((Object[])new String[] { "ID", "Name", "Avatar" }, 0)
/*     */       {
/*     */         public boolean isCellEditable(int row, int column) {
/* 126 */           return false;
/*     */         }
/*     */       };
/* 129 */     this.tbl1.setModel(this.model1);
/* 130 */     this.tbl1.setRowHeight(50);
/* 131 */     this.tbl1.getColumnModel().getColumn(2).setCellRenderer(new ImageRender());
/* 132 */     fillToTable();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/*     */     try {
/* 142 */       for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
/* 143 */         if ("Nimbus".equals(info.getName())) {
/* 144 */           UIManager.setLookAndFeel(info.getClassName());
/*     */           break;
/*     */         } 
/*     */       } 
/* 148 */     } catch (ClassNotFoundException ex) {
/* 149 */       Logger.getLogger(NpcTable.class.getName()).log(Level.SEVERE, (String)null, ex);
/* 150 */     } catch (InstantiationException ex) {
/* 151 */       Logger.getLogger(NpcTable.class.getName()).log(Level.SEVERE, (String)null, ex);
/* 152 */     } catch (IllegalAccessException ex) {
/* 153 */       Logger.getLogger(NpcTable.class.getName()).log(Level.SEVERE, (String)null, ex);
/* 154 */     } catch (UnsupportedLookAndFeelException ex) {
/* 155 */       Logger.getLogger(NpcTable.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 161 */     EventQueue.invokeLater(new Runnable() {
/*     */           public void run() {
/* 163 */             (new NpcTable(null)).setVisible(true);
/*     */           }
/*     */         });
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private class ImageRender
/*     */     extends DefaultTableCellRenderer
/*     */   {
/*     */     private ImageRender() {}
/*     */ 
/*     */     
/*     */     public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
/* 177 */       ImageIcon icon = null;
/*     */       try {
/* 179 */         String id = value.toString();
/* 180 */         Image image = Util.getImageById(Integer.parseInt(id), 2);
/* 181 */         image = image.getScaledInstance(40, 40, 4);
/* 182 */         icon = new ImageIcon(image);
/* 183 */       } catch (Exception exception) {}
/*     */       
/* 185 */       return new JLabel(icon);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\nro\server_luxu_nrp\vemap\GirlkunToolCBRO.jar!\com\girlkun\tool\screens\draw_map_scr\NpcTable.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */