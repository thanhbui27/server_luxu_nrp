/*     */ package com.girlkun.tool.screens.draw_map_scr;
/*     */ import com.girlkun.button.Button;
/*     */ import com.girlkun.tool.screens.draw_map_scr.models.MobMap;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Font;
/*     */ import java.awt.Image;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.KeyAdapter;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import javax.swing.GroupLayout;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.JTextArea;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.LayoutStyle;
/*     */ import javax.swing.table.DefaultTableModel;
/*     */ import org.json.simple.JSONArray;
/*     */ import org.json.simple.JSONValue;
/*     */ 
/*     */ public class MobList extends JFrame {
/*     */   private DrawMapScr drawMapScr;
/*     */   private DefaultTableModel model1;
/*     */   private int index;
/*     */   private Button button1;
/*     */   
/*     */   public MobList(DrawMapScr drawMapScr) {
/*  33 */     this.drawMapScr = drawMapScr;
/*  34 */     initComponents();
/*  35 */     setup();
/*  36 */     setDefaultCloseOperation(2);
/*  37 */     setTitle("Girlkun75 - List mob map");
/*  38 */     setAlwaysOnTop(true);
/*     */   }
/*     */   private Button button2; private Button button3; private JLabel jLabel1; private JLabel jLabel2; private JLabel jLabel3; private JLabel jLabel4; private JScrollPane jScrollPane1; private JScrollPane jScrollPane2; private JTable tbl1; private JTextField txtHp; private JTextField txtLevel; private JTextArea txtText;
/*     */   private JTextField txtX;
/*     */   private JTextField txtY;
/*     */   
/*     */   private void initComponents() {
/*  45 */     this.jScrollPane2 = new JScrollPane();
/*  46 */     this.tbl1 = new JTable();
/*  47 */     this.button1 = new Button();
/*  48 */     this.button2 = new Button();
/*  49 */     this.jScrollPane1 = new JScrollPane();
/*  50 */     this.txtText = new JTextArea();
/*  51 */     this.jLabel1 = new JLabel();
/*  52 */     this.jLabel2 = new JLabel();
/*  53 */     this.txtLevel = new JTextField();
/*  54 */     this.txtHp = new JTextField();
/*  55 */     this.jLabel3 = new JLabel();
/*  56 */     this.txtX = new JTextField();
/*  57 */     this.jLabel4 = new JLabel();
/*  58 */     this.txtY = new JTextField();
/*  59 */     this.button3 = new Button();
/*     */     
/*  61 */     setDefaultCloseOperation(3);
/*     */     
/*  63 */     this.tbl1.setModel(new DefaultTableModel(new Object[0][], (Object[])new String[0]));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  71 */     this.tbl1.setSelectionMode(0);
/*  72 */     this.tbl1.addMouseListener(new MouseAdapter() {
/*     */           public void mouseClicked(MouseEvent evt) {
/*  74 */             MobList.this.tbl1MouseClicked(evt);
/*     */           }
/*     */         });
/*  77 */     this.tbl1.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/*  79 */             MobList.this.tbl1KeyPressed(evt);
/*     */           }
/*     */           public void keyReleased(KeyEvent evt) {
/*  82 */             MobList.this.tbl1KeyReleased(evt);
/*     */           }
/*     */         });
/*  85 */     this.jScrollPane2.setViewportView(this.tbl1);
/*     */     
/*  87 */     this.button1.setBackground(new Color(255, 0, 0));
/*  88 */     this.button1.setForeground(new Color(255, 255, 255));
/*  89 */     this.button1.setText("Clear all");
/*  90 */     this.button1.setFont(new Font("SansSerif", 1, 14));
/*  91 */     this.button1.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/*  93 */             MobList.this.button1ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     
/*  97 */     this.button2.setBackground(new Color(0, 204, 0));
/*  98 */     this.button2.setForeground(new Color(255, 255, 255));
/*  99 */     this.button2.setText("Save");
/* 100 */     this.button2.setFont(new Font("SansSerif", 1, 14));
/* 101 */     this.button2.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/* 103 */             MobList.this.button2ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     
/* 107 */     this.txtText.setColumns(20);
/* 108 */     this.txtText.setFont(new Font("SansSerif", 1, 14));
/* 109 */     this.txtText.setLineWrap(true);
/* 110 */     this.txtText.setRows(5);
/* 111 */     this.txtText.setWrapStyleWord(true);
/* 112 */     this.txtText.addKeyListener(new KeyAdapter() {
/*     */           public void keyReleased(KeyEvent evt) {
/* 114 */             MobList.this.txtTextKeyReleased(evt);
/*     */           }
/*     */         });
/* 117 */     this.jScrollPane1.setViewportView(this.txtText);
/*     */     
/* 119 */     this.jLabel1.setFont(new Font("SansSerif", 1, 12));
/* 120 */     this.jLabel1.setText("Level");
/*     */     
/* 122 */     this.jLabel2.setFont(new Font("SansSerif", 1, 12));
/* 123 */     this.jLabel2.setText("Hp");
/*     */     
/* 125 */     this.txtLevel.setFont(new Font("SansSerif", 1, 12));
/* 126 */     this.txtLevel.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/* 128 */             MobList.this.txtLevelKeyPressed(evt);
/*     */           }
/*     */           public void keyReleased(KeyEvent evt) {
/* 131 */             MobList.this.txtLevelKeyReleased(evt);
/*     */           }
/*     */         });
/*     */     
/* 135 */     this.txtHp.setFont(new Font("SansSerif", 1, 12));
/* 136 */     this.txtHp.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/* 138 */             MobList.this.txtHpKeyPressed(evt);
/*     */           }
/*     */           public void keyReleased(KeyEvent evt) {
/* 141 */             MobList.this.txtHpKeyReleased(evt);
/*     */           }
/*     */         });
/*     */     
/* 145 */     this.jLabel3.setFont(new Font("SansSerif", 1, 12));
/* 146 */     this.jLabel3.setText("X");
/*     */     
/* 148 */     this.txtX.setFont(new Font("SansSerif", 1, 12));
/* 149 */     this.txtX.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/* 151 */             MobList.this.txtXKeyPressed(evt);
/*     */           }
/*     */           public void keyReleased(KeyEvent evt) {
/* 154 */             MobList.this.txtXKeyReleased(evt);
/*     */           }
/*     */         });
/*     */     
/* 158 */     this.jLabel4.setFont(new Font("SansSerif", 1, 12));
/* 159 */     this.jLabel4.setText("Y");
/*     */     
/* 161 */     this.txtY.setFont(new Font("SansSerif", 1, 12));
/* 162 */     this.txtY.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/* 164 */             MobList.this.txtYKeyPressed(evt);
/*     */           }
/*     */           public void keyReleased(KeyEvent evt) {
/* 167 */             MobList.this.txtYKeyReleased(evt);
/*     */           }
/*     */         });
/*     */     
/* 171 */     this.button3.setBackground(new Color(255, 0, 0));
/* 172 */     this.button3.setForeground(new Color(255, 255, 255));
/* 173 */     this.button3.setText("Remove");
/* 174 */     this.button3.setFont(new Font("SansSerif", 1, 14));
/* 175 */     this.button3.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/* 177 */             MobList.this.button3ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     
/* 181 */     GroupLayout layout = new GroupLayout(getContentPane());
/* 182 */     getContentPane().setLayout(layout);
/* 183 */     layout.setHorizontalGroup(layout
/* 184 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 185 */         .addGroup(layout.createSequentialGroup()
/* 186 */           .addComponent(this.jScrollPane2, -2, 423, -2)
/* 187 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 188 */           .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 189 */             .addComponent((Component)this.button1, -1, 185, 32767)
/* 190 */             .addComponent((Component)this.button2, -1, 185, 32767)
/* 191 */             .addGroup(layout.createSequentialGroup()
/* 192 */               .addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false)
/* 193 */                 .addComponent(this.jLabel2, -1, -1, 32767)
/* 194 */                 .addComponent(this.jLabel1, -1, 55, 32767)
/* 195 */                 .addComponent(this.jLabel3, -1, -1, 32767)
/* 196 */                 .addComponent(this.jLabel4, -1, -1, 32767))
/* 197 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 198 */               .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 199 */                 .addComponent(this.txtLevel)
/* 200 */                 .addComponent(this.txtHp)
/* 201 */                 .addComponent(this.txtX)
/* 202 */                 .addComponent(this.txtY)))
/* 203 */             .addComponent((Component)this.button3, -1, 185, 32767)))
/* 204 */         .addComponent(this.jScrollPane1));
/*     */     
/* 206 */     layout.setVerticalGroup(layout
/* 207 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 208 */         .addGroup(layout.createSequentialGroup()
/* 209 */           .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 210 */             .addGroup(layout.createSequentialGroup()
/* 211 */               .addContainerGap()
/* 212 */               .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 213 */                 .addComponent(this.txtLevel, -1, 42, 32767)
/* 214 */                 .addComponent(this.jLabel1, -2, 42, -2))
/* 215 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 216 */               .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 217 */                 .addComponent(this.jLabel2, -2, 42, -2)
/* 218 */                 .addComponent(this.txtHp))
/* 219 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 220 */               .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 221 */                 .addComponent(this.jLabel3, -2, 42, -2)
/* 222 */                 .addComponent(this.txtX))
/* 223 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 224 */               .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 225 */                 .addComponent(this.jLabel4, -2, 42, -2)
/* 226 */                 .addComponent(this.txtY))
/* 227 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 228 */               .addComponent((Component)this.button2, -2, 36, -2)
/* 229 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 230 */               .addComponent((Component)this.button3, -2, 36, -2)
/* 231 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 232 */               .addComponent((Component)this.button1, -2, 36, -2))
/* 233 */             .addComponent(this.jScrollPane2, -2, 0, 32767))
/* 234 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 235 */           .addComponent(this.jScrollPane1, -2, -1, -2)));
/*     */ 
/*     */     
/* 238 */     layout.linkSize(1, new Component[] { this.txtHp, this.txtLevel });
/*     */     
/* 240 */     layout.linkSize(1, new Component[] { this.jLabel3, this.txtX, this.txtY });
/*     */     
/* 242 */     pack();
/*     */   }
/*     */   
/*     */   private void tbl1MouseClicked(MouseEvent evt) {
/* 246 */     this.index = this.tbl1.getSelectedRow();
/* 247 */     if (this.index != -1) {
/* 248 */       this.drawMapScr.setMobChose(this.drawMapScr.mobs.get(this.index));
/* 249 */       this.txtLevel.setText(this.drawMapScr.mobMapChose.getLevel() + "");
/* 250 */       this.txtHp.setText(this.drawMapScr.mobMapChose.getHp() + "");
/* 251 */       this.txtX.setText(this.drawMapScr.mobMapChose.getX() + "");
/* 252 */       this.txtY.setText(this.drawMapScr.mobMapChose.getY() + "");
/*     */     } 
/*     */   }
/*     */   
/*     */   private void tbl1KeyPressed(KeyEvent evt) {
/* 257 */     this.index = this.tbl1.getSelectedRow();
/* 258 */     if (this.index != -1) {
/* 259 */       this.drawMapScr.setMobChose(this.drawMapScr.mobs.get(this.index));
/* 260 */       this.txtLevel.setText(this.drawMapScr.mobMapChose.getLevel() + "");
/* 261 */       this.txtHp.setText(this.drawMapScr.mobMapChose.getHp() + "");
/* 262 */       this.txtX.setText(this.drawMapScr.mobMapChose.getX() + "");
/* 263 */       this.txtY.setText(this.drawMapScr.mobMapChose.getY() + "");
/*     */     } 
/*     */   }
/*     */   
/*     */   private void tbl1KeyReleased(KeyEvent evt) {
/* 268 */     this.index = this.tbl1.getSelectedRow();
/* 269 */     if (this.index != -1) {
/* 270 */       this.drawMapScr.setMobChose(this.drawMapScr.mobs.get(this.index));
/* 271 */       this.txtLevel.setText(this.drawMapScr.mobMapChose.getLevel() + "");
/* 272 */       this.txtHp.setText(this.drawMapScr.mobMapChose.getHp() + "");
/* 273 */       this.txtX.setText(this.drawMapScr.mobMapChose.getX() + "");
/* 274 */       this.txtY.setText(this.drawMapScr.mobMapChose.getY() + "");
/*     */     } 
/*     */   }
/*     */   
/*     */   private void button1ActionPerformed(ActionEvent evt) {
/* 279 */     this.drawMapScr.mobs.clear();
/* 280 */     fillToTable();
/*     */   }
/*     */   
/*     */   private void button2ActionPerformed(ActionEvent evt) {
/*     */     try {
/* 285 */       System.out.println(this.txtText.getText());
/* 286 */       GirlkunDB.executeUpdate("GIRLKUN", "update map_template set mobs = ? where id = ?", new Object[] { this.txtText.getText(), Integer.valueOf(this.drawMapScr.mapId) });
/* 287 */       NotifyUtil.showMessageDialog(this, "Lưu thành công!");
/* 288 */     } catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */   
/*     */   private void txtTextKeyReleased(KeyEvent evt) {
/* 293 */     if (evt.getKeyCode() == 10) {
/* 294 */       readTextMob(this.txtText.getText());
/*     */     }
/*     */   }
/*     */   
/*     */   public void readTextMob(String data) {
/*     */     try {
/* 300 */       this.model1.setRowCount(0);
/* 301 */       this.drawMapScr.mobs.clear();
/* 302 */       JSONValue jv = new JSONValue();
/* 303 */       JSONArray dataArray = null;
/* 304 */       dataArray = (JSONArray)JSONValue.parse(data);
/* 305 */       for (int j = 0; j < dataArray.size(); j++) {
/* 306 */         JSONArray dtm = (JSONArray)JSONValue.parse(String.valueOf(dataArray.get(j)));
/* 307 */         int temp = Byte.parseByte(String.valueOf(dtm.get(0)));
/* 308 */         int level = Byte.parseByte(String.valueOf(dtm.get(1)));
/* 309 */         int hp = Integer.parseInt(String.valueOf(dtm.get(2)));
/* 310 */         int x = Short.parseShort(String.valueOf(dtm.get(3)));
/* 311 */         int y = Short.parseShort(String.valueOf(dtm.get(4)));
/* 312 */         this.drawMapScr.mobs.add(new MobMap(Manager.gI().getMobTemplates().get(temp), x, y, level, hp));
/* 313 */         dtm.clear();
/*     */       } 
/* 315 */       fillToTable();
/* 316 */     } catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */   
/*     */   private void txtLevelKeyPressed(KeyEvent evt) {
/* 321 */     if (this.drawMapScr.mobMapChose != null) {
/*     */       try {
/* 323 */         this.drawMapScr.mobMapChose.setLevel(Integer.parseInt(this.txtLevel.getText()));
/* 324 */       } catch (Exception exception) {}
/*     */       
/* 326 */       fillToTable();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void txtLevelKeyReleased(KeyEvent evt) {
/* 331 */     if (this.drawMapScr.mobMapChose != null) {
/*     */       try {
/* 333 */         this.drawMapScr.mobMapChose.setLevel(Integer.parseInt(this.txtLevel.getText()));
/* 334 */       } catch (Exception exception) {}
/*     */       
/* 336 */       fillToTable();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void txtHpKeyPressed(KeyEvent evt) {
/* 341 */     if (this.drawMapScr.mobMapChose != null) {
/*     */       try {
/* 343 */         this.drawMapScr.mobMapChose.setHp(Integer.parseInt(this.txtHp.getText()));
/* 344 */       } catch (Exception exception) {}
/*     */       
/* 346 */       fillToTable();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void txtHpKeyReleased(KeyEvent evt) {
/* 351 */     if (this.drawMapScr.mobMapChose != null) {
/*     */       try {
/* 353 */         this.drawMapScr.mobMapChose.setHp(Integer.parseInt(this.txtHp.getText()));
/* 354 */       } catch (Exception exception) {}
/*     */       
/* 356 */       fillToTable();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void txtXKeyPressed(KeyEvent evt) {}
/*     */ 
/*     */   
/*     */   private void txtXKeyReleased(KeyEvent evt) {
/* 365 */     if (this.drawMapScr.mobMapChose != null) {
/*     */       try {
/* 367 */         this.drawMapScr.mobMapChose.setX(Integer.parseInt(this.txtX.getText()));
/* 368 */       } catch (Exception exception) {}
/*     */       
/* 370 */       fillToTable();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void txtYKeyPressed(KeyEvent evt) {}
/*     */ 
/*     */   
/*     */   private void txtYKeyReleased(KeyEvent evt) {
/* 379 */     if (this.drawMapScr.mobMapChose != null) {
/*     */       try {
/* 381 */         this.drawMapScr.mobMapChose.setY(Integer.parseInt(this.txtY.getText()));
/* 382 */       } catch (Exception exception) {}
/*     */       
/* 384 */       fillToTable();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void button3ActionPerformed(ActionEvent evt) {
/* 390 */     this.drawMapScr.mobs.remove(this.drawMapScr.mobMapChose);
/* 391 */     fillToTable();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void fillToTable() {
/* 397 */     this.model1.setRowCount(0);
/*     */     
/* 399 */     JSONArray dataArray = new JSONArray();
/* 400 */     for (MobMap mob : this.drawMapScr.mobs) {
/* 401 */       JSONArray ja = new JSONArray();
/* 402 */       ja.add(Integer.valueOf(mob.getTemp().getId()));
/* 403 */       ja.add(Integer.valueOf(mob.getLevel()));
/* 404 */       ja.add(Integer.valueOf(mob.getHp()));
/* 405 */       ja.add(Integer.valueOf(mob.getX()));
/* 406 */       ja.add(Integer.valueOf(mob.getY()));
/* 407 */       dataArray.add(ja.toJSONString());
/* 408 */       this.model1.addRow(new Object[] {
/* 409 */             Integer.valueOf(mob.getTemp().getId()), mob.getTemp().getName(), Integer.valueOf(mob.getTemp().getId()), Integer.valueOf(mob.getX()), Integer.valueOf(mob.getY()), Integer.valueOf(mob.getLevel()), Integer.valueOf(mob.getHp())
/*     */           });
/*     */     } 
/* 412 */     this.txtText.setText(dataArray.toJSONString()
/* 413 */         .replaceAll("\\\\", "")
/* 414 */         .replaceAll("\\[\\\"\\[", "[[")
/* 415 */         .replaceAll("\\]\\\"\\,\\\"\\[", "],[")
/* 416 */         .replaceAll("\\]\\\"\\]", "]]"));
/*     */   }
/*     */   
/*     */   private void setup() {
/* 420 */     setResizable(false);
/* 421 */     setLocationRelativeTo(null);
/*     */     
/* 423 */     this.model1 = new DefaultTableModel((Object[])new String[] { "ID", "Name", "Image", "x", "y", "level", "hp" }, 0)
/*     */       {
/*     */         public boolean isCellEditable(int row, int column) {
/* 426 */           return false;
/*     */         }
/*     */       };
/* 429 */     this.tbl1.setModel(this.model1);
/* 430 */     this.tbl1.setRowHeight(50);
/* 431 */     this.tbl1.getColumnModel().getColumn(2).setCellRenderer(new ImageRender());
/* 432 */     fillToTable();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private class ImageRender
/*     */     extends DefaultTableCellRenderer
/*     */   {
/*     */     private ImageRender() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
/* 480 */       ImageIcon icon = null;
/*     */       try {
/* 482 */         String id = value.toString();
/* 483 */         Image image = Util.getImageMobById(Integer.parseInt(id), 0);
/* 484 */         image = image.getScaledInstance(40, 40, 4);
/* 485 */         icon = new ImageIcon(image);
/* 486 */       } catch (Exception exception) {}
/*     */       
/* 488 */       return new JLabel(icon);
/*     */     }
/*     */   }
/*     */ }


/* Location:              D:\nro\server_luxu_nrp\vemap\GirlkunToolCBRO.jar!\com\girlkun\tool\screens\draw_map_scr\MobList.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */