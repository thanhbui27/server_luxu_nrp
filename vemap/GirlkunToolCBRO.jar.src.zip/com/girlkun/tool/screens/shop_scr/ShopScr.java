/*      */ package com.girlkun.tool.screens.shop_scr;
/*      */ 
/*      */ import com.girlkun.avatar.Avatar;
/*      */ import com.girlkun.button.Button;
/*      */ import com.girlkun.database.GirlkunDB;
/*      */ import com.girlkun.result.GirlkunResultSet;
/*      */ import com.girlkun.tool.entities.item.ItemOption;
/*      */ import com.girlkun.tool.entities.item.ItemTemplate;
/*      */ import com.girlkun.tool.entities.map.NpcTemplate;
/*      */ import com.girlkun.tool.entities.shop.ItemShop;
/*      */ import com.girlkun.tool.entities.shop.Shop;
/*      */ import com.girlkun.tool.entities.shop.TabShop;
/*      */ import com.girlkun.tool.main.Manager;
/*      */ import com.girlkun.tool.utils.Logger;
/*      */ import com.girlkun.tool.utils.NotifyUtil;
/*      */ import com.girlkun.tool.utils.StringUtil;
/*      */ import com.girlkun.tool.utils.Util;
/*      */ import java.awt.Color;
/*      */ import java.awt.Component;
/*      */ import java.awt.Font;
/*      */ import java.awt.Graphics2D;
/*      */ import java.awt.Image;
/*      */ import java.awt.event.ActionEvent;
/*      */ import java.awt.event.ActionListener;
/*      */ import java.awt.event.KeyAdapter;
/*      */ import java.awt.event.KeyEvent;
/*      */ import java.awt.event.MouseAdapter;
/*      */ import java.awt.event.MouseEvent;
/*      */ import java.awt.image.BufferedImage;
/*      */ import java.awt.image.ImageObserver;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import javax.swing.DefaultComboBoxModel;
/*      */ import javax.swing.GroupLayout;
/*      */ import javax.swing.ImageIcon;
/*      */ import javax.swing.JCheckBox;
/*      */ import javax.swing.JComboBox;
/*      */ import javax.swing.JInternalFrame;
/*      */ import javax.swing.JLabel;
/*      */ import javax.swing.JPanel;
/*      */ import javax.swing.JScrollPane;
/*      */ import javax.swing.JSeparator;
/*      */ import javax.swing.JTabbedPane;
/*      */ import javax.swing.JTable;
/*      */ import javax.swing.JTextArea;
/*      */ import javax.swing.JTextField;
/*      */ import javax.swing.LayoutStyle;
/*      */ import javax.swing.table.DefaultTableModel;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ShopScr
/*      */   extends JInternalFrame
/*      */ {
/*      */   private DefaultTableModel modelShop;
/*      */   private DefaultTableModel modelTabShop;
/*      */   private DefaultTableModel modelItemShop;
/*      */   private int indexShop;
/*      */   private int indexTab;
/*      */   private int index;
/*      */   private List<Shop> shops;
/*      */   private ItemShopOption itemShopOptionScr;
/*      */   private JLabel avatarItem;
/*      */   private Avatar avatarNpc;
/*      */   private Avatar avatarNpc1;
/*      */   private Button button1;
/*      */   private Button button10;
/*      */   private Button button11;
/*      */   private Button button12;
/*      */   private Button button13;
/*      */   private Button button2;
/*      */   private Button button3;
/*      */   private Button button4;
/*      */   private Button button5;
/*      */   private Button button6;
/*      */   private Button button7;
/*      */   private Button button8;
/*      */   private Button button9;
/*      */   private JComboBox<String> cboIconSpec;
/*      */   private JComboBox<String> cboItemTemplate;
/*      */   private JComboBox<String> cboNpcTemplate;
/*      */   private JComboBox<String> cboShop;
/*      */   private JComboBox<String> cboShop2;
/*      */   private JComboBox<String> cboTab2;
/*      */   private JComboBox<String> cboTypeSell;
/*      */   private JComboBox<String> cboTypeShop;
/*      */   private JCheckBox chkNew;
/*      */   private JCheckBox chkSell;
/*      */   private JLabel jLabel1;
/*      */   private JLabel jLabel10;
/*      */   private JLabel jLabel11;
/*      */   private JLabel jLabel12;
/*      */   private JLabel jLabel2;
/*      */   private JLabel jLabel3;
/*      */   private JLabel jLabel4;
/*      */   private JLabel jLabel5;
/*      */   private JLabel jLabel6;
/*      */   private JLabel jLabel7;
/*      */   private JLabel jLabel8;
/*      */   private JLabel jLabel9;
/*      */   private JPanel jPanel1;
/*      */   private JPanel jPanel2;
/*      */   private JPanel jPanel3;
/*      */   private JScrollPane jScrollPane1;
/*      */   private JScrollPane jScrollPane2;
/*      */   private JScrollPane jScrollPane3;
/*      */   private JScrollPane jScrollPane4;
/*      */   private JSeparator jSeparator1;
/*      */   private JSeparator jSeparator2;
/*      */   private JTabbedPane jTabbedPane1;
/*      */   private JLabel lblIconSpec;
/*      */   private JTable tblListItem;
/*      */   private JTable tblListShop;
/*      */   private JTable tblListTabShop;
/*      */   private JTextField txtCost;
/*      */   private JTextField txtFindItemTemplate;
/*      */   private JTextArea txtInfoItem;
/*      */   private JTextField txtTabName;
/*      */   private JTextField txtTagName;
/*      */   
/*      */   public ShopScr() {
/* 1325 */     this.indexShop = -1;
/* 1326 */     this.indexTab = -1;
/* 1327 */     this.index = -1;
/* 1328 */     this.shops = new ArrayList<>();
/*      */     initComponents();
/*      */     setup();
/*      */     loadData();
/*      */   }
/*      */   
/*      */   private void initComponents() {
/*      */     this.jTabbedPane1 = new JTabbedPane();
/*      */     this.jPanel1 = new JPanel();
/*      */     this.jLabel1 = new JLabel();
/*      */     this.cboNpcTemplate = new JComboBox<>();
/*      */     this.jLabel2 = new JLabel();
/*      */     this.jLabel3 = new JLabel();
/*      */     this.txtTagName = new JTextField();
/*      */     this.cboTypeShop = new JComboBox<>();
/*      */     this.button1 = new Button();
/*      */     this.button2 = new Button();
/*      */     this.button3 = new Button();
/*      */     this.button4 = new Button();
/*      */     this.jScrollPane1 = new JScrollPane();
/*      */     this.tblListShop = new JTable();
/*      */     this.avatarNpc = new Avatar();
/*      */     this.jPanel2 = new JPanel();
/*      */     this.jLabel4 = new JLabel();
/*      */     this.cboShop = new JComboBox<>();
/*      */     this.txtTabName = new JTextField();
/*      */     this.jLabel5 = new JLabel();
/*      */     this.button5 = new Button();
/*      */     this.button6 = new Button();
/*      */     this.button7 = new Button();
/*      */     this.button8 = new Button();
/*      */     this.jScrollPane2 = new JScrollPane();
/*      */     this.tblListTabShop = new JTable();
/*      */     this.avatarNpc1 = new Avatar();
/*      */     this.jPanel3 = new JPanel();
/*      */     this.jLabel6 = new JLabel();
/*      */     this.cboShop2 = new JComboBox<>();
/*      */     this.jLabel7 = new JLabel();
/*      */     this.cboTab2 = new JComboBox<>();
/*      */     this.jSeparator1 = new JSeparator();
/*      */     this.jLabel8 = new JLabel();
/*      */     this.jLabel9 = new JLabel();
/*      */     this.jSeparator2 = new JSeparator();
/*      */     this.txtFindItemTemplate = new JTextField();
/*      */     this.cboItemTemplate = new JComboBox<>();
/*      */     this.avatarItem = new JLabel();
/*      */     this.chkNew = new JCheckBox();
/*      */     this.chkSell = new JCheckBox();
/*      */     this.jLabel10 = new JLabel();
/*      */     this.cboTypeSell = new JComboBox<>();
/*      */     this.jLabel11 = new JLabel();
/*      */     this.txtCost = new JTextField();
/*      */     this.cboIconSpec = new JComboBox<>();
/*      */     this.jLabel12 = new JLabel();
/*      */     this.button9 = new Button();
/*      */     this.button10 = new Button();
/*      */     this.button11 = new Button();
/*      */     this.button12 = new Button();
/*      */     this.lblIconSpec = new JLabel();
/*      */     this.jScrollPane3 = new JScrollPane();
/*      */     this.tblListItem = new JTable();
/*      */     this.button13 = new Button();
/*      */     this.jScrollPane4 = new JScrollPane();
/*      */     this.txtInfoItem = new JTextArea();
/*      */     setClosable(true);
/*      */     this.jLabel1.setFont(new Font("SansSerif", 1, 12));
/*      */     this.jLabel1.setText("Npc");
/*      */     this.cboNpcTemplate.setFont(new Font("SansSerif", 1, 12));
/*      */     this.cboNpcTemplate.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/*      */             ShopScr.this.cboNpcTemplateActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     this.jLabel2.setFont(new Font("SansSerif", 1, 12));
/*      */     this.jLabel2.setText("Tag name");
/*      */     this.jLabel3.setFont(new Font("SansSerif", 1, 12));
/*      */     this.jLabel3.setText("Type shop");
/*      */     this.txtTagName.setFont(new Font("SansSerif", 1, 12));
/*      */     this.cboTypeShop.setFont(new Font("SansSerif", 1, 12));
/*      */     this.cboTypeShop.setModel(new DefaultComboBoxModel<>(new String[] { "Normal", "Unknow", "Unknow", "Spec" }));
/*      */     this.cboTypeShop.setToolTipText("");
/*      */     this.button1.setBackground(new Color(0, 255, 0));
/*      */     this.button1.setForeground(new Color(255, 255, 255));
/*      */     this.button1.setText("Thêm");
/*      */     this.button1.setFont(new Font("SansSerif", 1, 12));
/*      */     this.button1.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/*      */             ShopScr.this.button1ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     this.button2.setBackground(new Color(204, 0, 204));
/*      */     this.button2.setForeground(new Color(255, 255, 255));
/*      */     this.button2.setText("Sửa");
/*      */     this.button2.setFont(new Font("SansSerif", 1, 12));
/*      */     this.button2.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/*      */             ShopScr.this.button2ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     this.button3.setBackground(new Color(255, 51, 0));
/*      */     this.button3.setForeground(new Color(255, 255, 255));
/*      */     this.button3.setText("Xóa");
/*      */     this.button3.setFont(new Font("SansSerif", 1, 12));
/*      */     this.button3.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/*      */             ShopScr.this.button3ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     this.button4.setBackground(new Color(153, 153, 0));
/*      */     this.button4.setForeground(new Color(255, 255, 255));
/*      */     this.button4.setFont(new Font("SansSerif", 1, 12));
/*      */     this.tblListShop.setModel(new DefaultTableModel(new Object[0][], (Object[])new String[0]));
/*      */     this.tblListShop.addMouseListener(new MouseAdapter() {
/*      */           public void mouseClicked(MouseEvent evt) {
/*      */             ShopScr.this.tblListShopMouseClicked(evt);
/*      */           }
/*      */         });
/*      */     this.tblListShop.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/*      */             ShopScr.this.tblListShopKeyPressed(evt);
/*      */           }
/*      */           
/*      */           public void keyReleased(KeyEvent evt) {
/*      */             ShopScr.this.tblListShopKeyReleased(evt);
/*      */           }
/*      */         });
/*      */     this.jScrollPane1.setViewportView(this.tblListShop);
/*      */     this.avatarNpc.setAlignmentX(5.0F);
/*      */     this.avatarNpc.setAlignmentY(5.0F);
/*      */     GroupLayout jPanel1Layout = new GroupLayout(this.jPanel1);
/*      */     this.jPanel1.setLayout(jPanel1Layout);
/*      */     jPanel1Layout.setHorizontalGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addContainerGap().addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addGroup(jPanel1Layout.createSequentialGroup().addComponent(this.jLabel1, -2, 103, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.cboNpcTemplate, 0, -1, 32767)).addGroup(jPanel1Layout.createSequentialGroup().addComponent(this.jLabel2, -2, 103, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtTagName)).addGroup(jPanel1Layout.createSequentialGroup().addComponent(this.jLabel3, -2, 103, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.cboTypeShop, 0, -1, 32767).addGroup(jPanel1Layout.createSequentialGroup().addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addComponent((Component)this.button1, -2, 93, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button2, -2, 93, -2)).addGroup(jPanel1Layout.createSequentialGroup().addComponent((Component)this.button3, -2, 93, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button4, -2, 93, -2))).addGap(0, 0, 32767))))).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.avatarNpc, -2, 223, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jScrollPane1, -1, 443, 32767).addContainerGap()));
/*      */     jPanel1Layout.setVerticalGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addContainerGap().addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jScrollPane1, -1, 574, 32767).addGroup(jPanel1Layout.createSequentialGroup().addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent((Component)this.avatarNpc, -2, 224, -2).addGroup(jPanel1Layout.createSequentialGroup().addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(this.cboNpcTemplate).addComponent(this.jLabel1, -1, 40, 32767)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(this.txtTagName).addComponent(this.jLabel2, -1, 40, 32767)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(this.jLabel3, -1, 40, 32767).addComponent(this.cboTypeShop)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent((Component)this.button1, -2, 40, -2).addComponent((Component)this.button2, -2, 40, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent((Component)this.button3, -2, 40, -2).addComponent((Component)this.button4, -2, 40, -2)))).addGap(0, 0, 32767))).addContainerGap()));
/*      */     this.jTabbedPane1.addTab("Shop", this.jPanel1);
/*      */     this.jLabel4.setFont(new Font("SansSerif", 1, 12));
/*      */     this.jLabel4.setText("Shop");
/*      */     this.cboShop.setFont(new Font("SansSerif", 1, 12));
/*      */     this.cboShop.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/*      */             ShopScr.this.cboShopActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     this.txtTabName.setFont(new Font("SansSerif", 1, 12));
/*      */     this.jLabel5.setFont(new Font("SansSerif", 1, 12));
/*      */     this.jLabel5.setText("Tab name");
/*      */     this.button5.setBackground(new Color(0, 255, 0));
/*      */     this.button5.setForeground(new Color(255, 255, 255));
/*      */     this.button5.setText("Thêm");
/*      */     this.button5.setFont(new Font("SansSerif", 1, 12));
/*      */     this.button5.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/*      */             ShopScr.this.button5ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     this.button6.setBackground(new Color(204, 0, 204));
/*      */     this.button6.setForeground(new Color(255, 255, 255));
/*      */     this.button6.setText("Sửa");
/*      */     this.button6.setFont(new Font("SansSerif", 1, 12));
/*      */     this.button6.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/*      */             ShopScr.this.button6ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     this.button7.setBackground(new Color(153, 153, 0));
/*      */     this.button7.setForeground(new Color(255, 255, 255));
/*      */     this.button7.setFont(new Font("SansSerif", 1, 12));
/*      */     this.button8.setBackground(new Color(255, 51, 0));
/*      */     this.button8.setForeground(new Color(255, 255, 255));
/*      */     this.button8.setText("Xóa");
/*      */     this.button8.setFont(new Font("SansSerif", 1, 12));
/*      */     this.button8.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/*      */             ShopScr.this.button8ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     this.tblListTabShop.setFont(new Font("SansSerif", 1, 12));
/*      */     this.tblListTabShop.setModel(new DefaultTableModel(new Object[0][], (Object[])new String[0]));
/*      */     this.tblListTabShop.addMouseListener(new MouseAdapter() {
/*      */           public void mouseClicked(MouseEvent evt) {
/*      */             ShopScr.this.tblListTabShopMouseClicked(evt);
/*      */           }
/*      */         });
/*      */     this.tblListTabShop.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/*      */             ShopScr.this.tblListTabShopKeyPressed(evt);
/*      */           }
/*      */           
/*      */           public void keyReleased(KeyEvent evt) {
/*      */             ShopScr.this.tblListTabShopKeyReleased(evt);
/*      */           }
/*      */         });
/*      */     this.jScrollPane2.setViewportView(this.tblListTabShop);
/*      */     this.avatarNpc1.setAlignmentX(5.0F);
/*      */     this.avatarNpc1.setAlignmentY(5.0F);
/*      */     GroupLayout jPanel2Layout = new GroupLayout(this.jPanel2);
/*      */     this.jPanel2.setLayout(jPanel2Layout);
/*      */     jPanel2Layout.setHorizontalGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel2Layout.createSequentialGroup().addContainerGap().addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addGroup(jPanel2Layout.createSequentialGroup().addComponent(this.jLabel4, -2, 103, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.cboShop, 0, -1, 32767)).addGroup(jPanel2Layout.createSequentialGroup().addComponent(this.jLabel5, -2, 103, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtTabName)).addGroup(jPanel2Layout.createSequentialGroup().addGap(107, 107, 107).addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel2Layout.createSequentialGroup().addComponent((Component)this.button5, -2, 93, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button6, -2, 93, -2)).addGroup(jPanel2Layout.createSequentialGroup().addComponent((Component)this.button8, -2, 93, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button7, -2, 93, -2))))).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.avatarNpc1, -2, 191, -2).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addComponent(this.jScrollPane2, -1, 471, 32767).addContainerGap()));
/*      */     jPanel2Layout.setVerticalGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel2Layout.createSequentialGroup().addContainerGap().addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent((Component)this.avatarNpc1, -2, 178, -2).addComponent(this.jScrollPane2, -2, 574, -2).addGroup(jPanel2Layout.createSequentialGroup().addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(this.cboShop).addComponent(this.jLabel4, -2, 40, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(this.txtTabName).addComponent(this.jLabel5, -2, 40, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent((Component)this.button5, -2, 40, -2).addComponent((Component)this.button6, -2, 40, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent((Component)this.button8, -2, 40, -2).addComponent((Component)this.button7, -2, 40, -2)))).addContainerGap(15, 32767)));
/*      */     this.jTabbedPane1.addTab("Tab shop", this.jPanel2);
/*      */     this.jLabel6.setFont(new Font("SansSerif", 1, 12));
/*      */     this.jLabel6.setText("Shop");
/*      */     this.cboShop2.setFont(new Font("SansSerif", 1, 12));
/*      */     this.cboShop2.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/*      */             ShopScr.this.cboShop2ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     this.jLabel7.setFont(new Font("SansSerif", 1, 12));
/*      */     this.jLabel7.setText("Tab");
/*      */     this.cboTab2.setFont(new Font("SansSerif", 1, 12));
/*      */     this.cboTab2.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/*      */             ShopScr.this.cboTab2ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     this.jLabel8.setFont(new Font("SansSerif", 1, 12));
/*      */     this.jLabel8.setText("Find template");
/*      */     this.jLabel9.setFont(new Font("SansSerif", 1, 12));
/*      */     this.jLabel9.setText("Item template");
/*      */     this.jSeparator2.setOrientation(1);
/*      */     this.txtFindItemTemplate.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/*      */             ShopScr.this.txtFindItemTemplateKeyPressed(evt);
/*      */           }
/*      */           
/*      */           public void keyReleased(KeyEvent evt) {
/*      */             ShopScr.this.txtFindItemTemplateKeyReleased(evt);
/*      */           }
/*      */         });
/*      */     this.cboItemTemplate.setFont(new Font("SansSerif", 1, 12));
/*      */     this.cboItemTemplate.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/*      */             ShopScr.this.cboItemTemplateActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     this.cboItemTemplate.addKeyListener(new KeyAdapter() {
/*      */           public void keyReleased(KeyEvent evt) {
/*      */             ShopScr.this.cboItemTemplateKeyReleased(evt);
/*      */           }
/*      */         });
/*      */     this.avatarItem.setHorizontalAlignment(0);
/*      */     this.chkNew.setFont(new Font("SansSerif", 1, 12));
/*      */     this.chkNew.setText("New item");
/*      */     this.chkSell.setFont(new Font("SansSerif", 1, 12));
/*      */     this.chkSell.setText("Sell");
/*      */     this.jLabel10.setFont(new Font("SansSerif", 1, 12));
/*      */     this.jLabel10.setText("Type sell");
/*      */     this.cboTypeSell.setFont(new Font("SansSerif", 1, 12));
/*      */     this.cboTypeSell.setModel(new DefaultComboBoxModel<>(new String[] { "Vàng", "Ngọc", "Vật phẩm đặc biệt" }));
/*      */     this.cboTypeSell.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/*      */             ShopScr.this.cboTypeSellActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     this.jLabel11.setFont(new Font("SansSerif", 1, 12));
/*      */     this.jLabel11.setText("Cost");
/*      */     this.txtCost.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/*      */             ShopScr.this.txtCostKeyPressed(evt);
/*      */           }
/*      */           
/*      */           public void keyReleased(KeyEvent evt) {
/*      */             ShopScr.this.txtCostKeyReleased(evt);
/*      */           }
/*      */         });
/*      */     this.cboIconSpec.setFont(new Font("SansSerif", 1, 12));
/*      */     this.cboIconSpec.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/*      */             ShopScr.this.cboIconSpecActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     this.jLabel12.setFont(new Font("SansSerif", 1, 12));
/*      */     this.jLabel12.setText("Icon spec");
/*      */     this.button9.setBackground(new Color(0, 255, 0));
/*      */     this.button9.setForeground(new Color(255, 255, 255));
/*      */     this.button9.setText("Thêm");
/*      */     this.button9.setFont(new Font("SansSerif", 1, 12));
/*      */     this.button9.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/*      */             ShopScr.this.button9ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     this.button10.setBackground(new Color(204, 0, 204));
/*      */     this.button10.setForeground(new Color(255, 255, 255));
/*      */     this.button10.setText("Sửa");
/*      */     this.button10.setFont(new Font("SansSerif", 1, 12));
/*      */     this.button10.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/*      */             ShopScr.this.button10ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     this.button11.setBackground(new Color(153, 153, 0));
/*      */     this.button11.setForeground(new Color(255, 255, 255));
/*      */     this.button11.setFont(new Font("SansSerif", 1, 12));
/*      */     this.button12.setBackground(new Color(255, 51, 0));
/*      */     this.button12.setForeground(new Color(255, 255, 255));
/*      */     this.button12.setText("Xóa");
/*      */     this.button12.setFont(new Font("SansSerif", 1, 12));
/*      */     this.button12.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/*      */             ShopScr.this.button12ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     this.lblIconSpec.setHorizontalAlignment(0);
/*      */     this.tblListItem.setModel(new DefaultTableModel(new Object[0][], (Object[])new String[0]));
/*      */     this.tblListItem.addMouseListener(new MouseAdapter() {
/*      */           public void mouseClicked(MouseEvent evt) {
/*      */             ShopScr.this.tblListItemMouseClicked(evt);
/*      */           }
/*      */         });
/*      */     this.tblListItem.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/*      */             ShopScr.this.tblListItemKeyPressed(evt);
/*      */           }
/*      */           
/*      */           public void keyReleased(KeyEvent evt) {
/*      */             ShopScr.this.tblListItemKeyReleased(evt);
/*      */           }
/*      */         });
/*      */     this.jScrollPane3.setViewportView(this.tblListItem);
/*      */     this.button13.setBackground(new Color(153, 153, 0));
/*      */     this.button13.setForeground(new Color(255, 255, 255));
/*      */     this.button13.setText("Item option");
/*      */     this.button13.setFont(new Font("SansSerif", 1, 12));
/*      */     this.button13.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/*      */             ShopScr.this.button13ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     this.txtInfoItem.setColumns(20);
/*      */     this.txtInfoItem.setRows(5);
/*      */     this.jScrollPane4.setViewportView(this.txtInfoItem);
/*      */     GroupLayout jPanel3Layout = new GroupLayout(this.jPanel3);
/*      */     this.jPanel3.setLayout(jPanel3Layout);
/*      */     jPanel3Layout.setHorizontalGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel3Layout.createSequentialGroup().addContainerGap().addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel3Layout.createSequentialGroup().addComponent(this.jLabel11, -2, 103, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtCost)).addGroup(jPanel3Layout.createSequentialGroup().addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addGroup(jPanel3Layout.createSequentialGroup().addComponent(this.jLabel6, -2, 103, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.cboShop2, -2, 192, -2)).addGroup(jPanel3Layout.createSequentialGroup().addComponent(this.jLabel7, -2, 103, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.cboTab2, -2, 192, -2)).addComponent(this.jSeparator1).addGroup(jPanel3Layout.createSequentialGroup().addComponent(this.jLabel8, -2, 103, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtFindItemTemplate)).addGroup(GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup().addComponent(this.jLabel9, -2, 103, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, -1, 32767).addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addGroup(jPanel3Layout.createSequentialGroup().addComponent(this.chkNew, -2, 103, -2).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addComponent(this.chkSell, -1, -1, 32767)).addComponent(this.cboItemTemplate, -2, 192, -2)))).addGap(0, 0, 32767)).addGroup(jPanel3Layout.createSequentialGroup().addComponent(this.jLabel10, -2, 103, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.cboTypeSell, 0, -1, 32767)).addGroup(jPanel3Layout.createSequentialGroup().addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jLabel12, -2, 103, -2).addComponent(this.lblIconSpec, -2, 97, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel3Layout.createSequentialGroup().addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel3Layout.createSequentialGroup().addComponent((Component)this.button9, -2, 93, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button10, -2, 93, -2)).addGroup(jPanel3Layout.createSequentialGroup().addComponent((Component)this.button12, -2, 93, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button11, -2, 93, -2))).addGap(0, 0, 32767)).addComponent(this.cboIconSpec, 0, -1, 32767)))).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jSeparator2, -2, 12, -2).addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel3Layout.createSequentialGroup().addGap(79, 79, 79).addComponent((Component)this.button13, -2, 93, -2)).addGroup(GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup().addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jScrollPane4, -2, -1, -2))).addGroup(jPanel3Layout.createSequentialGroup().addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.avatarItem, -2, 168, -2))).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addComponent(this.jScrollPane3, -2, 488, -2)));
/*      */     jPanel3Layout.linkSize(0, new Component[] { this.cboItemTemplate, this.cboShop2, this.cboTab2, this.txtFindItemTemplate });
/*      */     jPanel3Layout.setVerticalGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jSeparator2).addGroup(jPanel3Layout.createSequentialGroup().addContainerGap().addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel3Layout.createSequentialGroup().addComponent(this.avatarItem, -2, 191, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jScrollPane4, -2, 263, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, -1, 32767).addComponent((Component)this.button13, -2, 40, -2)).addGroup(jPanel3Layout.createSequentialGroup().addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(this.cboShop2).addComponent(this.jLabel6, -2, 40, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel7, -2, 40, -2).addComponent(this.cboTab2, -2, -1, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jSeparator1, -2, 10, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel8, -2, 40, -2).addComponent(this.txtFindItemTemplate, -2, -1, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel9, -2, 40, -2).addComponent(this.cboItemTemplate, -2, -1, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.chkSell, -2, 34, -2).addComponent(this.chkNew, -2, 34, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel10, -2, 40, -2).addComponent(this.cboTypeSell, -2, -1, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel11, -2, 40, -2).addComponent(this.txtCost, -2, -1, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel12, -2, 40, -2).addComponent(this.cboIconSpec, -2, -1, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel3Layout.createSequentialGroup().addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent((Component)this.button9, -2, 40, -2).addComponent((Component)this.button10, -2, 40, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent((Component)this.button12, -2, 40, -2).addComponent((Component)this.button11, -2, 40, -2))).addComponent(this.lblIconSpec, -2, 94, -2))))).addComponent(this.jScrollPane3));
/*      */     jPanel3Layout.linkSize(1, new Component[] { this.cboItemTemplate, this.cboShop2, this.cboTab2, this.jLabel7, this.txtFindItemTemplate });
/*      */     jPanel3Layout.linkSize(1, new Component[] { this.cboTypeSell, this.jLabel10 });
/*      */     jPanel3Layout.linkSize(1, new Component[] { this.jLabel11, this.txtCost });
/*      */     jPanel3Layout.linkSize(1, new Component[] { this.cboIconSpec, this.jLabel12 });
/*      */     this.jTabbedPane1.addTab("Item shop", this.jPanel3);
/*      */     GroupLayout layout = new GroupLayout(getContentPane());
/*      */     getContentPane().setLayout(layout);
/*      */     layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jTabbedPane1));
/*      */     layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jTabbedPane1));
/*      */     pack();
/*      */   }
/*      */   
/*      */   private void cboNpcTemplateActionPerformed(ActionEvent evt) {
/*      */     NpcTemplate npcTemplate = Manager.gI().getNpcTemplates().get(this.cboNpcTemplate.getSelectedIndex());
/*      */     try {
/*      */       BufferedImage icon = Util.getImageById(npcTemplate.getAvatar(), 4);
/*      */       this.avatarNpc.setIcon(new ImageIcon(icon));
/*      */     } catch (Exception ex) {
/*      */       ex.printStackTrace();
/*      */     } 
/*      */   }
/*      */   
/*      */   private void button1ActionPerformed(ActionEvent evt) {
/*      */     if (this.txtTagName.getText().equals("")) {
/*      */       NotifyUtil.showMessageDialog(null, "Vui lòng nhập tên thẻ");
/*      */       this.txtTagName.requestFocus();
/*      */       return;
/*      */     } 
/*      */     try {
/*      */       GirlkunResultSet rs = GirlkunDB.executeQuery("GIRLKUN", "select * from shop where tag_name = ?", new Object[] { this.txtTagName.getText() });
/*      */       if (rs.next()) {
/*      */         NotifyUtil.showMessageDialog(null, "Tên thẻ đã tồn tại, vui lòng nhập tên khác");
/*      */         this.txtTagName.requestFocus();
/*      */         return;
/*      */       } 
/*      */       GirlkunDB.executeUpdate("GIRLKUN", "insert into shop (npc_id, tag_name, type_shop) values ()", new Object[] { Integer.valueOf(((NpcTemplate)Manager.gI().getNpcTemplates().get(this.cboNpcTemplate.getSelectedIndex())).getId()), this.txtTagName.getText(), Integer.valueOf(this.cboTypeShop.getSelectedIndex()) });
/*      */       loadData();
/*      */       NotifyUtil.showMessageDialog(null, "Thêm thành công!");
/*      */     } catch (Exception e) {
/*      */       e.printStackTrace();
/*      */     } 
/*      */   }
/*      */   
/*      */   private void tblListShopMouseClicked(MouseEvent evt) {
/*      */     this.indexShop = this.tblListShop.getSelectedRow();
/*      */     if (this.indexShop != -1) {
/*      */       Shop shop = this.shops.get(this.indexShop);
/*      */       this.cboNpcTemplate.setSelectedIndex(shop.getNpc().getId());
/*      */       this.txtTagName.setText(shop.getTagName());
/*      */       this.cboTypeShop.setSelectedIndex(shop.getTypeShop());
/*      */     } 
/*      */   }
/*      */   
/*      */   private void tblListShopKeyPressed(KeyEvent evt) {
/*      */     this.indexShop = this.tblListShop.getSelectedRow();
/*      */     if (this.indexShop != -1) {
/*      */       Shop shop = this.shops.get(this.indexShop);
/*      */       this.cboNpcTemplate.setSelectedIndex(shop.getNpc().getId());
/*      */       this.txtTagName.setText(shop.getTagName());
/*      */       this.cboTypeShop.setSelectedIndex(shop.getTypeShop());
/*      */     } 
/*      */   }
/*      */   
/*      */   private void tblListShopKeyReleased(KeyEvent evt) {
/*      */     this.indexShop = this.tblListShop.getSelectedRow();
/*      */     if (this.indexShop != -1) {
/*      */       Shop shop = this.shops.get(this.indexShop);
/*      */       this.cboNpcTemplate.setSelectedIndex(shop.getNpc().getId());
/*      */       this.txtTagName.setText(shop.getTagName());
/*      */       this.cboTypeShop.setSelectedIndex(shop.getTypeShop());
/*      */     } 
/*      */   }
/*      */   
/*      */   private void button2ActionPerformed(ActionEvent evt) {
/*      */     if (this.indexShop == -1) {
/*      */       NotifyUtil.showMessageDialog(null, "Vui lòng chọn shop cần sửa");
/*      */       return;
/*      */     } 
/*      */     Shop shop = this.shops.get(this.indexShop);
/*      */     if (this.txtTagName.getText().equals("")) {
/*      */       NotifyUtil.showMessageDialog(null, "Vui lòng nhập tên thẻ");
/*      */       this.txtTagName.requestFocus();
/*      */       return;
/*      */     } 
/*      */     try {
/*      */       if (this.txtTagName.getText().equals(shop.getTagName()) || GirlkunDB.executeQuery("select * from shop where tag_name = ?", this.txtTagName.getText()).next()) {
/*      */         NotifyUtil.showMessageDialog(null, "Tên thẻ đã tồn tại, vui lòng nhập tên khác");
/*      */         this.txtTagName.requestFocus();
/*      */         return;
/*      */       } 
/*      */     } catch (Exception exception) {}
/*      */     try {
/*      */       GirlkunDB.executeUpdate("GIRLKUN", "update shop set npc_id = ?, tag_name = ?, type_shop = ? where id = ?", new Object[] { Integer.valueOf(((NpcTemplate)Manager.gI().getNpcTemplates().get(this.cboNpcTemplate.getSelectedIndex())).getId()), this.txtTagName.getText(), Integer.valueOf(this.cboTypeShop.getSelectedIndex()), Integer.valueOf(shop.getId()) });
/*      */       loadData();
/*      */       NotifyUtil.showMessageDialog(null, "Sửa thành công!");
/*      */     } catch (Exception exception) {}
/*      */   }
/*      */   
/*      */   private void button3ActionPerformed(ActionEvent evt) {
/*      */     if (this.indexShop == -1) {
/*      */       NotifyUtil.showMessageDialog(null, "Vui lòng chọn shop cần xóa");
/*      */       return;
/*      */     } 
/*      */     if (NotifyUtil.showConfirmDialog(null, "Bạn có chắc chắn muốn xóa shop này?\nTất cả dữ liệu của shop này sẽ mất hết không thể khôi phục!") == 0) {
/*      */       Shop shop = this.shops.get(this.indexShop);
/*      */       try {
/*      */         GirlkunDB.executeUpdate("GIRLKUN", "delete from shop where id = ?", new Object[] { Integer.valueOf(shop.getId()) });
/*      */         loadData();
/*      */         NotifyUtil.showMessageDialog(null, "Xóa thành công!");
/*      */       } catch (Exception exception) {}
/*      */     } 
/*      */   }
/*      */   
/*      */   private void cboShopActionPerformed(ActionEvent evt) {
/*      */     try {
/*      */       this.modelTabShop.setRowCount(0);
/*      */       Shop shop = this.shops.get(this.cboShop.getSelectedIndex());
/*      */       for (TabShop tabShop : shop.getTabShops()) {
/*      */         this.modelTabShop.addRow(new Object[] { Integer.valueOf(tabShop.getId()), tabShop.getName() });
/*      */       } 
/*      */       try {
/*      */         BufferedImage icon = Util.getImageById(shop.getNpc().getAvatar(), 4);
/*      */         this.avatarNpc1.setIcon(new ImageIcon(icon));
/*      */       } catch (Exception ex) {
/*      */         ex.printStackTrace();
/*      */       } 
/*      */     } catch (Exception exception) {}
/*      */   }
/*      */   
/*      */   private void button5ActionPerformed(ActionEvent evt) {
/*      */     if (this.txtTabName.getText().equals("")) {
/*      */       NotifyUtil.showMessageDialog(null, "Vui lòng nhập tab name");
/*      */       this.txtTabName.requestFocus();
/*      */       return;
/*      */     } 
/*      */     try {
/*      */       int index = this.cboShop.getSelectedIndex();
/*      */       GirlkunDB.executeUpdate("GIRLKUN", "insert into tab_shop (shop_id,name) values ()", new Object[] { Integer.valueOf(((Shop)this.shops.get(index)).getId()), this.txtTabName.getText() });
/*      */       loadData();
/*      */       this.cboShop.setSelectedIndex(index);
/*      */       NotifyUtil.showMessageDialog(null, "Thêm thành công!");
/*      */     } catch (Exception exception) {}
/*      */   }
/*      */   
/*      */   private void button6ActionPerformed(ActionEvent evt) {
/*      */     if (this.indexTab == -1) {
/*      */       NotifyUtil.showMessageDialog(null, "Vui lòng chọn tab cần sửa");
/*      */       return;
/*      */     } 
/*      */     if (this.txtTabName.getText().equals("")) {
/*      */       NotifyUtil.showMessageDialog(null, "Vui lòng nhập tên tab");
/*      */       this.txtTabName.requestFocus();
/*      */       return;
/*      */     } 
/*      */     int index = this.cboShop.getSelectedIndex();
/*      */     TabShop tabShop = ((Shop)this.shops.get(index)).getTabShops().get(this.indexTab);
/*      */     try {
/*      */       GirlkunDB.executeUpdate("GIRLKUN", "update tab_shop set name = ? where id = ?", new Object[] { this.txtTabName.getText(), Integer.valueOf(tabShop.getId()) });
/*      */       loadData();
/*      */       this.cboShop.setSelectedIndex(index);
/*      */       NotifyUtil.showMessageDialog(null, "Sửa thành công!");
/*      */     } catch (Exception exception) {}
/*      */   }
/*      */   
/*      */   private void button8ActionPerformed(ActionEvent evt) {
/*      */     if (this.indexTab == -1) {
/*      */       NotifyUtil.showMessageDialog(null, "Vui lòng chọn tab cần xóa");
/*      */       return;
/*      */     } 
/*      */     if (NotifyUtil.showConfirmDialog(null, "Bạn có chắc chắn muốn xóa tab này?\nTất cả dữ liệu của tab này sẽ mất hết không thể khôi phục!") == 0) {
/*      */       int index = this.cboShop.getSelectedIndex();
/*      */       TabShop tabShop = ((Shop)this.shops.get(index)).getTabShops().get(this.indexTab);
/*      */       try {
/*      */         GirlkunDB.executeUpdate("GIRLKUN", "delete from tab_shop where id = ?", new Object[] { Integer.valueOf(tabShop.getId()) });
/*      */         loadData();
/*      */         this.cboShop.setSelectedIndex(index);
/*      */         NotifyUtil.showMessageDialog(null, "Xóa thành công!");
/*      */       } catch (Exception exception) {}
/*      */     } 
/*      */   }
/*      */   
/*      */   private void tblListTabShopMouseClicked(MouseEvent evt) {
/*      */     this.indexTab = this.tblListTabShop.getSelectedRow();
/*      */     if (this.indexTab != -1) {
/*      */       TabShop tabShop = ((Shop)this.shops.get(this.cboShop.getSelectedIndex())).getTabShops().get(this.indexTab);
/*      */       this.txtTabName.setText(tabShop.getName());
/*      */     } 
/*      */   }
/*      */   
/*      */   private void tblListTabShopKeyPressed(KeyEvent evt) {
/*      */     this.indexTab = this.tblListTabShop.getSelectedRow();
/*      */     if (this.indexTab != -1) {
/*      */       TabShop tabShop = ((Shop)this.shops.get(this.cboShop.getSelectedIndex())).getTabShops().get(this.indexTab);
/*      */       this.txtTabName.setText(tabShop.getName());
/*      */     } 
/*      */   }
/*      */   
/*      */   private void tblListTabShopKeyReleased(KeyEvent evt) {
/*      */     this.indexTab = this.tblListTabShop.getSelectedRow();
/*      */     if (this.indexTab != -1) {
/*      */       TabShop tabShop = ((Shop)this.shops.get(this.cboShop.getSelectedIndex())).getTabShops().get(this.indexTab);
/*      */       this.txtTabName.setText(tabShop.getName());
/*      */     } 
/*      */   }
/*      */   
/*      */   private void cboShop2ActionPerformed(ActionEvent evt) {
/*      */     try {
/*      */       Shop shop = this.shops.get(this.cboShop2.getSelectedIndex());
/*      */       this.cboTab2.removeAllItems();
/*      */       for (TabShop tabShop : shop.getTabShops())
/*      */         this.cboTab2.addItem(tabShop.getId() + " - " + tabShop.getName()); 
/*      */     } catch (Exception exception) {}
/*      */   }
/*      */   
/*      */   private void cboTab2ActionPerformed(ActionEvent evt) {
/*      */     try {
/*      */       TabShop tabShop = ((Shop)this.shops.get(this.cboShop2.getSelectedIndex())).getTabShops().get(this.cboTab2.getSelectedIndex());
/*      */       this.modelItemShop.setRowCount(0);
/*      */       for (ItemShop is : tabShop.getItems()) {
/*      */         String cost = is.getCost() + "";
/*      */         if (is.getCost() == 0) {
/*      */           cost = "Miễn phí";
/*      */         } else {
/*      */           switch (is.getTypeSell()) {
/*      */             case 0:
/*      */               cost = cost + " vàng";
/*      */               break;
/*      */             case 1:
/*      */               cost = cost + " ngọc";
/*      */               break;
/*      */             case 2:
/*      */               cost = cost + " " + is.getItemSpec().getName();
/*      */               break;
/*      */           } 
/*      */         } 
/*      */         this.modelItemShop.addRow(new Object[] { Integer.valueOf(is.getId()), is.getItemTemplate().getName() + (is.isNew() ? " (New)" : ""), is.isSell() ? "Sell" : "", cost });
/*      */       } 
/*      */     } catch (Exception exception) {}
/*      */   }
/*      */   
/*      */   private void cboItemTemplateActionPerformed(ActionEvent evt) {
/*      */     try {
/*      */       ItemTemplate itemTemplate = Manager.gI().getItemTemplates().get(this.cboItemTemplate.getSelectedIndex());
/*      */       Image image = Util.getImageById(itemTemplate.getIconId(), 4).getScaledInstance(this.avatarItem.getWidth() / 2, this.avatarItem.getHeight() / 2, 4);
/*      */       BufferedImage img = new BufferedImage(this.avatarItem.getWidth(), this.avatarItem.getHeight(), 2);
/*      */       Graphics2D g = img.createGraphics();
/*      */       g.drawImage(image, 0, 0, (ImageObserver)null);
/*      */       g.setColor(Color.YELLOW);
/*      */       g.drawString("Giá vàng gốc: " + itemTemplate.getGold(), 10, this.avatarItem.getHeight() - 50);
/*      */       g.setColor(Color.CYAN);
/*      */       g.drawString("Giá ngọc gốc: " + itemTemplate.getGem(), 10, this.avatarItem.getHeight() - 30);
/*      */       g.setColor(Color.RED);
/*      */       g.drawString("Hành tinh: " + ((itemTemplate.getGender() == 0) ? "Trái đất" : ((itemTemplate.getGender() == 1) ? "Namếc" : ((itemTemplate.getGender() == 2) ? "Xayda" : "All"))), 10, this.avatarItem.getHeight() - 10);
/*      */       this.avatarItem.setIcon(new ImageIcon(img));
/*      */     } catch (Exception exception) {}
/*      */   }
/*      */   
/*      */   private void txtFindItemTemplateKeyPressed(KeyEvent evt) {
/*      */     findItemTemplate();
/*      */   }
/*      */   
/*      */   private void txtFindItemTemplateKeyReleased(KeyEvent evt) {
/*      */     findItemTemplate();
/*      */   }
/*      */   
/*      */   private void cboTypeSellActionPerformed(ActionEvent evt) {}
/*      */   
/*      */   private void txtCostKeyPressed(KeyEvent evt) {}
/*      */   
/*      */   private void txtCostKeyReleased(KeyEvent evt) {}
/*      */   
/*      */   private void cboIconSpecActionPerformed(ActionEvent evt) {
/*      */     try {
/*      */       this.lblIconSpec.setIcon(new ImageIcon(Util.getImageById(((ItemTemplate)Manager.gI().getItemTemplates().get(this.cboIconSpec.getSelectedIndex())).getIconId(), 4).getScaledInstance(this.lblIconSpec.getWidth() / 2, this.lblIconSpec.getHeight() / 2, 4)));
/*      */     } catch (Exception exception) {}
/*      */   }
/*      */   
/*      */   private void button9ActionPerformed(ActionEvent evt) {
/*      */     addItemToShop();
/*      */   }
/*      */   
/*      */   private void addItemToShop() {
/*      */     if (this.txtCost.getText().equals("")) {
/*      */       NotifyUtil.showMessageDialog(null, "Vui lòng nhập giá item");
/*      */       this.txtCost.requestFocus();
/*      */       return;
/*      */     } 
/*      */     int cost = -1;
/*      */     try {
/*      */       cost = Integer.parseInt(this.txtCost.getText());
/*      */     } catch (Exception e) {
/*      */       NotifyUtil.showMessageDialog(null, "Vui lòng nhập đúng giá item");
/*      */       this.txtCost.requestFocus();
/*      */       return;
/*      */     } 
/*      */     if (cost < 0) {
/*      */       NotifyUtil.showMessageDialog(null, "Vui lòng nhập giá item >= 0");
/*      */       this.txtCost.requestFocus();
/*      */       return;
/*      */     } 
/*      */     int idShop = this.cboShop2.getSelectedIndex();
/*      */     int idTab = this.cboTab2.getSelectedIndex();
/*      */     try {
/*      */       GirlkunDB.executeUpdate("GIRLKUN", "insert into item_shop (tab_id, temp_id, is_new, is_sell, type_sell, cost, item_spec) values ()", new Object[] { Integer.valueOf(((TabShop)((Shop)this.shops.get(idShop)).getTabShops().get(idTab)).getId()), Integer.valueOf(((ItemTemplate)Manager.gI().getItemTemplates().get(this.cboItemTemplate.getSelectedIndex())).getId()), Boolean.valueOf(this.chkNew.isSelected()), Boolean.valueOf(this.chkSell.isSelected()), Integer.valueOf(this.cboTypeSell.getSelectedIndex()), Integer.valueOf(cost), Integer.valueOf(this.cboIconSpec.getSelectedIndex()) });
/*      */       loadData();
/*      */       this.cboShop2.setSelectedIndex(idShop);
/*      */       this.cboTab2.setSelectedIndex(idTab);
/*      */       NotifyUtil.showMessageDialog(null, "Thêm thành công!");
/*      */     } catch (Exception exception) {}
/*      */   }
/*      */   
/*      */   private void button10ActionPerformed(ActionEvent evt) {
/*      */     if (this.index == -1) {
/*      */       NotifyUtil.showMessageDialog(null, "Vui lòng chọn item cần sửa");
/*      */       return;
/*      */     } 
/*      */     int cost = -1;
/*      */     try {
/*      */       cost = Integer.parseInt(this.txtCost.getText());
/*      */     } catch (Exception e) {
/*      */       NotifyUtil.showMessageDialog(null, "Vui lòng nhập đúng giá item");
/*      */       this.txtCost.requestFocus();
/*      */       return;
/*      */     } 
/*      */     if (cost < 0) {
/*      */       NotifyUtil.showMessageDialog(null, "Vui lòng nhập giá item >= 0");
/*      */       this.txtCost.requestFocus();
/*      */       return;
/*      */     } 
/*      */     int idShop = this.cboShop2.getSelectedIndex();
/*      */     int idTab = this.cboTab2.getSelectedIndex();
/*      */     try {
/*      */       ItemShop is = ((TabShop)((Shop)this.shops.get(idShop)).getTabShops().get(idTab)).getItems().get(this.index);
/*      */       GirlkunDB.executeUpdate("GIRLKUN", "update item_shop set temp_id = ?, is_new = ?, is_sell = ?, type_sell = ?, cost = ?, item_spec = ? where id = ?", new Object[] { Integer.valueOf(((ItemTemplate)Manager.gI().getItemTemplates().get(this.cboItemTemplate.getSelectedIndex())).getId()), Boolean.valueOf(this.chkNew.isSelected()), Boolean.valueOf(this.chkSell.isSelected()), Integer.valueOf(this.cboTypeSell.getSelectedIndex()), Integer.valueOf(cost), Integer.valueOf(this.cboIconSpec.getSelectedIndex()), Integer.valueOf(is.getId()) });
/*      */       loadData();
/*      */       this.cboShop2.setSelectedIndex(idShop);
/*      */       this.cboTab2.setSelectedIndex(idTab);
/*      */       NotifyUtil.showMessageDialog(null, "Sửa thành công!");
/*      */     } catch (Exception exception) {}
/*      */   }
/*      */   
/*      */   private void button12ActionPerformed(ActionEvent evt) {
/*      */     if (this.index == -1) {
/*      */       NotifyUtil.showMessageDialog(null, "Vui lòng chọn item cần xóa");
/*      */       return;
/*      */     } 
/*      */     int idShop = this.cboShop2.getSelectedIndex();
/*      */     int idTab = this.cboTab2.getSelectedIndex();
/*      */     int idItem = this.index;
/*      */     try {
/*      */       if (NotifyUtil.showConfirmDialog(null, "Bạn có chắc chắn muốn xóa item này?\nTất cả dữ liệu của item này sẽ mất hết không thể khôi phục!") == 0) {
/*      */         ItemShop is = ((TabShop)((Shop)this.shops.get(idShop)).getTabShops().get(idTab)).getItems().get(idItem);
/*      */         GirlkunDB.executeUpdate("GIRLKUN", "delete from item_shop where id = ?", new Object[] { Integer.valueOf(is.getId()) });
/*      */         loadData();
/*      */         this.cboShop2.setSelectedIndex(idShop);
/*      */         this.cboTab2.setSelectedIndex(idTab);
/*      */         NotifyUtil.showMessageDialog(null, "Xóa thành công!");
/*      */       } 
/*      */     } catch (Exception exception) {}
/*      */   }
/*      */   
/*      */   private void tblListItemMouseClicked(MouseEvent evt) {
/*      */     showInfoItemTable();
/*      */   }
/*      */   
/*      */   private void showInfoItemTable() {
/*      */     this.index = this.tblListItem.getSelectedRow();
/*      */     if (this.index != -1) {
/*      */       ItemShop is = ((TabShop)((Shop)this.shops.get(this.cboShop2.getSelectedIndex())).getTabShops().get(this.cboTab2.getSelectedIndex())).getItems().get(this.index);
/*      */       this.cboItemTemplate.setSelectedIndex(is.getItemTemplate().getId());
/*      */       this.chkNew.setSelected(is.isNew());
/*      */       this.chkSell.setSelected(is.isSell());
/*      */       this.cboTypeSell.setSelectedIndex(is.getTypeSell());
/*      */       this.txtCost.setText(is.getCost() + "");
/*      */       this.cboIconSpec.setSelectedIndex(is.getItemSpec().getId());
/*      */       this.txtInfoItem.setText("");
/*      */       for (ItemOption io : is.getOptions())
/*      */         this.txtInfoItem.append(io.getItemOptionTemplate().getId() + " - " + io.getItemOptionTemplate().getName().replaceAll("#", String.valueOf(io.getParam())) + "\n"); 
/*      */     } 
/*      */     try {
/*      */       if (this.itemShopOptionScr.isVisible()) {
/*      */         ItemShop is = ((TabShop)((Shop)this.shops.get(this.cboShop2.getSelectedIndex())).getTabShops().get(this.cboTab2.getSelectedIndex())).getItems().get(this.index);
/*      */         if (this.itemShopOptionScr == null)
/*      */           this.itemShopOptionScr = new ItemShopOption(); 
/*      */         this.itemShopOptionScr.show(is);
/*      */       } 
/*      */     } catch (Exception exception) {}
/*      */   }
/*      */   
/*      */   private void tblListItemKeyPressed(KeyEvent evt) {
/*      */     showInfoItemTable();
/*      */   }
/*      */   
/*      */   private void tblListItemKeyReleased(KeyEvent evt) {
/*      */     showInfoItemTable();
/*      */   }
/*      */   
/*      */   private void button13ActionPerformed(ActionEvent evt) {
/*      */     if (this.index == -1) {
/*      */       NotifyUtil.showMessageDialog(null, "Vui lòng chọn item");
/*      */       return;
/*      */     } 
/*      */     ItemShop is = ((TabShop)((Shop)this.shops.get(this.cboShop2.getSelectedIndex())).getTabShops().get(this.cboTab2.getSelectedIndex())).getItems().get(this.index);
/*      */     if (this.itemShopOptionScr == null)
/*      */       this.itemShopOptionScr = new ItemShopOption(); 
/*      */     this.itemShopOptionScr.show(is);
/*      */   }
/*      */   
/*      */   private void cboItemTemplateKeyReleased(KeyEvent evt) {
/*      */     if (evt.getKeyCode() == 10)
/*      */       addItemToShop(); 
/*      */   }
/*      */   
/*      */   private void findItemTemplate() {
/*      */     String text = this.txtFindItemTemplate.getText();
/*      */     try {
/*      */       int id = Integer.parseInt(text);
/*      */       for (int i = 0; i < Manager.gI().getItemTemplates().size(); i++) {
/*      */         if (((ItemTemplate)Manager.gI().getItemTemplates().get(i)).getId() == id) {
/*      */           this.cboItemTemplate.setSelectedIndex(i);
/*      */           break;
/*      */         } 
/*      */       } 
/*      */     } catch (Exception e) {
/*      */       for (int i = 0; i < Manager.gI().getItemTemplates().size(); i++) {
/*      */         try {
/*      */           String name = ((ItemTemplate)Manager.gI().getItemTemplates().get(i)).getName();
/*      */           if (StringUtil.removeAccent(name).toLowerCase().contains(StringUtil.removeAccent(text).toLowerCase())) {
/*      */             this.cboItemTemplate.setSelectedIndex(i);
/*      */             break;
/*      */           } 
/*      */         } catch (Exception exception) {}
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private void setup() {
/*      */     setTitle("Girlkun75 - Quản lý shop");
/*      */     setResizable(false);
/*      */     this.modelShop = new DefaultTableModel((Object[])new String[] { "Id", "Npc", "Tag name", "Type shop" }, 0) {
/*      */         public boolean isCellEditable(int row, int column) {
/*      */           return false;
/*      */         }
/*      */       };
/*      */     this.tblListShop.setModel(this.modelShop);
/*      */     this.modelTabShop = new DefaultTableModel((Object[])new String[] { "Tab id", "Tab name" }, 0) {
/*      */         public boolean isCellEditable(int row, int column) {
/*      */           return false;
/*      */         }
/*      */       };
/*      */     this.tblListTabShop.setModel(this.modelTabShop);
/*      */     this.modelItemShop = new DefaultTableModel((Object[])new String[] { "Id", "Name", "Sell", "Cost" }, 0) {
/*      */         public boolean isCellEditable(int row, int column) {
/*      */           return false;
/*      */         }
/*      */       };
/*      */     this.tblListItem.setModel(this.modelItemShop);
/*      */     for (NpcTemplate npc : Manager.gI().getNpcTemplates())
/*      */       this.cboNpcTemplate.addItem(npc.getId() + " - " + npc.getName()); 
/*      */     for (ItemTemplate itemTemplate : Manager.gI().getItemTemplates()) {
/*      */       this.cboItemTemplate.addItem(itemTemplate.getId() + " - " + itemTemplate.getName());
/*      */       this.cboIconSpec.addItem(itemTemplate.getId() + " - " + itemTemplate.getName());
/*      */     } 
/*      */   }
/*      */   
/*      */   private void loadData() {
/*      */     try {
/*      */       this.shops.clear();
/*      */       GirlkunResultSet rsShop = GirlkunDB.executeQuery("GIRLKUN", "select * from shop");
/*      */       while (rsShop.next()) {
/*      */         Shop shop = new Shop(rsShop.getInt("id"), rsShop.getInt("npc_id"), rsShop.getString("tag_name"), rsShop.getInt("type_shop"));
/*      */         GirlkunResultSet rsTabShop = GirlkunDB.executeQuery("GIRLKUN", "select * from tab_shop where shop_id = ?", new Object[] { Integer.valueOf(shop.getId()) });
/*      */         while (rsTabShop.next()) {
/*      */           TabShop tabShop = new TabShop(shop, rsTabShop.getInt("id"), rsTabShop.getString("name"));
/*      */           GirlkunResultSet rsItemShop = GirlkunDB.executeQuery("GIRLKUN", "select * from item_shop where tab_id = ? order by create_time desc", new Object[] { Integer.valueOf(tabShop.getId()) });
/*      */           while (rsItemShop.next()) {
/*      */             ItemShop itemShop = new ItemShop(tabShop, rsItemShop.getInt("id"), rsItemShop.getInt("temp_id"), rsItemShop.getBoolean("is_new"), rsItemShop.getBoolean("is_sell"), rsItemShop.getInt("type_sell"), rsItemShop.getInt("cost"), Manager.gI().getItemTemplates().get(rsItemShop.getInt("item_spec")), rsItemShop.getTimestamp("create_time").getTime());
/*      */             GirlkunResultSet rsItemOption = GirlkunDB.executeQuery("GIRLKUN", "select * from item_shop_option where item_shop_id = ?", new Object[] { Integer.valueOf(itemShop.getId()) });
/*      */             while (rsItemOption.next()) {
/*      */               ItemOption io = new ItemOption(rsItemOption.getInt("option_id"), rsItemOption.getInt("param"));
/*      */               itemShop.getOptions().add(io);
/*      */             } 
/*      */             tabShop.getItems().add(itemShop);
/*      */           } 
/*      */           shop.getTabShops().add(tabShop);
/*      */         } 
/*      */         this.shops.add(shop);
/*      */       } 
/*      */       Logger.warning("Done load data shop!\n");
/*      */     } catch (Exception e) {
/*      */       e.printStackTrace();
/*      */     } 
/*      */     this.modelShop.setRowCount(0);
/*      */     this.cboShop.removeAllItems();
/*      */     this.cboShop2.removeAllItems();
/*      */     for (Shop shop : this.shops) {
/*      */       this.modelShop.addRow(new Object[] { Integer.valueOf(shop.getId()), shop.getNpc().getId() + " - " + shop.getNpc().getName(), shop.getTagName(), (shop.getTypeShop() == 0) ? "NORMAL" : ((shop.getTypeShop() == 1) ? "UNKNOW" : "SPEC") });
/*      */       this.cboShop.addItem(shop.getId() + " - " + shop.getTagName());
/*      */       this.cboShop2.addItem(shop.getId() + " - " + shop.getTagName());
/*      */     } 
/*      */     this.indexShop = -1;
/*      */     this.indexTab = -1;
/*      */     this.index = -1;
/*      */   }
/*      */ }


/* Location:              D:\nro\server_luxu_nrp\vemap\GirlkunToolCBRO.jar!\com\girlkun\tool\screens\shop_scr\ShopScr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */