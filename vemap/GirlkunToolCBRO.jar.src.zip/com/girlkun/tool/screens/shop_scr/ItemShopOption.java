/*     */ package com.girlkun.tool.screens.shop_scr;
/*     */ 
/*     */ import com.girlkun.button.Button;
/*     */ import com.girlkun.database.GirlkunDB;
/*     */ import com.girlkun.tool.entities.item.ItemOption;
/*     */ import com.girlkun.tool.entities.item.ItemOptionTemplate;
/*     */ import com.girlkun.tool.entities.shop.ItemShop;
/*     */ import com.girlkun.tool.main.Manager;
/*     */ import com.girlkun.tool.utils.NotifyUtil;
/*     */ import com.girlkun.tool.utils.StringUtil;
/*     */ import com.girlkun.tool.utils.Util;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Font;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.KeyAdapter;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import javax.swing.GroupLayout;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.LayoutStyle;
/*     */ import javax.swing.table.DefaultTableModel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ItemShopOption
/*     */   extends JFrame
/*     */ {
/*     */   private ItemShop is;
/*     */   private DefaultTableModel model;
/*     */   private int index;
/*     */   private Button button10;
/*     */   private Button button11;
/*     */   private Button button12;
/*     */   private Button button13;
/*     */   private Button button14;
/*     */   private Button button15;
/*     */   private Button button16;
/*     */   private Button button17;
/*     */   private Button button18;
/*     */   private Button button19;
/*     */   private Button button20;
/*     */   private Button button21;
/*     */   private Button button22;
/*     */   private Button button23;
/*     */   private Button button24;
/*     */   private Button button9;
/*     */   private JComboBox<String> cboItemOptionTemplate;
/*     */   private JComboBox<String> cboTab2;
/*     */   private JLabel jLabel10;
/*     */   private JLabel jLabel6;
/*     */   private JLabel jLabel7;
/*     */   private JLabel jLabel8;
/*     */   private JLabel jLabel9;
/*     */   private JScrollPane jScrollPane1;
/*     */   private JLabel lblItem;
/*     */   private JLabel lblNameItem;
/*     */   private JTable tblListOption;
/*     */   private JTextField txtFindItemOptionTemplate;
/*     */   private JTextField txtParam;
/*     */   
/*     */   public ItemShopOption() {
/* 667 */     this.index = -1;
/*     */     initComponents();
/*     */     setup();
/*     */     setDefaultCloseOperation(1);
/*     */   }
/*     */   
/*     */   private void initComponents() {
/*     */     this.jLabel6 = new JLabel();
/*     */     this.jLabel7 = new JLabel();
/*     */     this.cboTab2 = new JComboBox<>();
/*     */     this.jLabel8 = new JLabel();
/*     */     this.txtFindItemOptionTemplate = new JTextField();
/*     */     this.jLabel9 = new JLabel();
/*     */     this.cboItemOptionTemplate = new JComboBox<>();
/*     */     this.lblNameItem = new JLabel();
/*     */     this.lblItem = new JLabel();
/*     */     this.jScrollPane1 = new JScrollPane();
/*     */     this.tblListOption = new JTable();
/*     */     this.button9 = new Button();
/*     */     this.button10 = new Button();
/*     */     this.button12 = new Button();
/*     */     this.button11 = new Button();
/*     */     this.jLabel10 = new JLabel();
/*     */     this.txtParam = new JTextField();
/*     */     this.button13 = new Button();
/*     */     this.button14 = new Button();
/*     */     this.button15 = new Button();
/*     */     this.button16 = new Button();
/*     */     this.button17 = new Button();
/*     */     this.button18 = new Button();
/*     */     this.button19 = new Button();
/*     */     this.button20 = new Button();
/*     */     this.button21 = new Button();
/*     */     this.button22 = new Button();
/*     */     this.button23 = new Button();
/*     */     this.button24 = new Button();
/*     */     setDefaultCloseOperation(3);
/*     */     this.jLabel6.setFont(new Font("SansSerif", 1, 12));
/*     */     this.jLabel6.setText("Item");
/*     */     this.jLabel7.setFont(new Font("SansSerif", 1, 12));
/*     */     this.jLabel7.setText("Tab");
/*     */     this.cboTab2.setFont(new Font("SansSerif", 1, 12));
/*     */     this.cboTab2.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/*     */             ItemShopOption.this.cboTab2ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     this.jLabel8.setFont(new Font("SansSerif", 1, 12));
/*     */     this.jLabel8.setText("Find option");
/*     */     this.txtFindItemOptionTemplate.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/*     */             ItemShopOption.this.txtFindItemOptionTemplateKeyPressed(evt);
/*     */           }
/*     */           
/*     */           public void keyReleased(KeyEvent evt) {
/*     */             ItemShopOption.this.txtFindItemOptionTemplateKeyReleased(evt);
/*     */           }
/*     */         });
/*     */     this.jLabel9.setFont(new Font("SansSerif", 1, 12));
/*     */     this.jLabel9.setText("Option template");
/*     */     this.cboItemOptionTemplate.setFont(new Font("SansSerif", 1, 12));
/*     */     this.cboItemOptionTemplate.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/*     */             ItemShopOption.this.cboItemOptionTemplateActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     this.lblItem.setHorizontalAlignment(0);
/*     */     this.tblListOption.setFont(new Font("SansSerif", 1, 12));
/*     */     this.tblListOption.setModel(new DefaultTableModel(new Object[0][], (Object[])new String[0]));
/*     */     this.tblListOption.addMouseListener(new MouseAdapter() {
/*     */           public void mouseClicked(MouseEvent evt) {
/*     */             ItemShopOption.this.tblListOptionMouseClicked(evt);
/*     */           }
/*     */         });
/*     */     this.tblListOption.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/*     */             ItemShopOption.this.tblListOptionKeyPressed(evt);
/*     */           }
/*     */           
/*     */           public void keyReleased(KeyEvent evt) {
/*     */             ItemShopOption.this.tblListOptionKeyReleased(evt);
/*     */           }
/*     */         });
/*     */     this.jScrollPane1.setViewportView(this.tblListOption);
/*     */     this.button9.setBackground(new Color(0, 153, 51));
/*     */     this.button9.setForeground(new Color(255, 255, 255));
/*     */     this.button9.setText("Thêm");
/*     */     this.button9.setFont(new Font("SansSerif", 1, 12));
/*     */     this.button9.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/*     */             ItemShopOption.this.button9ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     this.button10.setBackground(new Color(204, 0, 204));
/*     */     this.button10.setForeground(new Color(255, 255, 255));
/*     */     this.button10.setText("Sửa param");
/*     */     this.button10.setFont(new Font("SansSerif", 1, 12));
/*     */     this.button10.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/*     */             ItemShopOption.this.button10ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     this.button12.setBackground(new Color(255, 51, 0));
/*     */     this.button12.setForeground(new Color(255, 255, 255));
/*     */     this.button12.setText("Xóa");
/*     */     this.button12.setFont(new Font("SansSerif", 1, 12));
/*     */     this.button12.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/*     */             ItemShopOption.this.button12ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     this.button11.setBackground(new Color(153, 153, 0));
/*     */     this.button11.setForeground(new Color(255, 255, 255));
/*     */     this.button11.setFont(new Font("SansSerif", 1, 12));
/*     */     this.jLabel10.setFont(new Font("SansSerif", 1, 12));
/*     */     this.jLabel10.setText("Param");
/*     */     this.txtParam.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/*     */             ItemShopOption.this.txtParamKeyPressed(evt);
/*     */           }
/*     */           
/*     */           public void keyReleased(KeyEvent evt) {
/*     */             ItemShopOption.this.txtParamKeyReleased(evt);
/*     */           }
/*     */         });
/*     */     this.button13.setBackground(new Color(0, 153, 51));
/*     */     this.button13.setForeground(new Color(255, 255, 255));
/*     */     this.button13.setText("HP %");
/*     */     this.button13.setFont(new Font("SansSerif", 1, 12));
/*     */     this.button13.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/*     */             ItemShopOption.this.button13ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     this.button14.setBackground(new Color(0, 153, 51));
/*     */     this.button14.setForeground(new Color(255, 255, 255));
/*     */     this.button14.setText("KI %");
/*     */     this.button14.setFont(new Font("SansSerif", 1, 12));
/*     */     this.button14.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/*     */             ItemShopOption.this.button14ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     this.button15.setBackground(new Color(0, 153, 51));
/*     */     this.button15.setForeground(new Color(255, 255, 255));
/*     */     this.button15.setText("SĐ %");
/*     */     this.button15.setFont(new Font("SansSerif", 1, 12));
/*     */     this.button15.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/*     */             ItemShopOption.this.button15ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     this.button16.setBackground(new Color(0, 153, 51));
/*     */     this.button16.setForeground(new Color(255, 255, 255));
/*     */     this.button16.setText("HP");
/*     */     this.button16.setFont(new Font("SansSerif", 1, 12));
/*     */     this.button16.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/*     */             ItemShopOption.this.button16ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     this.button17.setBackground(new Color(0, 153, 51));
/*     */     this.button17.setForeground(new Color(255, 255, 255));
/*     */     this.button17.setText("KI");
/*     */     this.button17.setFont(new Font("SansSerif", 1, 12));
/*     */     this.button17.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/*     */             ItemShopOption.this.button17ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     this.button18.setBackground(new Color(0, 153, 51));
/*     */     this.button18.setForeground(new Color(255, 255, 255));
/*     */     this.button18.setText("Tấn công");
/*     */     this.button18.setFont(new Font("SansSerif", 1, 12));
/*     */     this.button18.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/*     */             ItemShopOption.this.button18ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     this.button19.setBackground(new Color(0, 153, 51));
/*     */     this.button19.setForeground(new Color(255, 255, 255));
/*     */     this.button19.setText("HP/30s");
/*     */     this.button19.setFont(new Font("SansSerif", 1, 12));
/*     */     this.button19.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/*     */             ItemShopOption.this.button19ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     this.button20.setBackground(new Color(0, 153, 51));
/*     */     this.button20.setForeground(new Color(255, 255, 255));
/*     */     this.button20.setText("KI/30s");
/*     */     this.button20.setFont(new Font("SansSerif", 1, 12));
/*     */     this.button20.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/*     */             ItemShopOption.this.button20ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     this.button21.setBackground(new Color(0, 153, 51));
/*     */     this.button21.setForeground(new Color(255, 255, 255));
/*     */     this.button21.setText("HSD");
/*     */     this.button21.setFont(new Font("SansSerif", 1, 12));
/*     */     this.button21.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/*     */             ItemShopOption.this.button21ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     this.button22.setBackground(new Color(0, 153, 51));
/*     */     this.button22.setForeground(new Color(255, 255, 255));
/*     */     this.button22.setText("Chí mạng");
/*     */     this.button22.setFont(new Font("SansSerif", 1, 12));
/*     */     this.button22.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/*     */             ItemShopOption.this.button22ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     this.button23.setBackground(new Color(0, 153, 51));
/*     */     this.button23.setForeground(new Color(255, 255, 255));
/*     */     this.button23.setText("HP K");
/*     */     this.button23.setFont(new Font("SansSerif", 1, 12));
/*     */     this.button23.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/*     */             ItemShopOption.this.button23ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     this.button24.setBackground(new Color(0, 153, 51));
/*     */     this.button24.setForeground(new Color(255, 255, 255));
/*     */     this.button24.setText("KI K");
/*     */     this.button24.setFont(new Font("SansSerif", 1, 12));
/*     */     this.button24.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/*     */             ItemShopOption.this.button24ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     GroupLayout layout = new GroupLayout(getContentPane());
/*     */     getContentPane().setLayout(layout);
/*     */     layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING).addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false).addGroup(GroupLayout.Alignment.LEADING, layout.createSequentialGroup().addComponent(this.jLabel10, -2, 103, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtParam)).addGroup(GroupLayout.Alignment.LEADING, layout.createSequentialGroup().addComponent(this.jLabel6, -2, 103, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.lblNameItem, -1, -1, 32767)).addGroup(GroupLayout.Alignment.LEADING, layout.createSequentialGroup().addComponent(this.jLabel7, -2, 103, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.cboTab2, -2, 192, -2)).addGroup(GroupLayout.Alignment.LEADING, layout.createSequentialGroup().addComponent(this.jLabel8, -2, 103, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtFindItemOptionTemplate)).addGroup(layout.createSequentialGroup().addComponent(this.jLabel9, -2, 103, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, -1, 32767).addComponent(this.cboItemOptionTemplate, -2, 192, -2))).addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addComponent((Component)this.button9, -2, 93, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button10, -2, 93, -2)).addGroup(layout.createSequentialGroup().addComponent((Component)this.button12, -2, 93, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button11, -2, 93, -2)))).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.lblItem, -2, 89, -2)).addGroup(layout.createSequentialGroup().addComponent((Component)this.button13, -2, 93, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button16, -2, 93, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button19, -2, 93, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button21, -2, 93, -2)).addGroup(layout.createSequentialGroup().addComponent((Component)this.button14, -2, 93, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button17, -2, 93, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button20, -2, 93, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button23, -2, 93, -2)).addGroup(layout.createSequentialGroup().addComponent((Component)this.button15, -2, 93, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button18, -2, 93, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button22, -2, 93, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button24, -2, 93, -2))).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 8, 32767).addComponent(this.jScrollPane1, -1, 430, 32767).addContainerGap()));
/*     */     layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jScrollPane1).addGroup(layout.createSequentialGroup().addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addGroup(layout.createSequentialGroup().addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(this.jLabel6, -1, 40, 32767).addComponent(this.lblNameItem, -1, -1, 32767)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel7, -2, 40, -2).addComponent(this.cboTab2, -2, -1, -2))).addComponent(this.lblItem, -1, -1, 32767)).addGap(22, 22, 22).addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel8, -2, 40, -2).addComponent(this.txtFindItemOptionTemplate, -2, -1, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel9, -2, 40, -2).addComponent(this.cboItemOptionTemplate, -2, -1, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel10, -2, 40, -2).addComponent(this.txtParam, -2, -1, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent((Component)this.button9, -2, 40, -2).addComponent((Component)this.button10, -2, 40, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent((Component)this.button12, -2, 40, -2).addComponent((Component)this.button11, -2, 40, -2)).addGap(53, 53, 53).addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent((Component)this.button13, -2, 40, -2).addComponent((Component)this.button16, -2, 40, -2).addComponent((Component)this.button19, -2, 40, -2).addComponent((Component)this.button21, -2, 40, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent((Component)this.button14, -2, 40, -2).addComponent((Component)this.button17, -2, 40, -2).addComponent((Component)this.button20, -2, 40, -2).addComponent((Component)this.button23, -2, 40, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent((Component)this.button15, -2, 40, -2).addComponent((Component)this.button18, -2, 40, -2).addComponent((Component)this.button22, -2, 40, -2).addComponent((Component)this.button24, -2, 40, -2)).addGap(0, 46, 32767))).addContainerGap()));
/*     */     layout.linkSize(1, new Component[] { this.cboItemOptionTemplate, this.cboTab2, this.jLabel6, this.jLabel7, this.jLabel8, this.jLabel9, this.txtFindItemOptionTemplate, this.txtParam });
/*     */     pack();
/*     */   }
/*     */   
/*     */   private void cboTab2ActionPerformed(ActionEvent evt) {}
/*     */   
/*     */   private void txtFindItemOptionTemplateKeyPressed(KeyEvent evt) {
/*     */     findItemOption();
/*     */   }
/*     */   
/*     */   private void txtFindItemOptionTemplateKeyReleased(KeyEvent evt) {
/*     */     findItemOption();
/*     */   }
/*     */   
/*     */   private void cboItemOptionTemplateActionPerformed(ActionEvent evt) {}
/*     */   
/*     */   private void button9ActionPerformed(ActionEvent evt) {
/*     */     if (this.txtParam.getText().equals("")) {
/*     */       NotifyUtil.showMessageDialog(this, "Vui lòng nhập chỉ số");
/*     */       this.txtParam.requestFocus();
/*     */       return;
/*     */     } 
/*     */     try {
/*     */       int param = Integer.parseInt(this.txtParam.getText());
/*     */       if (param < 0) {
/*     */         NotifyUtil.showMessageDialog(this, "Vui lòng nhập chỉ số >= 0");
/*     */         this.txtParam.requestFocus();
/*     */         return;
/*     */       } 
/*     */       for (ItemOption io : this.is.getOptions()) {
/*     */         if (io.getItemOptionTemplate().getId() == this.cboItemOptionTemplate.getSelectedIndex()) {
/*     */           NotifyUtil.showMessageDialog(this, "Option này đã có trong item");
/*     */           return;
/*     */         } 
/*     */       } 
/*     */       this.is.getOptions().add(new ItemOption(this.cboItemOptionTemplate.getSelectedIndex(), param));
/*     */       GirlkunDB.executeUpdate("GIRLKUN", "insert into item_shop_option (item_shop_id, option_id, param) values()", new Object[] { Integer.valueOf(this.is.getId()), Integer.valueOf(this.cboItemOptionTemplate.getSelectedIndex()), Integer.valueOf(param) });
/*     */       loadData();
/*     */       NotifyUtil.showMessageDialog(this, "Thêm thành công");
/*     */     } catch (Exception e) {
/*     */       NotifyUtil.showMessageDialog(this, "Vui lòng nhập đúng chỉ số");
/*     */       this.txtParam.requestFocus();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void button10ActionPerformed(ActionEvent evt) {
/*     */     if (this.index == -1) {
/*     */       NotifyUtil.showMessageDialog(null, "Vui lòng chọn option cần sửa");
/*     */       return;
/*     */     } 
/*     */     try {
/*     */       int param = Integer.parseInt(this.txtParam.getText());
/*     */       if (param < 0) {
/*     */         NotifyUtil.showMessageDialog(this, "Vui lòng nhập chỉ số >= 0");
/*     */         this.txtParam.requestFocus();
/*     */         return;
/*     */       } 
/*     */       ((ItemOption)this.is.getOptions().get(this.index)).setParam(param);
/*     */       GirlkunDB.executeUpdate("GIRLKUN", "update item_shop_option set param = ? where item_shop_id = ? and option_id = ?", new Object[] { Integer.valueOf(param), Integer.valueOf(this.is.getId()), Integer.valueOf(((ItemOption)this.is.getOptions().get(this.index)).getItemOptionTemplate().getId()) });
/*     */       loadData();
/*     */       NotifyUtil.showMessageDialog(this, "Sửa thành công");
/*     */     } catch (Exception e) {
/*     */       NotifyUtil.showMessageDialog(this, "Vui lòng nhập đúng chỉ số");
/*     */       this.txtParam.requestFocus();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void button12ActionPerformed(ActionEvent evt) {
/*     */     if (this.index == -1) {
/*     */       NotifyUtil.showMessageDialog(null, "Vui lòng chọn option cần xóa");
/*     */       return;
/*     */     } 
/*     */     try {
/*     */       if (NotifyUtil.showConfirmDialog(null, "Bạn có chắc chắn muốn xóa option này?\nTất cả dữ liệu của option này sẽ mất hết không thể khôi phục!") == 0) {
/*     */         ItemOption io = this.is.getOptions().remove(this.index);
/*     */         GirlkunDB.executeUpdate("GIRLKUN", "delete from item_shop_option where item_shop_id = ? and option_id = ? and param = ?", new Object[] { Integer.valueOf(this.is.getId()), Integer.valueOf(io.getItemOptionTemplate().getId()), Integer.valueOf(io.getParam()) });
/*     */         loadData();
/*     */         NotifyUtil.showMessageDialog(null, "Xóa thành công!");
/*     */       } 
/*     */     } catch (Exception exception) {}
/*     */   }
/*     */   
/*     */   private void txtParamKeyPressed(KeyEvent evt) {}
/*     */   
/*     */   private void txtParamKeyReleased(KeyEvent evt) {}
/*     */   
/*     */   private void tblListOptionMouseClicked(MouseEvent evt) {
/*     */     this.index = this.tblListOption.getSelectedRow();
/*     */     if (this.index != -1) {
/*     */       ItemOption is = this.is.getOptions().get(this.index);
/*     */       this.cboItemOptionTemplate.setSelectedIndex(is.getItemOptionTemplate().getId());
/*     */       this.txtParam.setText("" + is.getParam());
/*     */     } 
/*     */   }
/*     */   
/*     */   private void tblListOptionKeyPressed(KeyEvent evt) {
/*     */     this.index = this.tblListOption.getSelectedRow();
/*     */     if (this.index != -1) {
/*     */       ItemOption is = this.is.getOptions().get(this.index);
/*     */       this.cboItemOptionTemplate.setSelectedIndex(is.getItemOptionTemplate().getId());
/*     */       this.txtParam.setText("" + is.getParam());
/*     */     } 
/*     */   }
/*     */   
/*     */   private void tblListOptionKeyReleased(KeyEvent evt) {
/*     */     this.index = this.tblListOption.getSelectedRow();
/*     */     if (this.index != -1) {
/*     */       ItemOption is = this.is.getOptions().get(this.index);
/*     */       this.cboItemOptionTemplate.setSelectedIndex(is.getItemOptionTemplate().getId());
/*     */       this.txtParam.setText("" + is.getParam());
/*     */     } 
/*     */   }
/*     */   
/*     */   private void button13ActionPerformed(ActionEvent evt) {
/*     */     this.cboItemOptionTemplate.setSelectedIndex(77);
/*     */   }
/*     */   
/*     */   private void button14ActionPerformed(ActionEvent evt) {
/*     */     this.cboItemOptionTemplate.setSelectedIndex(103);
/*     */   }
/*     */   
/*     */   private void button15ActionPerformed(ActionEvent evt) {
/*     */     this.cboItemOptionTemplate.setSelectedIndex(50);
/*     */   }
/*     */   
/*     */   private void button16ActionPerformed(ActionEvent evt) {
/*     */     this.cboItemOptionTemplate.setSelectedIndex(6);
/*     */   }
/*     */   
/*     */   private void button17ActionPerformed(ActionEvent evt) {
/*     */     this.cboItemOptionTemplate.setSelectedIndex(7);
/*     */   }
/*     */   
/*     */   private void button18ActionPerformed(ActionEvent evt) {
/*     */     this.cboItemOptionTemplate.setSelectedIndex(0);
/*     */   }
/*     */   
/*     */   private void button19ActionPerformed(ActionEvent evt) {
/*     */     this.cboItemOptionTemplate.setSelectedIndex(27);
/*     */   }
/*     */   
/*     */   private void button20ActionPerformed(ActionEvent evt) {
/*     */     this.cboItemOptionTemplate.setSelectedIndex(28);
/*     */   }
/*     */   
/*     */   private void button21ActionPerformed(ActionEvent evt) {
/*     */     this.cboItemOptionTemplate.setSelectedIndex(93);
/*     */   }
/*     */   
/*     */   private void button22ActionPerformed(ActionEvent evt) {
/*     */     this.cboItemOptionTemplate.setSelectedIndex(14);
/*     */   }
/*     */   
/*     */   private void button23ActionPerformed(ActionEvent evt) {
/*     */     this.cboItemOptionTemplate.setSelectedIndex(22);
/*     */   }
/*     */   
/*     */   private void button24ActionPerformed(ActionEvent evt) {
/*     */     this.cboItemOptionTemplate.setSelectedIndex(23);
/*     */   }
/*     */   
/*     */   private void findItemOption() {
/*     */     String text = this.txtFindItemOptionTemplate.getText();
/*     */     try {
/*     */       int id = Integer.parseInt(text);
/*     */       for (int i = 0; i < Manager.gI().getItemOptionTemplates().size(); i++) {
/*     */         if (((ItemOptionTemplate)Manager.gI().getItemOptionTemplates().get(i)).getId() == id) {
/*     */           this.cboItemOptionTemplate.setSelectedIndex(i);
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } catch (Exception e) {
/*     */       for (int i = 0; i < Manager.gI().getItemOptionTemplates().size(); i++) {
/*     */         try {
/*     */           String name = ((ItemOptionTemplate)Manager.gI().getItemOptionTemplates().get(i)).getName();
/*     */           if (StringUtil.removeAccent(name).toLowerCase().contains(StringUtil.removeAccent(text).toLowerCase())) {
/*     */             this.cboItemOptionTemplate.setSelectedIndex(i);
/*     */             break;
/*     */           } 
/*     */         } catch (Exception exception) {}
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void loadData() {
/*     */     this.index = -1;
/*     */     this.model.setRowCount(0);
/*     */     if (this.is != null)
/*     */       for (ItemOption is : this.is.getOptions()) {
/*     */         this.model.addRow(new Object[] { is.getItemOptionTemplate().getId() + " - " + is.getItemOptionTemplate().getName().replaceAll("#", String.valueOf(is.getParam())) });
/*     */       }  
/*     */   }
/*     */   
/*     */   private void setup() {
/*     */     setResizable(false);
/*     */     setLocationRelativeTo((Component)null);
/*     */     for (ItemOptionTemplate io : Manager.gI().getItemOptionTemplates())
/*     */       this.cboItemOptionTemplate.addItem(io.getId() + " - " + io.getName()); 
/*     */     this.model = new DefaultTableModel((Object[])new String[] { "Option" }, 0) {
/*     */         public boolean isCellEditable(int row, int column) {
/*     */           return false;
/*     */         }
/*     */       };
/*     */     this.tblListOption.setModel(this.model);
/*     */   }
/*     */   
/*     */   public void show(ItemShop is) {
/*     */     this.is = is;
/*     */     this.lblNameItem.setText(is.getId() + " - " + is.getItemTemplate().getName());
/*     */     try {
/*     */       this.lblItem.setIcon(new ImageIcon(Util.getImageById(is.getItemTemplate().getIconId(), 4).getScaledInstance(this.lblItem.getWidth(), this.lblItem.getHeight(), 4)));
/*     */     } catch (Exception exception) {}
/*     */     loadData();
/*     */     if (isVisible())
/*     */       return; 
/*     */     setVisible(true);
/*     */   }
/*     */ }


/* Location:              D:\nro\server_luxu_nrp\vemap\GirlkunToolCBRO.jar!\com\girlkun\tool\screens\shop_scr\ItemShopOption.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */