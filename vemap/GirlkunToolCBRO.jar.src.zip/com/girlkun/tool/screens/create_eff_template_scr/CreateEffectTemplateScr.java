/*     */ package com.girlkun.tool.screens.create_eff_template_scr;
/*     */ import com.girlkun.button.Button;
/*     */ import com.girlkun.tool.utils.Util;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Font;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.KeyEventDispatcher;
/*     */ import java.awt.KeyboardFocusManager;
/*     */ import java.awt.dnd.DropTarget;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.ComponentAdapter;
/*     */ import java.awt.event.ComponentEvent;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.ImageObserver;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Random;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.GroupLayout;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JInternalFrame;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.event.InternalFrameAdapter;
/*     */ import javax.swing.event.InternalFrameEvent;
/*     */ 
/*     */ public class CreateEffectTemplateScr extends JInternalFrame {
/*     */   private KeyEventDispatcher ked;
/*     */   private int scrW;
/*     */   private int scrH;
/*     */   private Thread tDrawPreview;
/*     */   private Thread tDraw;
/*     */   private long lastTimeMove;
/*     */   private RectanglePacker<EffImage> packer;
/*     */   private EffImage effImageChose;
/*     */   private BufferedImage imgTamDemPreview;
/*     */   private BufferedImage imgTamDem;
/*  43 */   private Camera camera = new Camera();
/*     */   
/*     */   private int maxY;
/*     */   public int cEffX;
/*     */   public int cEffY;
/*  48 */   public List<EffImage> effImages = new ArrayList<>();
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean drawBorder;
/*     */ 
/*     */ 
/*     */   
/*     */   private Button button1;
/*     */ 
/*     */   
/*     */   private JCheckBox chkDrawBorder;
/*     */ 
/*     */   
/*     */   private JPanel jPanel1;
/*     */ 
/*     */   
/*     */   private JPanel jPanel2;
/*     */ 
/*     */   
/*     */   private JScrollPane jScrollPane1;
/*     */ 
/*     */   
/*     */   private JPanel panelPreview;
/*     */ 
/*     */   
/*     */   private JPanel panelScreen;
/*     */ 
/*     */   
/*     */   private Random rd;
/*     */ 
/*     */   
/*     */   private long lastTimeNextF;
/*     */ 
/*     */   
/*     */   private int timeNextF;
/*     */ 
/*     */   
/*     */   private int f;
/*     */ 
/*     */ 
/*     */   
/*     */   private void keyPress(KeyEvent e) {
/*  91 */     e.getKeyCode();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void keyRelease(KeyEvent e) {
/*  97 */     e.getKeyCode();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void initThreadDraw() {
/* 103 */     this.tDraw = new Thread(() -> {
/*     */           while (!this.isClosed) {
/*     */             try {
/*     */               if (this.isSelected && Util.canDoLastTime(this.lastTimeMove, 500)) {
/*     */                 draw();
/*     */               }
/*     */               Thread.sleep(1L);
/* 110 */             } catch (Exception e) {
/*     */               e.printStackTrace();
/*     */             } 
/*     */           } 
/*     */         });
/* 115 */     this.tDrawPreview = new Thread(() -> {
/*     */           while (!this.isClosed) {
/*     */             try {
/*     */               if (this.isSelected && Util.canDoLastTime(this.lastTimeMove, 500)) {
/*     */                 drawPreview();
/*     */               }
/*     */               Thread.sleep(1L);
/* 122 */             } catch (Exception e) {
/*     */               e.printStackTrace();
/*     */             } 
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   public void setVisible(boolean aFlag) {
/* 131 */     super.setVisible(aFlag);
/* 132 */     if (this.panelScreen != null) {
/* 133 */       this.scrW = this.panelScreen.getWidth();
/* 134 */       this.scrH = this.panelScreen.getHeight();
/* 135 */       this.camera.w = this.scrW;
/* 136 */       this.camera.h = this.scrH;
/* 137 */       this.imgTamDem = new BufferedImage(this.scrW, this.scrH, 2);
/*     */ 
/*     */       
/* 140 */       this.packer = new RectanglePacker<>(this.scrW, this.scrH, 0);
/*     */       
/* 142 */       this
/* 143 */         .imgTamDemPreview = new BufferedImage(this.panelPreview.getWidth(), this.panelPreview.getHeight(), 2);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void dropImage(BufferedImage image) {
/* 149 */     EffImage effImage = new EffImage(image, 1);
/* 150 */     RectanglePacker.Rectangle r = this.packer.insert(effImage.w, effImage.h, effImage);
/* 151 */     effImage.x = r.x;
/* 152 */     effImage.y = r.y;
/* 153 */     System.out.println(r);
/* 154 */     this.effImages.add(effImage);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initComponents() {
/* 161 */     this.panelScreen = new JPanel();
/* 162 */     this.jPanel2 = new JPanel();
/* 163 */     this.jScrollPane1 = new JScrollPane();
/* 164 */     this.jPanel1 = new JPanel();
/* 165 */     this.chkDrawBorder = new JCheckBox();
/* 166 */     this.button1 = new Button();
/* 167 */     this.panelPreview = new JPanel();
/*     */     
/* 169 */     setClosable(true);
/* 170 */     setIconifiable(true);
/* 171 */     setResizable(true);
/*     */     
/* 173 */     this.panelScreen.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/* 174 */     this.panelScreen.addMouseListener(new MouseAdapter() {
/*     */           public void mouseClicked(MouseEvent evt) {
/* 176 */             CreateEffectTemplateScr.this.panelScreenMouseClicked(evt);
/*     */           }
/*     */           public void mouseReleased(MouseEvent evt) {
/* 179 */             CreateEffectTemplateScr.this.panelScreenMouseReleased(evt);
/*     */           }
/*     */         });
/*     */     
/* 183 */     GroupLayout panelScreenLayout = new GroupLayout(this.panelScreen);
/* 184 */     this.panelScreen.setLayout(panelScreenLayout);
/* 185 */     panelScreenLayout.setHorizontalGroup(panelScreenLayout
/* 186 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 187 */         .addGap(0, 1270, 32767));
/*     */     
/* 189 */     panelScreenLayout.setVerticalGroup(panelScreenLayout
/* 190 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 191 */         .addGap(0, 824, 32767));
/*     */ 
/*     */     
/* 194 */     this.jPanel2.setBorder(BorderFactory.createLineBorder(new Color(0, 0, 0)));
/*     */     
/* 196 */     this.chkDrawBorder.setFont(new Font("SansSerif", 1, 12));
/* 197 */     this.chkDrawBorder.setText("Draw border");
/* 198 */     this.chkDrawBorder.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/* 200 */             CreateEffectTemplateScr.this.chkDrawBorderActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     
/* 204 */     this.button1.setBackground(new Color(255, 0, 0));
/* 205 */     this.button1.setForeground(new Color(255, 255, 255));
/* 206 */     this.button1.setText("Clear");
/* 207 */     this.button1.setFont(new Font("SansSerif", 1, 14));
/* 208 */     this.button1.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/* 210 */             CreateEffectTemplateScr.this.button1ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     
/* 214 */     GroupLayout jPanel1Layout = new GroupLayout(this.jPanel1);
/* 215 */     this.jPanel1.setLayout(jPanel1Layout);
/* 216 */     jPanel1Layout.setHorizontalGroup(jPanel1Layout
/* 217 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 218 */         .addGroup(jPanel1Layout.createSequentialGroup()
/* 219 */           .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false)
/* 220 */             .addComponent((Component)this.button1, -1, -1, 32767)
/* 221 */             .addComponent(this.chkDrawBorder, -1, -1, 32767))
/* 222 */           .addGap(0, 286, 32767)));
/*     */     
/* 224 */     jPanel1Layout.setVerticalGroup(jPanel1Layout
/* 225 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 226 */         .addGroup(jPanel1Layout.createSequentialGroup()
/* 227 */           .addComponent(this.chkDrawBorder)
/* 228 */           .addGap(18, 18, 18)
/* 229 */           .addComponent((Component)this.button1, -2, 41, -2)
/* 230 */           .addGap(0, 569, 32767)));
/*     */ 
/*     */     
/* 233 */     this.jScrollPane1.setViewportView(this.jPanel1);
/*     */     
/* 235 */     GroupLayout panelPreviewLayout = new GroupLayout(this.panelPreview);
/* 236 */     this.panelPreview.setLayout(panelPreviewLayout);
/* 237 */     panelPreviewLayout.setHorizontalGroup(panelPreviewLayout
/* 238 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 239 */         .addGap(0, 0, 32767));
/*     */     
/* 241 */     panelPreviewLayout.setVerticalGroup(panelPreviewLayout
/* 242 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 243 */         .addGap(0, 0, 32767));
/*     */ 
/*     */     
/* 246 */     GroupLayout jPanel2Layout = new GroupLayout(this.jPanel2);
/* 247 */     this.jPanel2.setLayout(jPanel2Layout);
/* 248 */     jPanel2Layout.setHorizontalGroup(jPanel2Layout
/* 249 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 250 */         .addComponent(this.jScrollPane1)
/* 251 */         .addComponent(this.panelPreview, -1, -1, 32767));
/*     */     
/* 253 */     jPanel2Layout.setVerticalGroup(jPanel2Layout
/* 254 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 255 */         .addGroup(GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
/* 256 */           .addComponent(this.panelPreview, -1, -1, 32767)
/* 257 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 258 */           .addComponent(this.jScrollPane1, -2, 396, -2)));
/*     */ 
/*     */     
/* 261 */     GroupLayout layout = new GroupLayout(getContentPane());
/* 262 */     getContentPane().setLayout(layout);
/* 263 */     layout.setHorizontalGroup(layout
/* 264 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 265 */         .addGroup(layout.createSequentialGroup()
/* 266 */           .addComponent(this.panelScreen, -2, -1, -2)
/* 267 */           .addGap(0, 0, 0)
/* 268 */           .addComponent(this.jPanel2, -1, -1, 32767)));
/*     */     
/* 270 */     layout.setVerticalGroup(layout
/* 271 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 272 */         .addComponent(this.panelScreen, -1, -1, 32767)
/* 273 */         .addComponent(this.jPanel2, -1, -1, 32767));
/*     */ 
/*     */     
/* 276 */     pack();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void chkDrawBorderActionPerformed(ActionEvent evt) {
/* 282 */     this.drawBorder = this.chkDrawBorder.isSelected();
/*     */   }
/*     */   
/*     */   private void panelScreenMouseClicked(MouseEvent evt) {
/* 286 */     choseEffImage(evt);
/*     */   }
/*     */   
/*     */   private void choseEffImage(MouseEvent evt) {
/* 290 */     this.effImageChose = null;
/* 291 */     int x = evt.getX();
/* 292 */     int y = evt.getY();
/* 293 */     for (EffImage ei : this.effImages) {
/* 294 */       if (x >= ei.x && x <= ei.x + ei.w && y >= ei.y && y <= ei.y + ei.h) {
/* 295 */         this.effImageChose = ei;
/*     */         break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void panelScreenMouseReleased(MouseEvent evt) {
/* 302 */     choseEffImage(evt);
/*     */   }
/*     */   
/*     */   private void button1ActionPerformed(ActionEvent evt) {
/* 306 */     if (NotifyUtil.showConfirmDialog((JFrame)Main.I, "Bạn có chắc chắn muốn xóa hết tất cả?") == 0) {
/* 307 */       for (EffImage ei : this.effImages) {
/* 308 */         this.packer.remove(ei);
/*     */       }
/* 310 */       this.effImages.clear();
/* 311 */       this.effImageChose = null;
/*     */     } 
/*     */   }
/*     */   private void setup() {
/* 315 */     setResizable(false);
/* 316 */     this.panelScreen.setDropTarget(new DropTarget(this.panelScreen, new DropListener(this)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CreateEffectTemplateScr() {
/* 329 */     this.rd = new Random();
/*     */ 
/*     */     
/* 332 */     this.timeNextF = 50; initComponents(); setup(); initThreadDraw(); this.tDraw.start(); this.tDrawPreview.start(); addComponentListener(new ComponentAdapter() { public void componentMoved(ComponentEvent e) { CreateEffectTemplateScr.this.lastTimeMove = System.currentTimeMillis(); } }
/*     */       ); addInternalFrameListener(new InternalFrameAdapter() { public void internalFrameClosing(InternalFrameEvent e) { KeyboardFocusManager.getCurrentKeyboardFocusManager().removeKeyEventDispatcher(CreateEffectTemplateScr.this.ked); } }
/*     */       ); KeyboardFocusManager.getCurrentKeyboardFocusManager().addKeyEventDispatcher(this.ked = new KeyEventDispatcher() { public boolean dispatchKeyEvent(KeyEvent ke) { if (CreateEffectTemplateScr.this.isSelected)
/*     */               switch (ke.getID()) { case 401: CreateEffectTemplateScr.this.keyPress(ke); break;case 402: CreateEffectTemplateScr.this.keyRelease(ke); break; }   return false; } });
/* 336 */   } private void drawPreview() { if (this.imgTamDemPreview == null || this.effImages.isEmpty()) {
/*     */       return;
/*     */     }
/* 339 */     Graphics2D gTamDem = this.imgTamDemPreview.createGraphics();
/* 340 */     gTamDem.setColor(Color.gray);
/* 341 */     gTamDem.fillRect(0, 0, this.imgTamDemPreview.getWidth(), this.imgTamDemPreview.getHeight());
/* 342 */     if (Util.canDoLastTime(this.lastTimeNextF, this.timeNextF)) {
/* 343 */       this.f++;
/* 344 */       this.lastTimeNextF = System.currentTimeMillis();
/*     */     } 
/* 346 */     if (this.f >= this.effImages.size()) {
/* 347 */       this.f = 0;
/*     */     }
/* 349 */     int x = this.imgTamDemPreview.getWidth() / 2;
/* 350 */     int y = this.imgTamDemPreview.getHeight();
/* 351 */     EffImage ei = this.effImages.get(this.f);
/* 352 */     gTamDem.drawImage(ei.image, x - ei.w / 2, y - ei.h, (ImageObserver)null);
/* 353 */     gTamDem.dispose();
/*     */     
/*     */     try {
/* 356 */       Graphics2D grphScreen = (Graphics2D)this.panelPreview.getGraphics();
/* 357 */       grphScreen.drawImage(this.imgTamDemPreview, 0, 0, (ImageObserver)null);
/* 358 */       grphScreen.dispose();
/* 359 */     } catch (Exception exception) {} }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void draw() {
/* 365 */     if (this.imgTamDem == null) {
/*     */       return;
/*     */     }
/* 368 */     clearTamDem();
/* 369 */     drawToTamDem();
/* 370 */     drawToScreen();
/*     */   }
/*     */   
/*     */   private void clearTamDem() {
/* 374 */     Graphics2D gTamDem = this.imgTamDem.createGraphics();
/* 375 */     gTamDem.setColor(Color.gray);
/* 376 */     gTamDem.fillRect(0, 0, this.scrW, this.scrH);
/* 377 */     gTamDem.setColor(new Color(255, 255, 255, 0));
/* 378 */     gTamDem.fillRect(0, 0, this.scrW, this.scrH);
/*     */   }
/*     */   
/*     */   private void drawToTamDem() {
/* 382 */     Graphics2D gTamDem = this.imgTamDem.createGraphics();
/*     */     try {
/* 384 */       for (EffImage ei : this.effImages) {
/* 385 */         ei.draw(gTamDem, this.drawBorder);
/*     */       }
/* 387 */       if (this.effImageChose != null) {
/* 388 */         gTamDem.setColor(Color.red);
/* 389 */         gTamDem.drawRect(this.effImageChose.x, this.effImageChose.y, this.effImageChose.w, this.effImageChose.h);
/*     */       } 
/* 391 */     } catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */   
/*     */   private void drawToScreen() {
/*     */     try {
/* 397 */       Graphics2D grphScreen = (Graphics2D)this.panelScreen.getGraphics();
/* 398 */       grphScreen.drawImage(this.imgTamDem, 0, 0, (ImageObserver)null);
/* 399 */       grphScreen.dispose();
/* 400 */     } catch (Exception exception) {}
/*     */   }
/*     */ }


/* Location:              D:\nro\server_luxu_nrp\vemap\GirlkunToolCBRO.jar!\com\girlkun\tool\screens\create_eff_template_scr\CreateEffectTemplateScr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */