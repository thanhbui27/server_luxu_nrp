package com.girlkun.tool.screens.create_eff_template_scr;

public class Camera {
  public int x;
  
  public int y;
  
  public int w;
  
  public int h;
}


/* Location:              D:\nro\server_luxu_nrp\vemap\GirlkunToolCBRO.jar!\com\girlkun\tool\screens\create_eff_template_scr\Camera.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */