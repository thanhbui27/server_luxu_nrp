/*    */ package com.girlkun.tool.screens.create_eff_template_scr;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import java.awt.Graphics2D;
/*    */ import java.awt.image.BufferedImage;
/*    */ import java.awt.image.ImageObserver;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EffImage
/*    */ {
/*    */   public int x;
/*    */   public int y;
/*    */   public int w;
/*    */   public int h;
/*    */   public BufferedImage image;
/*    */   public int zoomSize;
/*    */   
/*    */   public EffImage(BufferedImage image, int zoomSize) {
/* 22 */     this.image = image;
/* 23 */     this.zoomSize = zoomSize;
/* 24 */     this.w = image.getWidth() * this.zoomSize;
/* 25 */     this.h = image.getHeight() * this.zoomSize;
/*    */   }
/*    */   
/*    */   public void draw(Graphics2D g, boolean drawBorder) {
/* 29 */     g.drawImage(this.image, this.x, this.y, (ImageObserver)null);
/* 30 */     if (drawBorder) {
/* 31 */       g.setColor(Color.white);
/* 32 */       g.drawRect(this.x, this.y, this.w, this.h);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\nro\server_luxu_nrp\vemap\GirlkunToolCBRO.jar!\com\girlkun\tool\screens\create_eff_template_scr\EffImage.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */