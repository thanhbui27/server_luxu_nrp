/*    */ package com.girlkun.tool.screens.create_eff_template_scr;
/*    */ 
/*    */ import java.awt.datatransfer.DataFlavor;
/*    */ import java.awt.datatransfer.Transferable;
/*    */ import java.awt.dnd.DropTargetDragEvent;
/*    */ import java.awt.dnd.DropTargetDropEvent;
/*    */ import java.awt.dnd.DropTargetEvent;
/*    */ import java.awt.dnd.DropTargetListener;
/*    */ import java.io.File;
/*    */ import java.util.List;
/*    */ import javax.imageio.ImageIO;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DropListener
/*    */   implements DropTargetListener
/*    */ {
/*    */   private CreateEffectTemplateScr cets;
/*    */   
/*    */   public DropListener(CreateEffectTemplateScr cets) {
/* 24 */     this.cets = cets;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void dragEnter(DropTargetDragEvent dtde) {}
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void dragOver(DropTargetDragEvent dtde) {}
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void dropActionChanged(DropTargetDragEvent dtde) {}
/*    */ 
/*    */ 
/*    */   
/*    */   public void dragExit(DropTargetEvent dte) {}
/*    */ 
/*    */ 
/*    */   
/*    */   public void drop(DropTargetDropEvent ev) {
/* 49 */     ev.acceptDrop(1);
/* 50 */     Transferable t = ev.getTransferable();
/* 51 */     DataFlavor[] df = t.getTransferDataFlavors();
/* 52 */     for (DataFlavor f : df) {
/*    */       try {
/* 54 */         if (f.isFlavorJavaFileListType()) {
/* 55 */           List<File> files = (List<File>)t.getTransferData(f);
/*    */           
/* 57 */           for (File file : files) {
/* 58 */             String nameFile = file.getName();
/* 59 */             if (nameFile.contains(".png") || nameFile.contains(".jpg")) {
/* 60 */               this.cets.dropImage(ImageIO.read(file));
/*    */             }
/*    */           } 
/*    */         } 
/* 64 */       } catch (Exception exception) {}
/*    */     } 
/*    */   }
/*    */ }


/* Location:              D:\nro\server_luxu_nrp\vemap\GirlkunToolCBRO.jar!\com\girlkun\tool\screens\create_eff_template_scr\DropListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */