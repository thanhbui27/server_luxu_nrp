/*     */ package com.girlkun.tool.screens.create_eff_template_scr;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JOptionPane;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class RectanglePacker<P>
/*     */ {
/*     */   private Node root;
/*     */   
/*     */   private enum Fit
/*     */   {
/*  56 */     FAIL,
/*     */ 
/*     */ 
/*     */     
/*  60 */     PERFECT,
/*     */ 
/*     */ 
/*     */     
/*  64 */     FIT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  72 */   private int border = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RectanglePacker(int width, int height, int border) {
/*  82 */     this.root = new Node(new Rectangle(0, 0, width, height));
/*  83 */     this.border = border;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void inspectRectangles(List<Rectangle> rectangles) {
/*  93 */     this.root.getRectangles(rectangles);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Rectangle findRectangle(P item) {
/* 104 */     return this.root.findRectange(item);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clear() {
/* 111 */     this.root = new Node(this.root.rect);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Rectangle insert(int width, int height, P o) {
/* 123 */     Node n = this.root.insert(width + 2 * this.border, height + 2 * this.border, o);
/*     */     
/* 125 */     if (n != null) {
/*     */       
/* 127 */       Rectangle r = new Rectangle(n.rect.x + this.border, n.rect.y + this.border, n.rect.width - 2 * this.border, n.rect.height - 2 * this.border);
/* 128 */       return r;
/*     */     } 
/* 130 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean remove(P o) {
/* 143 */     return this.root.remove(o);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getWidth() {
/* 152 */     return this.root.rect.width;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getHeight() {
/* 161 */     return this.root.rect.height;
/*     */   }
/*     */ 
/*     */   
/*     */   private class Node
/*     */   {
/*     */     private RectanglePacker.Rectangle rect;
/* 168 */     private P occupier = null;
/*     */     
/* 170 */     private Node left = null;
/*     */     
/* 172 */     private Node right = null;
/*     */     
/*     */     private Node(RectanglePacker.Rectangle r) {
/* 175 */       this.rect = r;
/*     */     }
/*     */     
/*     */     private RectanglePacker.Rectangle findRectange(P item) {
/* 179 */       if (isLeaf()) {
/* 180 */         if (item == this.occupier) {
/* 181 */           return this.rect;
/*     */         }
/* 183 */         return null;
/*     */       } 
/*     */       
/* 186 */       RectanglePacker.Rectangle l = this.left.findRectange(item);
/*     */       
/* 188 */       if (l != null) {
/* 189 */         return l;
/*     */       }
/* 191 */       return this.right.findRectange(item);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     private Node insert(int width, int height, P o) {
/* 197 */       if (!isLeaf()) {
/* 198 */         Node r = this.left.insert(width, height, o);
/*     */         
/* 200 */         if (r == null) {
/* 201 */           r = this.right.insert(width, height, o);
/*     */         }
/*     */         
/* 204 */         return r;
/*     */       } 
/* 206 */       if (this.occupier != null) {
/* 207 */         return null;
/*     */       }
/*     */       
/* 210 */       RectanglePacker.Fit fit = fits(width, height);
/*     */       
/* 212 */       switch (fit) {
/*     */         case FAIL:
/* 214 */           return null;
/*     */         case PERFECT:
/* 216 */           this.occupier = o;
/* 217 */           return this;
/*     */         case FIT:
/* 219 */           split(width, height);
/*     */           break;
/*     */       } 
/*     */       
/* 223 */       return this.left.insert(width, height, o);
/*     */     }
/*     */ 
/*     */     
/*     */     private boolean isLeaf() {
/* 228 */       return (this.left == null);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean isOccupied() {
/* 238 */       return (this.occupier != null || !isLeaf());
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean remove(P o) {
/* 249 */       if (isLeaf()) {
/* 250 */         if (this.occupier == o) {
/* 251 */           this.occupier = null;
/*     */           
/* 253 */           return true;
/*     */         } 
/* 255 */         return false;
/*     */       } 
/* 257 */       boolean found = this.left.remove(o);
/* 258 */       if (!found) {
/* 259 */         found = this.right.remove(o);
/*     */       }
/*     */       
/* 262 */       if (found && 
/* 263 */         !this.left.isOccupied() && !this.right.isOccupied()) {
/* 264 */         this.left = null;
/* 265 */         this.right = null;
/*     */       } 
/*     */ 
/*     */       
/* 269 */       return found;
/*     */     }
/*     */     
/*     */     private void split(int width, int height) {
/*     */       RectanglePacker.Rectangle r, l;
/* 274 */       int dw = this.rect.width - width;
/* 275 */       int dh = this.rect.height - height;
/*     */       
/* 277 */       assert dw >= 0;
/* 278 */       assert dh >= 0;
/*     */ 
/*     */       
/* 281 */       if (dw > dh) {
/* 282 */         l = new RectanglePacker.Rectangle(this.rect.x, this.rect.y, width, this.rect.height);
/*     */         
/* 284 */         r = new RectanglePacker.Rectangle(l.x + width, this.rect.y, this.rect.width - width, this.rect.height);
/*     */       } else {
/*     */         
/* 287 */         l = new RectanglePacker.Rectangle(this.rect.x, this.rect.y, this.rect.width, height);
/*     */         
/* 289 */         r = new RectanglePacker.Rectangle(this.rect.x, l.y + height, this.rect.width, this.rect.height - height);
/*     */       } 
/*     */ 
/*     */       
/* 293 */       this.left = new Node(l);
/* 294 */       this.right = new Node(r);
/*     */     }
/*     */     
/*     */     private RectanglePacker.Fit fits(int width, int height) {
/* 298 */       if (width <= this.rect.width && height <= this.rect.height) {
/* 299 */         if (width == this.rect.width && height == this.rect.height) {
/* 300 */           return RectanglePacker.Fit.PERFECT;
/*     */         }
/* 302 */         return RectanglePacker.Fit.FIT;
/*     */       } 
/*     */ 
/*     */       
/* 306 */       return RectanglePacker.Fit.FAIL;
/*     */     }
/*     */     
/*     */     private void getRectangles(List<RectanglePacker.Rectangle> rectangles) {
/* 310 */       rectangles.add(this.rect);
/*     */       
/* 312 */       if (!isLeaf()) {
/* 313 */         this.left.getRectangles(rectangles);
/* 314 */         this.right.getRectangles(rectangles);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Rectangle
/*     */   {
/*     */     public final int x;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final int y;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final int width;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public final int height;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Rectangle(int x, int y, int width, int height) {
/* 348 */       this.x = x;
/* 349 */       this.y = y;
/* 350 */       this.width = width;
/* 351 */       this.height = height;
/*     */     }
/*     */     
/*     */     private Rectangle(Rectangle r) {
/* 355 */       this.x = r.x;
/* 356 */       this.y = r.y;
/* 357 */       this.width = r.width;
/* 358 */       this.height = r.height;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 363 */       return "[ " + this.x + ", " + this.y + ", " + this.width + ", " + this.height + " ]";
/*     */     }
/*     */   }
/*     */   
/*     */   public static void main(String[] args) {
/* 368 */     int w = 1000;
/* 369 */     int h = 1000;
/* 370 */     int b = 0;
/* 371 */     BufferedImage image = new BufferedImage(w, h, 2);
/* 372 */     Graphics2D g = image.createGraphics();
/* 373 */     RectanglePacker<Integer> packer = new RectanglePacker(w, h, b);
/* 374 */     g.setColor(Color.red);
/* 375 */     g.drawRect(0, 0, w - 1, h - 1);
/* 376 */     Random rd = new Random(); int i;
/* 377 */     for (i = 0; i < 50; i++) {
/* 378 */       Rectangle r = packer.insert(100 + rd.nextInt(100), 100 + rd.nextInt(100), Integer.valueOf(1));
/* 379 */       if (r == null) {
/* 380 */         System.out.println("con 1");
/*     */       } else {
/*     */         
/* 383 */         System.out.println(r);
/* 384 */         g.drawRect(r.x, r.y, r.width, r.height);
/* 385 */         g.drawString(i + "", r.x + r.width / 2, r.y + r.height / 2);
/*     */       } 
/* 387 */     }  for (i = 0; i < 50; i++) {
/* 388 */       Rectangle r = packer.insert(20 + rd.nextInt(50), 20 + rd.nextInt(50), Integer.valueOf(1));
/* 389 */       if (r == null) {
/* 390 */         System.out.println("con 2");
/*     */       } else {
/*     */         
/* 393 */         System.out.println(r);
/* 394 */         g.drawRect(r.x, r.y, r.width, r.height);
/* 395 */         g.drawString((i + 50) + "", r.x + r.width / 2, r.y + r.height / 2);
/*     */       } 
/*     */     } 
/* 398 */     JOptionPane.showMessageDialog(null, null, null, 1, new ImageIcon(image));
/*     */   }
/*     */ }


/* Location:              D:\nro\server_luxu_nrp\vemap\GirlkunToolCBRO.jar!\com\girlkun\tool\screens\create_eff_template_scr\RectanglePacker.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */