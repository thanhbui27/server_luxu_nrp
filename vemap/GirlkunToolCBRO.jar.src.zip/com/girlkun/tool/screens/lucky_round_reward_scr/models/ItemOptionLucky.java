/*    */ package com.girlkun.tool.screens.lucky_round_reward_scr.models;
/*    */ 
/*    */ import com.girlkun.tool.entities.item.ItemOptionTemplate;
/*    */ import com.girlkun.tool.main.Manager;
/*    */ import java.util.Arrays;
/*    */ 
/*    */ public class ItemOptionLucky {
/*    */   private ItemOptionTemplate temp;
/*    */   private int[] param;
/*    */   private int[] ratio;
/*    */   
/* 12 */   public void setTemp(ItemOptionTemplate temp) { this.temp = temp; } public void setParam(int[] param) { this.param = param; } public void setRatio(int[] ratio) { this.ratio = ratio; } public boolean equals(Object o) { if (o == this) return true;  if (!(o instanceof ItemOptionLucky)) return false;  ItemOptionLucky other = (ItemOptionLucky)o; if (!other.canEqual(this)) return false;  Object this$temp = getTemp(), other$temp = other.getTemp(); return ((this$temp == null) ? (other$temp != null) : !this$temp.equals(other$temp)) ? false : (!Arrays.equals(getParam(), other.getParam()) ? false : (!!Arrays.equals(getRatio(), other.getRatio()))); } protected boolean canEqual(Object other) { return other instanceof ItemOptionLucky; } public int hashCode() { int PRIME = 59; result = 1; Object $temp = getTemp(); result = result * 59 + (($temp == null) ? 43 : $temp.hashCode()); result = result * 59 + Arrays.hashCode(getParam()); return result * 59 + Arrays.hashCode(getRatio()); } public String toString() { return "ItemOptionLucky(temp=" + getTemp() + ", param=" + Arrays.toString(getParam()) + ", ratio=" + Arrays.toString(getRatio()) + ")"; }
/*    */   
/*    */   public ItemOptionTemplate getTemp() {
/* 15 */     return this.temp;
/*    */   } public int[] getParam() {
/* 17 */     return this.param;
/*    */   } public int[] getRatio() {
/* 19 */     return this.ratio;
/*    */   }
/*    */   public ItemOptionLucky(int tempId, int[] param, int[] ratio) {
/* 22 */     this.temp = Manager.gI().getItemOptionTemplates().get(tempId);
/* 23 */     this.param = param;
/* 24 */     this.ratio = ratio;
/*    */   }
/*    */ }


/* Location:              D:\nro\server_luxu_nrp\vemap\GirlkunToolCBRO.jar!\com\girlkun\tool\screens\lucky_round_reward_scr\models\ItemOptionLucky.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */