/*    */ package com.girlkun.tool.screens.lucky_round_reward_scr.models;
/*    */ 
/*    */ import com.girlkun.tool.entities.item.ItemTemplate;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ 
/*    */ public class ItemLucky {
/*    */   private ItemTemplate temp;
/*    */   private int[] quantity;
/*    */   private int[] ratio;
/*    */   private int gender;
/*    */   
/* 13 */   public void setTemp(ItemTemplate temp) { this.temp = temp; } public void setQuantity(int[] quantity) { this.quantity = quantity; } public void setRatio(int[] ratio) { this.ratio = ratio; } public void setGender(int gender) { this.gender = gender; } public void setOptions(List<ItemOptionLucky> options) { this.options = options; } public boolean equals(Object o) { if (o == this) return true;  if (!(o instanceof ItemLucky)) return false;  ItemLucky other = (ItemLucky)o; if (!other.canEqual(this)) return false;  if (getGender() != other.getGender()) return false;  Object this$temp = getTemp(), other$temp = other.getTemp(); if ((this$temp == null) ? (other$temp != null) : !this$temp.equals(other$temp)) return false;  if (!Arrays.equals(getQuantity(), other.getQuantity())) return false;  if (!Arrays.equals(getRatio(), other.getRatio())) return false;  Object<ItemOptionLucky> this$options = (Object<ItemOptionLucky>)getOptions(), other$options = (Object<ItemOptionLucky>)other.getOptions(); return !((this$options == null) ? (other$options != null) : !this$options.equals(other$options)); } protected boolean canEqual(Object other) { return other instanceof ItemLucky; } public int hashCode() { int PRIME = 59; result = 1; result = result * 59 + getGender(); Object $temp = getTemp(); result = result * 59 + (($temp == null) ? 43 : $temp.hashCode()); result = result * 59 + Arrays.hashCode(getQuantity()); result = result * 59 + Arrays.hashCode(getRatio()); Object<ItemOptionLucky> $options = (Object<ItemOptionLucky>)getOptions(); return result * 59 + (($options == null) ? 43 : $options.hashCode()); } public String toString() { return "ItemLucky(temp=" + getTemp() + ", quantity=" + Arrays.toString(getQuantity()) + ", ratio=" + Arrays.toString(getRatio()) + ", gender=" + getGender() + ", options=" + getOptions() + ")"; }
/*    */   
/*    */   public ItemTemplate getTemp() {
/* 16 */     return this.temp;
/*    */   } public int[] getQuantity() {
/* 18 */     return this.quantity;
/*    */   } public int[] getRatio() {
/* 20 */     return this.ratio;
/*    */   } public int getGender() {
/* 22 */     return this.gender;
/*    */   }
/* 24 */   private List<ItemOptionLucky> options = new ArrayList<>(); public List<ItemOptionLucky> getOptions() { return this.options; }
/*    */ 
/*    */ }


/* Location:              D:\nro\server_luxu_nrp\vemap\GirlkunToolCBRO.jar!\com\girlkun\tool\screens\lucky_round_reward_scr\models\ItemLucky.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */