/*     */ package com.girlkun.tool.screens.lucky_round_reward_scr;
/*     */ 
/*     */ import com.girlkun.button.Button;
/*     */ import com.girlkun.tool.entities.item.ItemOptionTemplate;
/*     */ import com.girlkun.tool.entities.item.ItemTemplate;
/*     */ import com.girlkun.tool.main.Main;
/*     */ import com.girlkun.tool.main.Manager;
/*     */ import com.girlkun.tool.screens.lucky_round_reward_scr.models.ItemLucky;
/*     */ import com.girlkun.tool.screens.lucky_round_reward_scr.models.ItemOptionLucky;
/*     */ import com.girlkun.tool.utils.NotifyUtil;
/*     */ import com.girlkun.tool.utils.StringUtil;
/*     */ import com.girlkun.tool.utils.Util;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.KeyAdapter;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.swing.DefaultComboBoxModel;
/*     */ import javax.swing.GroupLayout;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JFileChooser;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JInternalFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.JTextArea;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.LayoutStyle;
/*     */ import javax.swing.table.DefaultTableModel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LuckyRoundRewardScr
/*     */   extends JInternalFrame
/*     */ {
/*     */   private ItemLucky itemLuckChose;
/*     */   private DefaultTableModel modelOption;
/*     */   private int indexOption;
/*     */   private DefaultTableModel model;
/*     */   private List<ItemLucky> list;
/*     */   private int index;
/*     */   private Button button1;
/*     */   private Button button2;
/*     */   private Button button5;
/*     */   private Button button6;
/*     */   private Button button7;
/*     */   private Button button8;
/*     */   private Button button9;
/*     */   private JComboBox<String> cboGender;
/*     */   private JComboBox<String> cboItemTemplate;
/*     */   private JComboBox<String> cboOption;
/*     */   private JLabel jLabel10;
/*     */   private JLabel jLabel11;
/*     */   private JLabel jLabel13;
/*     */   private JLabel jLabel14;
/*     */   private JLabel jLabel15;
/*     */   private JLabel jLabel16;
/*     */   private JLabel jLabel5;
/*     */   private JLabel jLabel6;
/*     */   private JLabel jLabel7;
/*     */   private JLabel jLabel8;
/*     */   private JLabel jLabel9;
/*     */   private JPanel jPanel1;
/*     */   private JScrollPane jScrollPane1;
/*     */   private JScrollPane jScrollPane2;
/*     */   private JScrollPane jScrollPane3;
/*     */   private JLabel lblImageItem;
/*     */   private JTable tblList;
/*     */   private JTable tblOption;
/*     */   private JTextField txtFindItemTemplate;
/*     */   private JTextField txtFindOption;
/*     */   private JTextArea txtInfoItem;
/*     */   private JTextField txtParam;
/*     */   private JTextField txtQuanF;
/*     */   private JTextField txtQuanT;
/*     */   private JTextField txtR1;
/*     */   private JTextField txtR2;
/*     */   private JTextField txtRatio1;
/*     */   private JTextField txtRatio2;
/*     */   
/*     */   public LuckyRoundRewardScr() {
/* 900 */     this.indexOption = -1;
/*     */     
/* 902 */     this.list = new ArrayList<>();
/* 903 */     this.index = -1;
/*     */     initComponents();
/*     */     setup();
/*     */   }
/*     */   
/*     */   private void initComponents() {
/*     */     this.cboItemTemplate = new JComboBox<>();
/*     */     this.jLabel5 = new JLabel();
/*     */     this.jLabel6 = new JLabel();
/*     */     this.txtFindItemTemplate = new JTextField();
/*     */     this.lblImageItem = new JLabel();
/*     */     this.jLabel7 = new JLabel();
/*     */     this.txtQuanF = new JTextField();
/*     */     this.jLabel8 = new JLabel();
/*     */     this.txtQuanT = new JTextField();
/*     */     this.jLabel9 = new JLabel();
/*     */     this.txtRatio1 = new JTextField();
/*     */     this.jLabel10 = new JLabel();
/*     */     this.txtRatio2 = new JTextField();
/*     */     this.button1 = new Button();
/*     */     this.jLabel11 = new JLabel();
/*     */     this.cboGender = new JComboBox<>();
/*     */     this.jScrollPane1 = new JScrollPane();
/*     */     this.txtInfoItem = new JTextArea();
/*     */     this.jScrollPane3 = new JScrollPane();
/*     */     this.tblList = new JTable();
/*     */     this.button5 = new Button();
/*     */     this.button7 = new Button();
/*     */     this.button8 = new Button();
/*     */     this.jPanel1 = new JPanel();
/*     */     this.button6 = new Button();
/*     */     this.jScrollPane2 = new JScrollPane();
/*     */     this.tblOption = new JTable();
/*     */     this.button2 = new Button();
/*     */     this.txtParam = new JTextField();
/*     */     this.cboOption = new JComboBox<>();
/*     */     this.txtFindOption = new JTextField();
/*     */     this.jLabel13 = new JLabel();
/*     */     this.jLabel14 = new JLabel();
/*     */     this.jLabel15 = new JLabel();
/*     */     this.txtR1 = new JTextField();
/*     */     this.jLabel16 = new JLabel();
/*     */     this.txtR2 = new JTextField();
/*     */     this.button9 = new Button();
/*     */     setClosable(true);
/*     */     setIconifiable(true);
/*     */     setResizable(true);
/*     */     this.cboItemTemplate.setBackground(new Color(255, 204, 255));
/*     */     this.cboItemTemplate.setFont(new Font("SansSerif", 1, 12));
/*     */     this.cboItemTemplate.setForeground(new Color(51, 0, 51));
/*     */     this.cboItemTemplate.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/*     */             LuckyRoundRewardScr.this.cboItemTemplateActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     this.cboItemTemplate.addKeyListener(new KeyAdapter() {
/*     */           public void keyReleased(KeyEvent evt) {
/*     */             LuckyRoundRewardScr.this.cboItemTemplateKeyReleased(evt);
/*     */           }
/*     */         });
/*     */     this.jLabel5.setFont(new Font("SansSerif", 1, 12));
/*     */     this.jLabel5.setText("Item template");
/*     */     this.jLabel6.setFont(new Font("SansSerif", 1, 12));
/*     */     this.jLabel6.setText("Search item");
/*     */     this.txtFindItemTemplate.setBackground(new Color(255, 204, 255));
/*     */     this.txtFindItemTemplate.setFont(new Font("SansSerif", 1, 12));
/*     */     this.txtFindItemTemplate.setForeground(new Color(51, 0, 51));
/*     */     this.txtFindItemTemplate.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/*     */             LuckyRoundRewardScr.this.txtFindItemTemplateKeyPressed(evt);
/*     */           }
/*     */           
/*     */           public void keyReleased(KeyEvent evt) {
/*     */             LuckyRoundRewardScr.this.txtFindItemTemplateKeyReleased(evt);
/*     */           }
/*     */         });
/*     */     this.lblImageItem.setHorizontalAlignment(0);
/*     */     this.jLabel7.setFont(new Font("SansSerif", 1, 12));
/*     */     this.jLabel7.setText("Quantity from");
/*     */     this.txtQuanF.setFont(new Font("SansSerif", 1, 12));
/*     */     this.txtQuanF.setText("1");
/*     */     this.txtQuanF.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/*     */             LuckyRoundRewardScr.this.txtQuanFKeyPressed(evt);
/*     */           }
/*     */           
/*     */           public void keyReleased(KeyEvent evt) {
/*     */             LuckyRoundRewardScr.this.txtQuanFKeyReleased(evt);
/*     */           }
/*     */         });
/*     */     this.jLabel8.setFont(new Font("SansSerif", 1, 12));
/*     */     this.jLabel8.setText("Quantity to");
/*     */     this.txtQuanT.setFont(new Font("SansSerif", 1, 12));
/*     */     this.txtQuanT.setText("1");
/*     */     this.txtQuanT.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/*     */             LuckyRoundRewardScr.this.txtQuanTKeyPressed(evt);
/*     */           }
/*     */           
/*     */           public void keyReleased(KeyEvent evt) {
/*     */             LuckyRoundRewardScr.this.txtQuanTKeyReleased(evt);
/*     */           }
/*     */         });
/*     */     this.jLabel9.setFont(new Font("SansSerif", 1, 12));
/*     */     this.jLabel9.setText("Ratio");
/*     */     this.txtRatio1.setFont(new Font("SansSerif", 1, 12));
/*     */     this.txtRatio1.setText("100");
/*     */     this.txtRatio1.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/*     */             LuckyRoundRewardScr.this.txtRatio1KeyPressed(evt);
/*     */           }
/*     */           
/*     */           public void keyReleased(KeyEvent evt) {
/*     */             LuckyRoundRewardScr.this.txtRatio1KeyReleased(evt);
/*     */           }
/*     */         });
/*     */     this.jLabel10.setText("/");
/*     */     this.txtRatio2.setFont(new Font("SansSerif", 1, 12));
/*     */     this.txtRatio2.setText("100");
/*     */     this.txtRatio2.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/*     */             LuckyRoundRewardScr.this.txtRatio2KeyPressed(evt);
/*     */           }
/*     */           
/*     */           public void keyReleased(KeyEvent evt) {
/*     */             LuckyRoundRewardScr.this.txtRatio2KeyReleased(evt);
/*     */           }
/*     */         });
/*     */     this.button1.setBackground(new Color(153, 0, 153));
/*     */     this.button1.setForeground(new Color(255, 255, 255));
/*     */     this.button1.setText("Add item");
/*     */     this.button1.setFont(new Font("SansSerif", 1, 12));
/*     */     this.button1.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/*     */             LuckyRoundRewardScr.this.button1ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     this.jLabel11.setFont(new Font("SansSerif", 1, 12));
/*     */     this.jLabel11.setText("For gender");
/*     */     this.cboGender.setFont(new Font("SansSerif", 1, 12));
/*     */     this.cboGender.setModel(new DefaultComboBoxModel<>(new String[] { "All", "Trái đất", "Namếc", "Xayda" }));
/*     */     this.cboGender.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/*     */             LuckyRoundRewardScr.this.cboGenderActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     this.cboGender.addKeyListener(new KeyAdapter() {
/*     */           public void keyReleased(KeyEvent evt) {
/*     */             LuckyRoundRewardScr.this.cboGenderKeyReleased(evt);
/*     */           }
/*     */         });
/*     */     this.txtInfoItem.setEditable(false);
/*     */     this.txtInfoItem.setColumns(20);
/*     */     this.txtInfoItem.setFont(new Font("SansSerif", 1, 12));
/*     */     this.txtInfoItem.setLineWrap(true);
/*     */     this.txtInfoItem.setRows(5);
/*     */     this.txtInfoItem.setWrapStyleWord(true);
/*     */     this.jScrollPane1.setViewportView(this.txtInfoItem);
/*     */     this.tblList.setModel(new DefaultTableModel(new Object[0][], (Object[])new String[0]));
/*     */     this.tblList.setSelectionMode(0);
/*     */     this.tblList.addMouseListener(new MouseAdapter() {
/*     */           public void mouseClicked(MouseEvent evt) {
/*     */             LuckyRoundRewardScr.this.tblListMouseClicked(evt);
/*     */           }
/*     */         });
/*     */     this.jScrollPane3.setViewportView(this.tblList);
/*     */     this.button5.setBackground(new Color(204, 0, 0));
/*     */     this.button5.setForeground(new Color(255, 255, 255));
/*     */     this.button5.setText("Remove item");
/*     */     this.button5.setFont(new Font("SansSerif", 1, 12));
/*     */     this.button5.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/*     */             LuckyRoundRewardScr.this.button5ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     this.button7.setBackground(new Color(153, 0, 153));
/*     */     this.button7.setForeground(new Color(255, 255, 255));
/*     */     this.button7.setText("Export");
/*     */     this.button7.setFont(new Font("SansSerif", 1, 12));
/*     */     this.button7.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/*     */             LuckyRoundRewardScr.this.button7ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     this.button8.setBackground(new Color(153, 0, 153));
/*     */     this.button8.setForeground(new Color(255, 255, 255));
/*     */     this.button8.setText("Import");
/*     */     this.button8.setFont(new Font("SansSerif", 1, 12));
/*     */     this.button8.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/*     */             LuckyRoundRewardScr.this.button8ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     this.button6.setBackground(new Color(204, 0, 0));
/*     */     this.button6.setForeground(new Color(255, 255, 255));
/*     */     this.button6.setText("Remove option");
/*     */     this.button6.setFont(new Font("SansSerif", 1, 12));
/*     */     this.button6.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/*     */             LuckyRoundRewardScr.this.button6ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     this.tblOption.setModel(new DefaultTableModel(new Object[0][], (Object[])new String[0]));
/*     */     this.tblOption.addMouseListener(new MouseAdapter() {
/*     */           public void mouseClicked(MouseEvent evt) {
/*     */             LuckyRoundRewardScr.this.tblOptionMouseClicked(evt);
/*     */           }
/*     */           
/*     */           public void mousePressed(MouseEvent evt) {
/*     */             LuckyRoundRewardScr.this.tblOptionMousePressed(evt);
/*     */           }
/*     */           
/*     */           public void mouseReleased(MouseEvent evt) {
/*     */             LuckyRoundRewardScr.this.tblOptionMouseReleased(evt);
/*     */           }
/*     */         });
/*     */     this.jScrollPane2.setViewportView(this.tblOption);
/*     */     this.button2.setBackground(new Color(153, 0, 153));
/*     */     this.button2.setForeground(new Color(255, 255, 255));
/*     */     this.button2.setText("Add option");
/*     */     this.button2.setFont(new Font("SansSerif", 1, 12));
/*     */     this.button2.setMaximumSize(new Dimension(152, 39));
/*     */     this.button2.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/*     */             LuckyRoundRewardScr.this.button2ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     this.txtParam.setFont(new Font("SansSerif", 1, 12));
/*     */     this.txtParam.setText("Eg: 752002 or 75-2002");
/*     */     this.txtParam.setMaximumSize(new Dimension(152, 39));
/*     */     this.txtParam.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/*     */             LuckyRoundRewardScr.this.txtParamKeyPressed(evt);
/*     */           }
/*     */           
/*     */           public void keyReleased(KeyEvent evt) {
/*     */             LuckyRoundRewardScr.this.txtParamKeyReleased(evt);
/*     */           }
/*     */         });
/*     */     this.cboOption.setBackground(new Color(255, 204, 255));
/*     */     this.cboOption.setFont(new Font("SansSerif", 1, 12));
/*     */     this.cboOption.setForeground(new Color(51, 0, 51));
/*     */     this.cboOption.setMaximumSize(new Dimension(152, 39));
/*     */     this.txtFindOption.setBackground(new Color(255, 204, 255));
/*     */     this.txtFindOption.setFont(new Font("SansSerif", 1, 12));
/*     */     this.txtFindOption.setForeground(new Color(51, 0, 51));
/*     */     this.txtFindOption.setMaximumSize(new Dimension(152, 39));
/*     */     this.txtFindOption.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/*     */             LuckyRoundRewardScr.this.txtFindOptionKeyPressed(evt);
/*     */           }
/*     */           
/*     */           public void keyReleased(KeyEvent evt) {
/*     */             LuckyRoundRewardScr.this.txtFindOptionKeyReleased(evt);
/*     */           }
/*     */         });
/*     */     this.jLabel13.setFont(new Font("SansSerif", 1, 12));
/*     */     this.jLabel13.setText("Search option");
/*     */     this.jLabel14.setFont(new Font("SansSerif", 1, 12));
/*     */     this.jLabel14.setText("Option template");
/*     */     this.jLabel15.setFont(new Font("SansSerif", 1, 12));
/*     */     this.jLabel15.setText("Param");
/*     */     this.txtR1.setFont(new Font("SansSerif", 1, 12));
/*     */     this.txtR1.setText("100");
/*     */     this.txtR1.setMaximumSize(new Dimension(152, 39));
/*     */     this.txtR1.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/*     */             LuckyRoundRewardScr.this.txtR1KeyPressed(evt);
/*     */           }
/*     */           
/*     */           public void keyReleased(KeyEvent evt) {
/*     */             LuckyRoundRewardScr.this.txtR1KeyReleased(evt);
/*     */           }
/*     */         });
/*     */     this.jLabel16.setFont(new Font("SansSerif", 1, 12));
/*     */     this.jLabel16.setText("Ratio");
/*     */     this.txtR2.setFont(new Font("SansSerif", 1, 12));
/*     */     this.txtR2.setText("100");
/*     */     this.txtR2.setMaximumSize(new Dimension(152, 39));
/*     */     this.txtR2.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/*     */             LuckyRoundRewardScr.this.txtR2KeyPressed(evt);
/*     */           }
/*     */           
/*     */           public void keyReleased(KeyEvent evt) {
/*     */             LuckyRoundRewardScr.this.txtR2KeyReleased(evt);
/*     */           }
/*     */         });
/*     */     GroupLayout jPanel1Layout = new GroupLayout(this.jPanel1);
/*     */     this.jPanel1.setLayout(jPanel1Layout);
/*     */     jPanel1Layout.setHorizontalGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jLabel13, -2, 100, -2).addComponent(this.jLabel14).addComponent(this.jLabel15, -2, 90, -2).addComponent(this.jLabel16, -2, 90, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent((Component)this.button2, -2, 228, -2).addGroup(jPanel1Layout.createSequentialGroup().addComponent(this.txtR1, -2, 82, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtR2, -2, 82, -2)).addComponent(this.cboOption, -2, 228, -2).addComponent(this.txtParam, -2, 228, -2).addComponent(this.txtFindOption, -2, 228, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jScrollPane2, -2, 0, 32767).addGroup(jPanel1Layout.createSequentialGroup().addComponent((Component)this.button6, -2, 166, -2).addGap(0, 142, 32767)))));
/*     */     jPanel1Layout.linkSize(0, new Component[] { this.jLabel13, this.jLabel14, this.jLabel15, this.jLabel16 });
/*     */     jPanel1Layout.setVerticalGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addComponent(this.jLabel13, -2, 39, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jLabel14, -2, 39, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jLabel15, -2, 39, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jLabel16, -2, 39, -2)).addGroup(jPanel1Layout.createSequentialGroup().addComponent(this.txtFindOption, -2, 39, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.cboOption, -2, 39, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtParam, -2, 39, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.txtR1, -2, 39, -2).addComponent(this.txtR2, -2, 39, -2))).addComponent(this.jScrollPane2, GroupLayout.Alignment.TRAILING, -2, 174, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent((Component)this.button2, -2, 39, -2).addComponent((Component)this.button6, -2, 39, -2)).addContainerGap(-1, 32767)));
/*     */     this.button9.setBackground(new Color(204, 0, 0));
/*     */     this.button9.setForeground(new Color(255, 255, 255));
/*     */     this.button9.setText("Clear all item");
/*     */     this.button9.setFont(new Font("SansSerif", 1, 12));
/*     */     this.button9.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/*     */             LuckyRoundRewardScr.this.button9ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     GroupLayout layout = new GroupLayout(getContentPane());
/*     */     getContentPane().setLayout(layout);
/*     */     layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(GroupLayout.Alignment.TRAILING, layout.createSequentialGroup().addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jLabel11, -2, 102, -2).addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent((Component)this.button7, -1, -1, 32767).addComponent((Component)this.button8, -2, 87, -2))).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING).addComponent((Component)this.button1, GroupLayout.Alignment.LEADING, -1, -1, 32767).addComponent(this.cboGender, 0, -1, 32767)).addGap(86, 86, 86)).addGroup(layout.createSequentialGroup().addComponent(this.jScrollPane1, -2, -1, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, -1, 32767)))).addGroup(layout.createSequentialGroup().addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addGroup(layout.createSequentialGroup().addComponent(this.jLabel9, -2, 102, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtRatio1, -2, 74, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jLabel10).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtRatio2)).addGroup(layout.createSequentialGroup().addComponent(this.jLabel8, -2, 102, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtQuanT)).addGroup(layout.createSequentialGroup().addComponent(this.jLabel7, -2, 102, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtQuanF)).addGroup(GroupLayout.Alignment.TRAILING, layout.createSequentialGroup().addComponent(this.jLabel6, -2, 102, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtFindItemTemplate)).addGroup(layout.createSequentialGroup().addComponent(this.jLabel5, -2, 102, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.cboItemTemplate, -2, 161, -2))).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.lblImageItem, -2, 83, -2).addGap(0, 0, 32767))).addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addComponent(this.jScrollPane3).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent((Component)this.button5, -1, -1, 32767).addComponent((Component)this.button9, -1, -1, 32767)).addGap(5, 5, 5)).addComponent(this.jPanel1, -2, -1, -2))));
/*     */     layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false).addGroup(layout.createSequentialGroup().addComponent(this.jPanel1, -2, -1, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jScrollPane3, -2, 0, 32767).addGroup(layout.createSequentialGroup().addGap(0, 0, 32767).addComponent((Component)this.button9, -2, 39, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button5, -2, 39, -2)))).addGroup(layout.createSequentialGroup().addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(this.jLabel6, -1, -1, 32767).addComponent(this.txtFindItemTemplate, -2, 39, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false).addComponent(this.cboItemTemplate).addComponent(this.jLabel5, -2, 39, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(this.jLabel7, -1, -1, 32767).addComponent(this.txtQuanF, -2, 39, -2))).addComponent(this.lblImageItem, -2, 84, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(this.jLabel8, -1, -1, 32767).addComponent(this.txtQuanT, -2, 39, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(this.jLabel9, -1, -1, 32767).addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.txtRatio1, -2, 39, -2).addComponent(this.jLabel10, -1, -1, 32767).addComponent(this.txtRatio2, -2, 39, -2))).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel11, -2, 39, -2).addComponent(this.cboGender, -2, -1, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING).addGroup(layout.createSequentialGroup().addComponent((Component)this.button1, -2, -1, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jScrollPane1, -2, 251, -2)).addGroup(layout.createSequentialGroup().addComponent((Component)this.button8, -2, 39, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button7, -2, 39, -2))))).addGap(5, 5, 5)));
/*     */     layout.linkSize(1, new Component[] { this.jLabel10, this.txtRatio1 });
/*     */     layout.linkSize(1, new Component[] { (Component)this.button1, this.txtRatio2 });
/*     */     layout.linkSize(1, new Component[] { this.cboGender, this.jLabel11 });
/*     */     pack();
/*     */   }
/*     */   
/*     */   private void findItemOption() {
/*     */     String text = this.txtFindOption.getText();
/*     */     try {
/*     */       int id = Integer.parseInt(text);
/*     */       for (int i = 0; i < Manager.gI().getItemOptionTemplates().size(); i++) {
/*     */         if (((ItemOptionTemplate)Manager.gI().getItemOptionTemplates().get(i)).getId() == id) {
/*     */           this.cboOption.setSelectedIndex(i);
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } catch (Exception e) {
/*     */       for (int i = 0; i < Manager.gI().getItemOptionTemplates().size(); i++) {
/*     */         try {
/*     */           String name = ((ItemOptionTemplate)Manager.gI().getItemOptionTemplates().get(i)).getName();
/*     */           if (StringUtil.removeAccent(name).toLowerCase().contains(StringUtil.removeAccent(text).toLowerCase())) {
/*     */             this.cboOption.setSelectedIndex(i);
/*     */             break;
/*     */           } 
/*     */         } catch (Exception exception) {}
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void findItemTemplate() {
/*     */     String text = this.txtFindItemTemplate.getText();
/*     */     try {
/*     */       int id = Integer.parseInt(text);
/*     */       for (int i = 0; i < Manager.gI().getItemTemplates().size(); i++) {
/*     */         if (((ItemTemplate)Manager.gI().getItemTemplates().get(i)).getId() == id) {
/*     */           this.cboItemTemplate.setSelectedIndex(i);
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } catch (Exception e) {
/*     */       for (int i = 0; i < Manager.gI().getItemTemplates().size(); i++) {
/*     */         try {
/*     */           String name = ((ItemTemplate)Manager.gI().getItemTemplates().get(i)).getName();
/*     */           if (StringUtil.removeAccent(name).toLowerCase().contains(StringUtil.removeAccent(text).toLowerCase())) {
/*     */             this.cboItemTemplate.setSelectedIndex(i);
/*     */             break;
/*     */           } 
/*     */         } catch (Exception exception) {}
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void cboItemTemplateActionPerformed(ActionEvent evt) {
/*     */     try {
/*     */       BufferedImage image = Util.getImageById(((ItemTemplate)Manager.gI().getItemTemplates().get(this.cboItemTemplate.getSelectedIndex())).getIconId(), 2);
/*     */       this.lblImageItem.setIcon(new ImageIcon(image));
/*     */     } catch (Exception ex) {
/*     */       Logger.getLogger(LuckyRoundRewardScr.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void cboItemTemplateKeyReleased(KeyEvent evt) {}
/*     */   
/*     */   private void txtFindItemTemplateKeyPressed(KeyEvent evt) {
/*     */     findItemTemplate();
/*     */   }
/*     */   
/*     */   private void txtFindItemTemplateKeyReleased(KeyEvent evt) {
/*     */     findItemTemplate();
/*     */   }
/*     */   
/*     */   private void txtQuanFKeyPressed(KeyEvent evt) {}
/*     */   
/*     */   private void txtQuanFKeyReleased(KeyEvent evt) {}
/*     */   
/*     */   private void txtQuanTKeyPressed(KeyEvent evt) {}
/*     */   
/*     */   private void txtQuanTKeyReleased(KeyEvent evt) {}
/*     */   
/*     */   private void txtRatio1KeyPressed(KeyEvent evt) {}
/*     */   
/*     */   private void txtRatio1KeyReleased(KeyEvent evt) {}
/*     */   
/*     */   private void txtRatio2KeyPressed(KeyEvent evt) {}
/*     */   
/*     */   private void txtRatio2KeyReleased(KeyEvent evt) {}
/*     */   
/*     */   private void cboGenderActionPerformed(ActionEvent evt) {}
/*     */   
/*     */   private void cboGenderKeyReleased(KeyEvent evt) {}
/*     */   
/*     */   private void button1ActionPerformed(ActionEvent evt) {
/*     */     try {
/*     */       int qF = Integer.parseInt(this.txtQuanF.getText());
/*     */       int qT = Integer.parseInt(this.txtQuanT.getText());
/*     */       if (qF < 1 || qT < qF) {
/*     */         NotifyUtil.showMessageDialog((JFrame)Main.I, "Vui lòng nhập đúng số lượng!");
/*     */         return;
/*     */       } 
/*     */       ItemLucky item = new ItemLucky();
/*     */       item.setGender(this.cboGender.getSelectedIndex() - 1);
/*     */       item.setTemp(Manager.gI().getItemTemplates().get(this.cboItemTemplate.getSelectedIndex()));
/*     */       item.setQuantity(new int[] { Integer.parseInt(this.txtQuanF.getText()), Integer.parseInt(this.txtQuanT.getText()) });
/*     */       item.setRatio(new int[] { Integer.parseInt(this.txtRatio1.getText()), Integer.parseInt(this.txtRatio2.getText()) });
/*     */       this.list.add(item);
/*     */       fillToTable();
/*     */     } catch (Exception e) {
/*     */       NotifyUtil.showMessageDialog((JFrame)Main.I, "Vui lòng nhập đúng giá trị!");
/*     */     } 
/*     */   }
/*     */   
/*     */   private void txtFindOptionKeyPressed(KeyEvent evt) {
/*     */     findItemOption();
/*     */   }
/*     */   
/*     */   private void txtFindOptionKeyReleased(KeyEvent evt) {
/*     */     findItemOption();
/*     */   }
/*     */   
/*     */   private void button2ActionPerformed(ActionEvent evt) {
/*     */     if (this.itemLuckChose != null)
/*     */       try {
/*     */         String textParam = this.txtParam.getText();
/*     */         String[] arrParam = textParam.split("-");
/*     */         int[] param = new int[2];
/*     */         if (arrParam.length == 2) {
/*     */           param[0] = Integer.parseInt(arrParam[0]);
/*     */           param[1] = Integer.parseInt(arrParam[1]);
/*     */         } else {
/*     */           param[0] = Integer.parseInt(arrParam[0]);
/*     */           param[1] = Integer.parseInt(arrParam[0]);
/*     */         } 
/*     */         int[] ratio = { Integer.parseInt(this.txtR1.getText()), Integer.parseInt(this.txtR2.getText()) };
/*     */         this.itemLuckChose.getOptions().add(new ItemOptionLucky(((ItemOptionTemplate)Manager.gI().getItemOptionTemplates().get(this.cboOption.getSelectedIndex())).getId(), param, ratio));
/*     */         showInfoItem();
/*     */       } catch (Exception e) {
/*     */         NotifyUtil.showMessageDialog((JFrame)Main.I, "Vui lòng nhập thông tin hợp lệ!");
/*     */       }  
/*     */   }
/*     */   
/*     */   private void txtParamKeyPressed(KeyEvent evt) {}
/*     */   
/*     */   private void txtParamKeyReleased(KeyEvent evt) {}
/*     */   
/*     */   private void tblListMouseClicked(MouseEvent evt) {
/*     */     this.index = this.tblList.getSelectedRow();
/*     */     if (this.index != -1)
/*     */       this.itemLuckChose = this.list.get(this.index); 
/*     */     showInfoItem();
/*     */   }
/*     */   
/*     */   private void showInfoItem() {
/*     */     this.modelOption.setRowCount(0);
/*     */     if (this.itemLuckChose != null) {
/*     */       String info = this.itemLuckChose.getTemp().getName() + "\n----Option----\n";
/*     */       for (ItemOptionLucky io : this.itemLuckChose.getOptions()) {
/*     */         info = info + io.getTemp().getName().replaceAll("#", "(" + io.getParam()[0] + " - " + io.getParam()[1] + ")") + " [" + io.getRatio()[0] + "/ " + io.getRatio()[1] + "]\n";
/*     */         this.modelOption.addRow(new Object[] { io.getTemp().getName().replaceAll("#", "(" + io.getParam()[0] + " - " + io.getParam()[1] + ")"), io.getRatio()[0] + "/ " + io.getRatio()[1] });
/*     */       } 
/*     */       this.txtInfoItem.setText(info);
/*     */     } else {
/*     */       this.txtInfoItem.setText("");
/*     */     } 
/*     */   }
/*     */   
/*     */   public void fillToTable() {
/*     */     this.index = -1;
/*     */     this.model.setRowCount(0);
/*     */     for (ItemLucky item : this.list) {
/*     */       this.model.addRow(new Object[] { item.getTemp().getName(), item.getQuantity()[0] + " - " + item.getQuantity()[1], item.getRatio()[0] + "/ " + item.getRatio()[1], (item.getGender() == -1) ? "All" : ((item.getGender() == 0) ? "Trái đất" : ((item.getGender() == 1) ? "Namếc" : "Xayda")) });
/*     */     } 
/*     */   }
/*     */   
/*     */   private void button5ActionPerformed(ActionEvent evt) {
/*     */     if (this.index != -1) {
/*     */       this.list.remove(this.index);
/*     */       fillToTable();
/*     */       this.itemLuckChose = null;
/*     */       showInfoItem();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void button6ActionPerformed(ActionEvent evt) {
/*     */     if (this.itemLuckChose != null && this.indexOption != -1) {
/*     */       this.itemLuckChose.getOptions().remove(this.indexOption);
/*     */       showInfoItem();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void tblOptionMouseClicked(MouseEvent evt) {
/*     */     this.indexOption = this.tblOption.getSelectedRow();
/*     */   }
/*     */   
/*     */   private void tblOptionMousePressed(MouseEvent evt) {
/*     */     this.indexOption = this.tblOption.getSelectedRow();
/*     */   }
/*     */   
/*     */   private void tblOptionMouseReleased(MouseEvent evt) {
/*     */     this.indexOption = this.tblOption.getSelectedRow();
/*     */   }
/*     */   
/*     */   private void button7ActionPerformed(ActionEvent evt) {
/*     */     JFileChooser fileChooser = new JFileChooser();
/*     */     if (fileChooser.showSaveDialog((Component)Main.I) == 0)
/*     */       try {
/*     */         DataOutputStream dos = new DataOutputStream(new FileOutputStream(fileChooser.getSelectedFile()));
/*     */         dos.writeInt(this.list.size());
/*     */         for (ItemLucky item : this.list) {
/*     */           dos.writeInt(item.getTemp().getId());
/*     */           dos.writeUTF(item.getQuantity()[0] + "-" + item.getQuantity()[1]);
/*     */           dos.writeUTF(item.getRatio()[0] + "-" + item.getRatio()[1]);
/*     */           dos.writeInt(item.getGender());
/*     */           dos.writeInt(item.getOptions().size());
/*     */           for (ItemOptionLucky io : item.getOptions()) {
/*     */             dos.writeInt(io.getTemp().getId());
/*     */             dos.writeUTF(io.getParam()[0] + "-" + io.getParam()[1]);
/*     */             dos.writeUTF(io.getRatio()[0] + "-" + io.getRatio()[1]);
/*     */           } 
/*     */         } 
/*     */         dos.flush();
/*     */         dos.close();
/*     */         NotifyUtil.showMessageDialog((JFrame)Main.I, "Save thành công!");
/*     */       } catch (Exception exception) {} 
/*     */   }
/*     */   
/*     */   private void txtR1KeyPressed(KeyEvent evt) {}
/*     */   
/*     */   private void txtR1KeyReleased(KeyEvent evt) {}
/*     */   
/*     */   private void txtR2KeyPressed(KeyEvent evt) {}
/*     */   
/*     */   private void txtR2KeyReleased(KeyEvent evt) {}
/*     */   
/*     */   private void button8ActionPerformed(ActionEvent evt) {
/*     */     JFileChooser fileChooser = new JFileChooser();
/*     */     if (fileChooser.showOpenDialog((Component)Main.I) == 0)
/*     */       try {
/*     */         this.list.clear();
/*     */         DataInputStream dis = new DataInputStream(new FileInputStream(fileChooser.getSelectedFile()));
/*     */         fillToTable();
/*     */       } catch (Exception exception) {} 
/*     */   }
/*     */   
/*     */   private void button9ActionPerformed(ActionEvent evt) {
/*     */     this.list.clear();
/*     */     this.itemLuckChose = null;
/*     */     fillToTable();
/*     */     showInfoItem();
/*     */   }
/*     */   
/*     */   private void setup() {
/*     */     setTitle("Girlkun - Mob reward");
/*     */     setResizable(false);
/*     */     for (ItemTemplate item : Manager.gI().getItemTemplates())
/*     */       this.cboItemTemplate.addItem(item.getId() + " - " + item.getName()); 
/*     */     for (ItemOptionTemplate io : Manager.gI().getItemOptionTemplates())
/*     */       this.cboOption.addItem(io.getId() + " - " + io.getName()); 
/*     */     this.modelOption = new DefaultTableModel((Object[])new String[] { "Option", "Ratio" }, 0) {
/*     */         public boolean isCellEditable(int row, int column) {
/*     */           return false;
/*     */         }
/*     */       };
/*     */     this.tblOption.setModel(this.modelOption);
/*     */     this.model = new DefaultTableModel((Object[])new String[] { "Item", "Quantity", "Ratio", "Gender" }, 0) {
/*     */         public boolean isCellEditable(int row, int column) {
/*     */           return false;
/*     */         }
/*     */       };
/*     */     this.tblList.setModel(this.model);
/*     */   }
/*     */ }


/* Location:              D:\nro\server_luxu_nrp\vemap\GirlkunToolCBRO.jar!\com\girlkun\tool\screens\lucky_round_reward_scr\LuckyRoundRewardScr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */