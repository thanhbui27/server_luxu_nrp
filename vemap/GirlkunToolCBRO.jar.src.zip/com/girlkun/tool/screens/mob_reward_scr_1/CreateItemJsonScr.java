/*     */ package com.girlkun.tool.screens.mob_reward_scr_1;
/*     */ 
/*     */ import com.girlkun.button.Button;
/*     */ import com.girlkun.tool.entities.item.ItemOptionTemplate;
/*     */ import com.girlkun.tool.entities.item.ItemTemplate;
/*     */ import com.girlkun.tool.main.Main;
/*     */ import com.girlkun.tool.main.Manager;
/*     */ import com.girlkun.tool.screens.mob_reward_scr.models.ItemCache;
/*     */ import com.girlkun.tool.screens.mob_reward_scr.models.ItemOptionReward;
/*     */ import com.girlkun.tool.screens.mob_reward_scr.models.ItemReward;
/*     */ import com.girlkun.tool.utils.NotifyUtil;
/*     */ import com.girlkun.tool.utils.StringUtil;
/*     */ import com.girlkun.tool.utils.Util;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.datatransfer.DataFlavor;
/*     */ import java.awt.datatransfer.Transferable;
/*     */ import java.awt.dnd.DropTarget;
/*     */ import java.awt.dnd.DropTargetDragEvent;
/*     */ import java.awt.dnd.DropTargetDropEvent;
/*     */ import java.awt.dnd.DropTargetEvent;
/*     */ import java.awt.dnd.DropTargetListener;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.KeyAdapter;
/*     */ import java.awt.event.KeyEvent;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.swing.GroupLayout;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JInternalFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.JTextArea;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.LayoutStyle;
/*     */ import javax.swing.table.DefaultTableModel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CreateItemJsonScr
/*     */   extends JInternalFrame
/*     */ {
/*     */   private ModifyItemMobReward itemMobReward;
/*     */   private ModifyAll modifyAll;
/*     */   private AddAllOptionScr addAllOptionScr;
/*     */   private int indexItemCache;
/*     */   private DefaultTableModel modelItemCache;
/*     */   private DefaultTableModel modelOption;
/*     */   private int indexOption;
/*     */   private DefaultTableModel model;
/*     */   private List<ItemReward> list;
/*     */   private int index;
/*     */   private List<ItemCache> listItemCache;
/*     */   private Button button1;
/*     */   private Button button10;
/*     */   private Button button11;
/*     */   private Button button13;
/*     */   private Button button14;
/*     */   private Button button2;
/*     */   private Button button4;
/*     */   private Button button5;
/*     */   private Button button6;
/*     */   private Button button9;
/*     */   private JComboBox<String> cboItemTemplate;
/*     */   private JComboBox<String> cboOption;
/*     */   private JLabel jLabel13;
/*     */   private JLabel jLabel14;
/*     */   private JLabel jLabel15;
/*     */   private JLabel jLabel5;
/*     */   private JLabel jLabel6;
/*     */   private JPanel jPanel2;
/*     */   private JScrollPane jScrollPane2;
/*     */   private JScrollPane jScrollPane3;
/*     */   private JScrollPane jScrollPane4;
/*     */   private JScrollPane jScrollPane5;
/*     */   private JLabel lblItemCache;
/*     */   private JTable tblItemCache;
/*     */   private JTable tblList;
/*     */   private JTable tblOption;
/*     */   private JTextField txtFindItemTemplate;
/*     */   private JTextField txtFindOption;
/*     */   private JTextArea txtInfoItem2;
/*     */   private JTextField txtParam;
/*     */   
/*     */   public CreateItemJsonScr() {
/* 909 */     this.indexItemCache = -1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 926 */     this.indexOption = -1;
/*     */     
/* 928 */     this.list = new ArrayList<>();
/* 929 */     this.index = -1;
/* 930 */     this.listItemCache = new ArrayList<>();
/*     */     initComponents();
/*     */     setup();
/*     */     new DropTarget(this, new DropTargetListener() {
/*     */           public void dragEnter(DropTargetDragEvent dtde) {}
/*     */           
/*     */           public void dragOver(DropTargetDragEvent dtde) {}
/*     */           
/*     */           public void dropActionChanged(DropTargetDragEvent dtde) {}
/*     */           
/*     */           public void dragExit(DropTargetEvent dte) {}
/*     */           
/*     */           public void drop(DropTargetDropEvent ev) {
/*     */             ev.acceptDrop(1);
/*     */             Transferable t = ev.getTransferable();
/*     */             DataFlavor[] df = t.getTransferDataFlavors();
/*     */             for (DataFlavor f : df) {
/*     */               try {
/*     */                 if (f.isFlavorJavaFileListType()) {
/*     */                   List<File> files = (List<File>)t.getTransferData(f);
/*     */                   for (File file : files)
/*     */                     CreateItemJsonScr.this.readFileSave(file); 
/*     */                 } 
/*     */               } catch (Exception exception) {}
/*     */             } 
/*     */           }
/*     */         });
/*     */   }
/*     */   
/*     */   private void initComponents() {
/*     */     this.button4 = new Button();
/*     */     this.jScrollPane3 = new JScrollPane();
/*     */     this.tblList = new JTable();
/*     */     this.jScrollPane4 = new JScrollPane();
/*     */     this.txtInfoItem2 = new JTextArea();
/*     */     this.button5 = new Button();
/*     */     this.button9 = new Button();
/*     */     this.jPanel2 = new JPanel();
/*     */     this.jScrollPane5 = new JScrollPane();
/*     */     this.tblItemCache = new JTable();
/*     */     this.button10 = new Button();
/*     */     this.lblItemCache = new JLabel();
/*     */     this.button11 = new Button();
/*     */     this.button1 = new Button();
/*     */     this.cboItemTemplate = new JComboBox<>();
/*     */     this.txtFindItemTemplate = new JTextField();
/*     */     this.jLabel6 = new JLabel();
/*     */     this.jLabel5 = new JLabel();
/*     */     this.button6 = new Button();
/*     */     this.button2 = new Button();
/*     */     this.jScrollPane2 = new JScrollPane();
/*     */     this.tblOption = new JTable();
/*     */     this.jLabel15 = new JLabel();
/*     */     this.txtParam = new JTextField();
/*     */     this.cboOption = new JComboBox<>();
/*     */     this.txtFindOption = new JTextField();
/*     */     this.jLabel13 = new JLabel();
/*     */     this.jLabel14 = new JLabel();
/*     */     this.button13 = new Button();
/*     */     this.button14 = new Button();
/*     */     setClosable(true);
/*     */     setIconifiable(true);
/*     */     setResizable(true);
/*     */     this.button4.setBackground(new Color(153, 0, 153));
/*     */     this.button4.setForeground(new Color(255, 255, 255));
/*     */     this.button4.setText("Add to list");
/*     */     this.button4.setFont(new Font("SansSerif", 1, 12));
/*     */     this.button4.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/*     */             CreateItemJsonScr.this.button4ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     this.tblList.setModel(new DefaultTableModel(new Object[0][], (Object[])new String[0]));
/*     */     this.tblList.addMouseListener(new MouseAdapter() {
/*     */           public void mouseClicked(MouseEvent evt) {
/*     */             CreateItemJsonScr.this.tblListMouseClicked(evt);
/*     */           }
/*     */         });
/*     */     this.tblList.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/*     */             CreateItemJsonScr.this.tblListKeyPressed(evt);
/*     */           }
/*     */           
/*     */           public void keyReleased(KeyEvent evt) {
/*     */             CreateItemJsonScr.this.tblListKeyReleased(evt);
/*     */           }
/*     */         });
/*     */     this.jScrollPane3.setViewportView(this.tblList);
/*     */     this.txtInfoItem2.setEditable(false);
/*     */     this.txtInfoItem2.setColumns(20);
/*     */     this.txtInfoItem2.setFont(new Font("SansSerif", 1, 12));
/*     */     this.txtInfoItem2.setLineWrap(true);
/*     */     this.txtInfoItem2.setRows(5);
/*     */     this.txtInfoItem2.setWrapStyleWord(true);
/*     */     this.jScrollPane4.setViewportView(this.txtInfoItem2);
/*     */     this.button5.setBackground(new Color(204, 0, 0));
/*     */     this.button5.setForeground(new Color(255, 255, 255));
/*     */     this.button5.setText("Remove item");
/*     */     this.button5.setFont(new Font("SansSerif", 1, 12));
/*     */     this.button5.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/*     */             CreateItemJsonScr.this.button5ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     this.button9.setBackground(new Color(204, 0, 0));
/*     */     this.button9.setForeground(new Color(255, 255, 255));
/*     */     this.button9.setText("Clear all item");
/*     */     this.button9.setFont(new Font("SansSerif", 1, 12));
/*     */     this.button9.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/*     */             CreateItemJsonScr.this.button9ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     this.tblItemCache.setModel(new DefaultTableModel(new Object[0][], (Object[])new String[0]));
/*     */     this.tblItemCache.addMouseListener(new MouseAdapter() {
/*     */           public void mouseClicked(MouseEvent evt) {
/*     */             CreateItemJsonScr.this.tblItemCacheMouseClicked(evt);
/*     */           }
/*     */         });
/*     */     this.tblItemCache.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/*     */             CreateItemJsonScr.this.tblItemCacheKeyPressed(evt);
/*     */           }
/*     */           
/*     */           public void keyReleased(KeyEvent evt) {
/*     */             CreateItemJsonScr.this.tblItemCacheKeyReleased(evt);
/*     */           }
/*     */         });
/*     */     this.jScrollPane5.setViewportView(this.tblItemCache);
/*     */     this.button10.setBackground(new Color(204, 0, 0));
/*     */     this.button10.setForeground(new Color(255, 255, 255));
/*     */     this.button10.setText("Remove");
/*     */     this.button10.setFont(new Font("SansSerif", 1, 12));
/*     */     this.button10.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/*     */             CreateItemJsonScr.this.button10ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     this.lblItemCache.setHorizontalAlignment(0);
/*     */     this.button11.setBackground(new Color(204, 0, 0));
/*     */     this.button11.setForeground(new Color(255, 255, 255));
/*     */     this.button11.setText("Clear all");
/*     */     this.button11.setFont(new Font("SansSerif", 1, 12));
/*     */     this.button11.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/*     */             CreateItemJsonScr.this.button11ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     this.button1.setBackground(new Color(153, 0, 153));
/*     */     this.button1.setForeground(new Color(255, 255, 255));
/*     */     this.button1.setText("Add item cache");
/*     */     this.button1.setFont(new Font("SansSerif", 1, 12));
/*     */     this.button1.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/*     */             CreateItemJsonScr.this.button1ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     this.cboItemTemplate.setBackground(new Color(255, 204, 255));
/*     */     this.cboItemTemplate.setFont(new Font("SansSerif", 1, 12));
/*     */     this.cboItemTemplate.setForeground(new Color(51, 0, 51));
/*     */     this.cboItemTemplate.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/*     */             CreateItemJsonScr.this.cboItemTemplateActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     this.cboItemTemplate.addKeyListener(new KeyAdapter() {
/*     */           public void keyReleased(KeyEvent evt) {
/*     */             CreateItemJsonScr.this.cboItemTemplateKeyReleased(evt);
/*     */           }
/*     */         });
/*     */     this.txtFindItemTemplate.setBackground(new Color(255, 204, 255));
/*     */     this.txtFindItemTemplate.setFont(new Font("SansSerif", 1, 12));
/*     */     this.txtFindItemTemplate.setForeground(new Color(51, 0, 51));
/*     */     this.txtFindItemTemplate.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/*     */             CreateItemJsonScr.this.txtFindItemTemplateKeyPressed(evt);
/*     */           }
/*     */           
/*     */           public void keyReleased(KeyEvent evt) {
/*     */             CreateItemJsonScr.this.txtFindItemTemplateKeyReleased(evt);
/*     */           }
/*     */         });
/*     */     this.jLabel6.setFont(new Font("SansSerif", 1, 12));
/*     */     this.jLabel6.setText("Search item");
/*     */     this.jLabel5.setFont(new Font("SansSerif", 1, 12));
/*     */     this.jLabel5.setText("Item template");
/*     */     this.button6.setBackground(new Color(204, 0, 0));
/*     */     this.button6.setForeground(new Color(255, 255, 255));
/*     */     this.button6.setText("Remove option");
/*     */     this.button6.setFont(new Font("SansSerif", 1, 12));
/*     */     this.button6.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/*     */             CreateItemJsonScr.this.button6ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     this.button2.setBackground(new Color(153, 0, 153));
/*     */     this.button2.setForeground(new Color(255, 255, 255));
/*     */     this.button2.setText("Add option");
/*     */     this.button2.setFont(new Font("SansSerif", 1, 12));
/*     */     this.button2.setMaximumSize(new Dimension(152, 39));
/*     */     this.button2.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/*     */             CreateItemJsonScr.this.button2ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     this.tblOption.setModel(new DefaultTableModel(new Object[0][], (Object[])new String[0]));
/*     */     this.tblOption.addMouseListener(new MouseAdapter() {
/*     */           public void mouseClicked(MouseEvent evt) {
/*     */             CreateItemJsonScr.this.tblOptionMouseClicked(evt);
/*     */           }
/*     */           
/*     */           public void mousePressed(MouseEvent evt) {
/*     */             CreateItemJsonScr.this.tblOptionMousePressed(evt);
/*     */           }
/*     */           
/*     */           public void mouseReleased(MouseEvent evt) {
/*     */             CreateItemJsonScr.this.tblOptionMouseReleased(evt);
/*     */           }
/*     */         });
/*     */     this.jScrollPane2.setViewportView(this.tblOption);
/*     */     this.jLabel15.setFont(new Font("SansSerif", 1, 12));
/*     */     this.jLabel15.setText("Param");
/*     */     this.txtParam.setFont(new Font("SansSerif", 1, 12));
/*     */     this.txtParam.setText("Eg: 752002 or 75-2002");
/*     */     this.txtParam.setMaximumSize(new Dimension(152, 39));
/*     */     this.txtParam.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/*     */             CreateItemJsonScr.this.txtParamKeyPressed(evt);
/*     */           }
/*     */           
/*     */           public void keyReleased(KeyEvent evt) {
/*     */             CreateItemJsonScr.this.txtParamKeyReleased(evt);
/*     */           }
/*     */         });
/*     */     this.cboOption.setBackground(new Color(255, 204, 255));
/*     */     this.cboOption.setFont(new Font("SansSerif", 1, 12));
/*     */     this.cboOption.setForeground(new Color(51, 0, 51));
/*     */     this.cboOption.setMaximumSize(new Dimension(152, 39));
/*     */     this.txtFindOption.setBackground(new Color(255, 204, 255));
/*     */     this.txtFindOption.setFont(new Font("SansSerif", 1, 12));
/*     */     this.txtFindOption.setForeground(new Color(51, 0, 51));
/*     */     this.txtFindOption.setMaximumSize(new Dimension(152, 39));
/*     */     this.txtFindOption.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/*     */             CreateItemJsonScr.this.txtFindOptionKeyPressed(evt);
/*     */           }
/*     */           
/*     */           public void keyReleased(KeyEvent evt) {
/*     */             CreateItemJsonScr.this.txtFindOptionKeyReleased(evt);
/*     */           }
/*     */         });
/*     */     this.jLabel13.setFont(new Font("SansSerif", 1, 12));
/*     */     this.jLabel13.setText("Search option");
/*     */     this.jLabel14.setFont(new Font("SansSerif", 1, 12));
/*     */     this.jLabel14.setText("Option template");
/*     */     GroupLayout jPanel2Layout = new GroupLayout(this.jPanel2);
/*     */     this.jPanel2.setLayout(jPanel2Layout);
/*     */     jPanel2Layout.setHorizontalGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel2Layout.createSequentialGroup().addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addGroup(GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup().addComponent(this.jLabel6, -2, 102, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtFindItemTemplate)).addGroup(jPanel2Layout.createSequentialGroup().addComponent(this.jLabel5, -2, 102, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(this.jScrollPane5, GroupLayout.Alignment.TRAILING, -2, 0, 32767).addComponent((Component)this.button1, GroupLayout.Alignment.TRAILING, -1, 161, 32767).addComponent(this.cboItemTemplate, GroupLayout.Alignment.TRAILING, 0, -1, 32767)))).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel2Layout.createSequentialGroup().addComponent((Component)this.button11, -2, 100, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, -1, 32767).addComponent((Component)this.button6, -2, 212, -2)).addGroup(GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup().addComponent((Component)this.button10, -2, 100, -2).addGap(0, 0, 32767)).addGroup(jPanel2Layout.createSequentialGroup().addComponent(this.lblItemCache, -2, 100, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addGroup(jPanel2Layout.createSequentialGroup().addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jLabel13, -2, 100, -2).addComponent(this.jLabel14)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.cboOption, -2, 170, -2).addComponent(this.txtFindOption, -2, 170, -2))).addGroup(jPanel2Layout.createSequentialGroup().addComponent(this.jLabel15, -2, 90, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtParam, -1, -1, 32767))).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent((Component)this.button2, -1, 212, 32767).addComponent(this.jScrollPane2, -2, 0, 32767)))).addGap(0, 0, 0)));
/*     */     jPanel2Layout.linkSize(0, new Component[] { this.jLabel13, this.jLabel14, this.jLabel15 });
/*     */     jPanel2Layout.setVerticalGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel2Layout.createSequentialGroup().addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false).addComponent(this.lblItemCache, -1, -1, 32767).addGroup(jPanel2Layout.createSequentialGroup().addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(this.jLabel6, -1, -1, 32767).addComponent(this.txtFindItemTemplate, -2, 39, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false).addComponent(this.cboItemTemplate).addComponent(this.jLabel5, -2, 39, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button1, -2, 40, -2))).addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel2Layout.createSequentialGroup().addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jScrollPane5, -2, 202, -2)).addGroup(GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup().addGap(124, 124, 124).addComponent((Component)this.button11, -2, 39, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button10, -2, 39, -2)))).addGroup(jPanel2Layout.createSequentialGroup().addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel2Layout.createSequentialGroup().addComponent(this.jLabel13, -2, 39, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jLabel14, -2, 39, -2)).addComponent(this.jScrollPane2, -2, 194, -2).addGroup(jPanel2Layout.createSequentialGroup().addComponent(this.txtFindOption, -2, 39, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.cboOption, -2, 39, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.txtParam, -2, 39, -2).addComponent(this.jLabel15, -2, 39, -2)))).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button2, -2, 39, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button6, -2, 39, -2).addContainerGap(-1, 32767)));
/*     */     this.button13.setBackground(new Color(153, 0, 153));
/*     */     this.button13.setForeground(new Color(255, 255, 255));
/*     */     this.button13.setText("Modify all");
/*     */     this.button13.setFont(new Font("SansSerif", 1, 12));
/*     */     this.button13.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/*     */             CreateItemJsonScr.this.button13ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     this.button14.setBackground(new Color(153, 0, 153));
/*     */     this.button14.setForeground(new Color(255, 255, 255));
/*     */     this.button14.setText("Add all option");
/*     */     this.button14.setFont(new Font("SansSerif", 1, 12));
/*     */     this.button14.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/*     */             CreateItemJsonScr.this.button14ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     GroupLayout layout = new GroupLayout(getContentPane());
/*     */     getContentPane().setLayout(layout);
/*     */     layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jPanel2, -2, -1, -2).addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false).addGroup(layout.createSequentialGroup().addGap(102, 102, 102).addComponent((Component)this.button4, -2, 176, -2).addGap(361, 361, 361)).addGroup(GroupLayout.Alignment.LEADING, layout.createSequentialGroup().addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addComponent(this.jScrollPane3, -2, 278, -2).addGap(6, 6, 6).addComponent(this.jScrollPane4, -2, 281, -2)).addGroup(layout.createSequentialGroup().addComponent((Component)this.button13, -2, 100, -2).addGap(6, 6, 6).addComponent((Component)this.button14, -2, 100, -2).addGap(6, 6, 6).addComponent((Component)this.button9, -2, 100, -2).addGap(6, 6, 6).addComponent((Component)this.button5, -2, 100, -2))).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, -1, 32767)))).addGap(135, 135, 135)));
/*     */     layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addComponent(this.jPanel2, -2, -1, -2).addGap(11, 11, 11).addComponent((Component)this.button4, -2, 39, -2).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jScrollPane3, -2, 285, -2).addComponent(this.jScrollPane4, -2, 285, -2)).addGap(6, 6, 6).addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent((Component)this.button13, -2, 39, -2).addComponent((Component)this.button14, -2, 39, -2).addComponent((Component)this.button9, -2, 39, -2).addComponent((Component)this.button5, -2, 39, -2)).addGap(0, 0, 32767)));
/*     */     pack();
/*     */   }
/*     */   
/*     */   private void findItemOption() {
/*     */     String text = this.txtFindOption.getText();
/*     */     try {
/*     */       int id = Integer.parseInt(text);
/*     */       for (int i = 0; i < Manager.gI().getItemOptionTemplates().size(); i++) {
/*     */         if (((ItemOptionTemplate)Manager.gI().getItemOptionTemplates().get(i)).getId() == id) {
/*     */           this.cboOption.setSelectedIndex(i);
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } catch (Exception e) {
/*     */       for (int i = 0; i < Manager.gI().getItemOptionTemplates().size(); i++) {
/*     */         try {
/*     */           String name = ((ItemOptionTemplate)Manager.gI().getItemOptionTemplates().get(i)).getName();
/*     */           if (StringUtil.removeAccent(name).toLowerCase().contains(StringUtil.removeAccent(text).toLowerCase())) {
/*     */             this.cboOption.setSelectedIndex(i);
/*     */             break;
/*     */           } 
/*     */         } catch (Exception exception) {}
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void findItemTemplate() {
/*     */     String text = this.txtFindItemTemplate.getText();
/*     */     try {
/*     */       int id = Integer.parseInt(text);
/*     */       for (int i = 0; i < Manager.gI().getItemTemplates().size(); i++) {
/*     */         if (((ItemTemplate)Manager.gI().getItemTemplates().get(i)).getId() == id) {
/*     */           this.cboItemTemplate.setSelectedIndex(i);
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } catch (Exception e) {
/*     */       for (int i = 0; i < Manager.gI().getItemTemplates().size(); i++) {
/*     */         try {
/*     */           String name = ((ItemTemplate)Manager.gI().getItemTemplates().get(i)).getName();
/*     */           if (StringUtil.removeAccent(name).toLowerCase().contains(StringUtil.removeAccent(text).toLowerCase())) {
/*     */             this.cboItemTemplate.setSelectedIndex(i);
/*     */             break;
/*     */           } 
/*     */         } catch (Exception exception) {}
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void cboItemTemplateActionPerformed(ActionEvent evt) {
/*     */     try {
/*     */       BufferedImage image = Util.getImageById(((ItemTemplate)Manager.gI().getItemTemplates().get(this.cboItemTemplate.getSelectedIndex())).getIconId(), 2);
/*     */       this.lblItemCache.setIcon(new ImageIcon(image));
/*     */     } catch (Exception ex) {
/*     */       Logger.getLogger(CreateItemJsonScr.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void cboItemTemplateKeyReleased(KeyEvent evt) {}
/*     */   
/*     */   private void txtFindItemTemplateKeyPressed(KeyEvent evt) {
/*     */     findItemTemplate();
/*     */   }
/*     */   
/*     */   private void txtFindItemTemplateKeyReleased(KeyEvent evt) {
/*     */     findItemTemplate();
/*     */   }
/*     */   
/*     */   private void button1ActionPerformed(ActionEvent evt) {
/*     */     ItemCache itemReward = new ItemCache();
/*     */     itemReward.setTemp(Manager.gI().getItemTemplates().get(this.cboItemTemplate.getSelectedIndex()));
/*     */     try {
/*     */       this.listItemCache.add(itemReward);
/*     */       fillToTableListItemCache();
/*     */       showInfoItemCache();
/*     */     } catch (Exception e) {
/*     */       e.printStackTrace();
/*     */       NotifyUtil.showMessageDialog((JFrame)Main.I, "Thông tin không hợp lệ!");
/*     */     } 
/*     */   }
/*     */   
/*     */   private void fillToTableListItemCache() {
/*     */     this.modelItemCache.setRowCount(0);
/*     */     for (ItemCache itemCache : this.listItemCache) {
/*     */       this.modelItemCache.addRow(new Object[] { itemCache.getTemp().getName() });
/*     */     } 
/*     */     try {
/*     */       this.tblItemCache.setRowSelectionInterval(this.indexItemCache, this.indexItemCache);
/*     */     } catch (Exception exception) {}
/*     */   }
/*     */   
/*     */   private void txtFindOptionKeyPressed(KeyEvent evt) {
/*     */     findItemOption();
/*     */   }
/*     */   
/*     */   private void txtFindOptionKeyReleased(KeyEvent evt) {
/*     */     findItemOption();
/*     */   }
/*     */   
/*     */   private void button2ActionPerformed(ActionEvent evt) {
/*     */     if (!this.listItemCache.isEmpty())
/*     */       try {
/*     */         String textParam = this.txtParam.getText();
/*     */         String[] arrParam = textParam.split("-");
/*     */         int[] param = new int[2];
/*     */         if (arrParam.length == 2) {
/*     */           param[0] = Integer.parseInt(arrParam[0]);
/*     */           param[1] = Integer.parseInt(arrParam[1]);
/*     */         } else {
/*     */           param[0] = Integer.parseInt(arrParam[0]);
/*     */           param[1] = Integer.parseInt(arrParam[0]);
/*     */         } 
/*     */         for (ItemCache itemCache : this.listItemCache) {
/*     */           itemCache.getOptions().add(new ItemOptionReward(((ItemOptionTemplate)Manager.gI().getItemOptionTemplates().get(this.cboOption.getSelectedIndex())).getId(), param, new int[] { -1, -1 }));
/*     */         } 
/*     */         showInfoItemCache();
/*     */       } catch (Exception e) {
/*     */         NotifyUtil.showMessageDialog((JFrame)Main.I, "Vui lòng nhập thông tin hợp lệ!");
/*     */       }  
/*     */   }
/*     */   
/*     */   private void txtParamKeyPressed(KeyEvent evt) {}
/*     */   
/*     */   private void txtParamKeyReleased(KeyEvent evt) {}
/*     */   
/*     */   private void tblListMouseClicked(MouseEvent evt) {
/*     */     this.index = this.tblList.getSelectedRow();
/*     */     showInfoItem2();
/*     */   }
/*     */   
/*     */   private void showInfoItem2() {
/*     */     if (this.index != -1) {
/*     */       if (this.itemMobReward == null)
/*     */         this.itemMobReward = new ModifyItemMobReward(this); 
/*     */       ItemReward i = this.list.get(this.index);
/*     */       String info = i.getTemp().getName() + "\n-------Option-------\n";
/*     */       for (ItemOptionReward io : i.getOptions())
/*     */         info = info + io.getTemp().getName().replaceAll("#", "(" + io.getParam()[0] + " - " + io.getParam()[1] + ")") + "         [" + io.getParam()[0] + "/ " + io.getParam()[1] + "][" + io.getRatio()[0] + " - " + io.getRatio()[1] + "]\n"; 
/*     */       this.txtInfoItem2.setText(info);
/*     */       try {
/*     */         this.itemMobReward.show(i);
/*     */       } catch (Exception exception) {}
/*     */     } 
/*     */   }
/*     */   
/*     */   private void button4ActionPerformed(ActionEvent evt) {
/*     */     if (!this.listItemCache.isEmpty()) {
/*     */       for (ItemCache itemCache : this.listItemCache) {
/*     */         ItemReward item = new ItemReward();
/*     */         item.setTemp(itemCache.getTemp());
/*     */         item.setOptions(itemCache.getOptions());
/*     */         this.list.add(item);
/*     */       } 
/*     */       fillToTable();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void fillToTable() {
/*     */     this.index = -1;
/*     */     this.model.setRowCount(0);
/*     */     for (ItemReward item : this.list) {
/*     */       this.model.addRow(new Object[] { Integer.valueOf(item.getTemp().getId()), item.getTemp().getName() });
/*     */     } 
/*     */   }
/*     */   
/*     */   private void button5ActionPerformed(ActionEvent evt) {
/*     */     int[] selects = this.tblList.getSelectedRows();
/*     */     System.out.println(Arrays.toString(selects));
/*     */     for (int i = selects.length - 1; i >= 0; i--)
/*     */       this.list.remove(selects[i]); 
/*     */     fillToTable();
/*     */     try {
/*     */       this.itemMobReward.show((ItemReward)null);
/*     */     } catch (Exception exception) {}
/*     */   }
/*     */   
/*     */   private void button6ActionPerformed(ActionEvent evt) {
/*     */     if (this.indexOption != -1 && !this.listItemCache.isEmpty()) {
/*     */       for (ItemCache itemCache : this.listItemCache)
/*     */         itemCache.getOptions().remove(this.indexOption); 
/*     */       showInfoItemCache();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void tblOptionMouseClicked(MouseEvent evt) {
/*     */     this.indexOption = this.tblOption.getSelectedRow();
/*     */   }
/*     */   
/*     */   private void tblOptionMousePressed(MouseEvent evt) {
/*     */     this.indexOption = this.tblOption.getSelectedRow();
/*     */   }
/*     */   
/*     */   private void tblOptionMouseReleased(MouseEvent evt) {
/*     */     this.indexOption = this.tblOption.getSelectedRow();
/*     */   }
/*     */   
/*     */   private void readFileSave(File file) {}
/*     */   
/*     */   private void button9ActionPerformed(ActionEvent evt) {
/*     */     if (NotifyUtil.showConfirmDialog((JFrame)Main.I, "Bạn có chắc chắn muốn xóa tất cả?") == 0) {
/*     */       this.list.clear();
/*     */       fillToTable();
/*     */       if (this.itemMobReward != null && this.itemMobReward.isVisible())
/*     */         try {
/*     */           this.itemMobReward.show((ItemReward)null);
/*     */         } catch (Exception ex) {
/*     */           Logger.getLogger(CreateItemJsonScr.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */         }  
/*     */     } 
/*     */   }
/*     */   
/*     */   private void tblListKeyPressed(KeyEvent evt) {
/*     */     this.index = this.tblList.getSelectedRow();
/*     */     showInfoItem2();
/*     */   }
/*     */   
/*     */   private void tblListKeyReleased(KeyEvent evt) {
/*     */     this.index = this.tblList.getSelectedRow();
/*     */     showInfoItem2();
/*     */   }
/*     */   
/*     */   private void button10ActionPerformed(ActionEvent evt) {
/*     */     if (this.indexItemCache != -1) {
/*     */       this.listItemCache.remove(this.indexItemCache);
/*     */       fillToTableListItemCache();
/*     */       this.indexItemCache = -1;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void tblItemCacheMouseClicked(MouseEvent evt) {
/*     */     this.indexItemCache = this.tblItemCache.getSelectedRow();
/*     */     showInfoItemCache();
/*     */   }
/*     */   
/*     */   private void tblItemCacheKeyPressed(KeyEvent evt) {
/*     */     this.indexItemCache = this.tblItemCache.getSelectedRow();
/*     */     showInfoItemCache();
/*     */   }
/*     */   
/*     */   private void tblItemCacheKeyReleased(KeyEvent evt) {
/*     */     this.indexItemCache = this.tblItemCache.getSelectedRow();
/*     */     showInfoItemCache();
/*     */   }
/*     */   
/*     */   private void button11ActionPerformed(ActionEvent evt) {
/*     */     if (NotifyUtil.showConfirmDialog((JFrame)Main.I, "Bạn có chắc chắn muốn xóa tất cả?") == 0) {
/*     */       this.listItemCache.clear();
/*     */       fillToTableListItemCache();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void button13ActionPerformed(ActionEvent evt) {
/*     */     if (this.modifyAll == null)
/*     */       this.modifyAll = new ModifyAll(this, this.list); 
/*     */     this.modifyAll.setVisible(true);
/*     */   }
/*     */   
/*     */   private void button14ActionPerformed(ActionEvent evt) {
/*     */     if (this.addAllOptionScr == null)
/*     */       this.addAllOptionScr = new AddAllOptionScr(this, this.list); 
/*     */     this.addAllOptionScr.setVisible(true);
/*     */   }
/*     */   
/*     */   private void setup() {
/*     */     setTitle("Girlkun - Mob reward");
/*     */     setResizable(false);
/*     */     for (ItemTemplate item : Manager.gI().getItemTemplates())
/*     */       this.cboItemTemplate.addItem(item.getId() + " - " + item.getName()); 
/*     */     for (ItemOptionTemplate io : Manager.gI().getItemOptionTemplates())
/*     */       this.cboOption.addItem(io.getId() + " - " + io.getName()); 
/*     */     Dimension d = new Dimension(161, 39);
/*     */     this.modelOption = new DefaultTableModel((Object[])new String[] { "Option", "Ratio" }, 0) {
/*     */         public boolean isCellEditable(int row, int column) {
/*     */           return false;
/*     */         }
/*     */       };
/*     */     this.tblOption.setModel(this.modelOption);
/*     */     this.model = new DefaultTableModel((Object[])new String[] { "Item id", "Name" }, 0) {
/*     */         public boolean isCellEditable(int row, int column) {
/*     */           return false;
/*     */         }
/*     */       };
/*     */     this.tblList.setModel(this.model);
/*     */     this.modelItemCache = new DefaultTableModel((Object[])new String[] { "Item cache" }, 0) {
/*     */         public boolean isCellEditable(int row, int column) {
/*     */           return false;
/*     */         }
/*     */       };
/*     */     this.tblItemCache.setModel(this.modelItemCache);
/*     */   }
/*     */   
/*     */   private void showInfoItemCache() {
/*     */     this.modelOption.setRowCount(0);
/*     */     this.indexOption = -1;
/*     */     if (this.listItemCache.isEmpty())
/*     */       return; 
/*     */     if (this.indexItemCache == -1) {
/*     */       this.indexItemCache = 0;
/*     */       this.tblItemCache.setRowSelectionInterval(this.indexItemCache, this.indexItemCache);
/*     */     } 
/*     */     ItemCache itemCache = this.listItemCache.get(this.indexItemCache);
/*     */   }
/*     */ }


/* Location:              D:\nro\server_luxu_nrp\vemap\GirlkunToolCBRO.jar!\com\girlkun\tool\screens\mob_reward_scr_1\CreateItemJsonScr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */