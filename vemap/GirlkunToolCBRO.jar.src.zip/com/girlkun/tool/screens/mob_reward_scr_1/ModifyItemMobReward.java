/*     */ package com.girlkun.tool.screens.mob_reward_scr_1;
/*     */ import com.girlkun.tool.screens.mob_reward_scr.models.ItemReward;
/*     */ import java.awt.Font;
/*     */ import java.awt.event.KeyEvent;
/*     */ import javax.swing.GroupLayout;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.LayoutStyle;
/*     */ 
/*     */ public class ModifyItemMobReward extends JFrame {
/*     */   private CreateItemJsonScr mobRewardScr;
/*     */   private ItemReward item;
/*     */   private JLabel Gender;
/*     */   
/*     */   public ModifyItemMobReward(CreateItemJsonScr mobRewardScr) {
/*  16 */     this.mobRewardScr = mobRewardScr;
/*  17 */     initComponents();
/*  18 */     setup();
/*  19 */     setDefaultCloseOperation(2);
/*  20 */     setAlwaysOnTop(true);
/*     */   }
/*     */   private JComboBox<String> cboGender; private JLabel jLabel3; private JLabel jLabel4; private JLabel jLabel5; private JLabel jLabel6; private JLabel lblImageItem; private JLabel lblImageMob; private JLabel lblName; private JTextField txtQuanF; private JTextField txtQuanT;
/*     */   private JTextField txtRatio1;
/*     */   private JTextField txtRatio2;
/*     */   
/*     */   public void show(ItemReward item) throws Exception {
/*  27 */     this.item = item;
/*  28 */     if (item != null) {
/*  29 */       this.mobRewardScr = this.mobRewardScr;
/*  30 */       this.lblImageMob.setIcon(new ImageIcon(Util.getImageMobById(item.getMobId(), 0)));
/*  31 */       this.lblImageItem.setIcon(new ImageIcon(Util.getImageById(item.getTemp().getIconId(), 2)));
/*  32 */       this.txtQuanF.setText(item.getQuantity()[0] + "");
/*  33 */       this.txtQuanT.setText(item.getQuantity()[1] + "");
/*  34 */       this.txtRatio1.setText(item.getRatio()[1] + "");
/*  35 */       this.lblName.setText(item.getTemp().getName());
/*  36 */       this.txtRatio2.setText(item.getRatio()[1] + "");
/*     */     } else {
/*  38 */       this.txtQuanF.setText("");
/*  39 */       this.txtQuanT.setText("");
/*  40 */       this.txtRatio1.setText("");
/*  41 */       this.txtRatio2.setText("");
/*  42 */       this.lblImageItem.setIcon((Icon)null);
/*  43 */       this.lblImageMob.setIcon((Icon)null);
/*  44 */       this.lblName.setText("");
/*     */     } 
/*  46 */     if (!isVisible()) {
/*  47 */       setVisible(true);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initComponents() {
/*  55 */     this.lblImageMob = new JLabel();
/*  56 */     this.lblImageItem = new JLabel();
/*  57 */     this.lblName = new JLabel();
/*  58 */     this.jLabel3 = new JLabel();
/*  59 */     this.txtQuanF = new JTextField();
/*  60 */     this.jLabel4 = new JLabel();
/*  61 */     this.txtQuanT = new JTextField();
/*  62 */     this.jLabel5 = new JLabel();
/*  63 */     this.txtRatio1 = new JTextField();
/*  64 */     this.jLabel6 = new JLabel();
/*  65 */     this.txtRatio2 = new JTextField();
/*  66 */     this.Gender = new JLabel();
/*  67 */     this.cboGender = new JComboBox<>();
/*     */     
/*  69 */     setDefaultCloseOperation(3);
/*     */     
/*  71 */     this.lblName.setFont(new Font("SansSerif", 1, 12));
/*  72 */     this.lblName.setText("Name");
/*     */     
/*  74 */     this.jLabel3.setFont(new Font("SansSerif", 1, 12));
/*  75 */     this.jLabel3.setText("Quantity");
/*     */     
/*  77 */     this.txtQuanF.setFont(new Font("SansSerif", 1, 12));
/*  78 */     this.txtQuanF.addKeyListener(new KeyAdapter() {
/*     */           public void keyReleased(KeyEvent evt) {
/*  80 */             ModifyItemMobReward.this.txtQuanFKeyReleased(evt);
/*     */           }
/*     */         });
/*     */     
/*  84 */     this.jLabel4.setFont(new Font("SansSerif", 1, 12));
/*  85 */     this.jLabel4.setHorizontalAlignment(0);
/*  86 */     this.jLabel4.setText("to");
/*     */     
/*  88 */     this.txtQuanT.setFont(new Font("SansSerif", 1, 12));
/*  89 */     this.txtQuanT.addKeyListener(new KeyAdapter() {
/*     */           public void keyReleased(KeyEvent evt) {
/*  91 */             ModifyItemMobReward.this.txtQuanTKeyReleased(evt);
/*     */           }
/*     */         });
/*     */     
/*  95 */     this.jLabel5.setFont(new Font("SansSerif", 1, 12));
/*  96 */     this.jLabel5.setText("Ratio");
/*     */     
/*  98 */     this.txtRatio1.setFont(new Font("SansSerif", 1, 12));
/*  99 */     this.txtRatio1.addKeyListener(new KeyAdapter() {
/*     */           public void keyReleased(KeyEvent evt) {
/* 101 */             ModifyItemMobReward.this.txtRatio1KeyReleased(evt);
/*     */           }
/*     */         });
/*     */     
/* 105 */     this.jLabel6.setFont(new Font("SansSerif", 1, 12));
/* 106 */     this.jLabel6.setHorizontalAlignment(0);
/* 107 */     this.jLabel6.setText("/");
/*     */     
/* 109 */     this.txtRatio2.setFont(new Font("SansSerif", 1, 12));
/* 110 */     this.txtRatio2.addKeyListener(new KeyAdapter() {
/*     */           public void keyReleased(KeyEvent evt) {
/* 112 */             ModifyItemMobReward.this.txtRatio2KeyReleased(evt);
/*     */           }
/*     */         });
/*     */     
/* 116 */     this.Gender.setFont(new Font("SansSerif", 1, 12));
/* 117 */     this.Gender.setText("Gender");
/*     */     
/* 119 */     this.cboGender.setFont(new Font("SansSerif", 1, 12));
/* 120 */     this.cboGender.setModel(new DefaultComboBoxModel<>(new String[] { "All", "Trái đất", "Namếc", "Xayda" }));
/* 121 */     this.cboGender.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/* 123 */             ModifyItemMobReward.this.cboGenderActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     
/* 127 */     GroupLayout layout = new GroupLayout(getContentPane());
/* 128 */     getContentPane().setLayout(layout);
/* 129 */     layout.setHorizontalGroup(layout
/* 130 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 131 */         .addGroup(layout.createSequentialGroup()
/* 132 */           .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 133 */             .addComponent(this.lblName, -1, -1, 32767)
/* 134 */             .addGroup(layout.createSequentialGroup()
/* 135 */               .addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false)
/* 136 */                 .addGroup(layout.createSequentialGroup()
/* 137 */                   .addComponent(this.jLabel3, -2, 54, -2)
/* 138 */                   .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 139 */                   .addComponent(this.txtQuanF, -1, 64, 32767))
/* 140 */                 .addGroup(GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
/* 141 */                   .addComponent(this.jLabel5, -2, 54, -2)
/* 142 */                   .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 143 */                   .addComponent(this.txtRatio1)))
/* 144 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 145 */               .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 146 */                 .addGroup(layout.createSequentialGroup()
/* 147 */                   .addComponent(this.jLabel6, -2, 54, -2)
/* 148 */                   .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 149 */                   .addComponent(this.txtRatio2, -1, 61, 32767))
/* 150 */                 .addGroup(layout.createSequentialGroup()
/* 151 */                   .addComponent(this.jLabel4, -2, 54, -2)
/* 152 */                   .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 153 */                   .addComponent(this.txtQuanT))))
/* 154 */             .addGroup(layout.createSequentialGroup()
/* 155 */               .addComponent(this.lblImageMob, -2, 81, -2)
/* 156 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 157 */               .addComponent(this.lblImageItem, -2, 81, -2))
/* 158 */             .addGroup(layout.createSequentialGroup()
/* 159 */               .addComponent(this.Gender, -2, 54, -2)
/* 160 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 161 */               .addComponent(this.cboGender, 0, -1, 32767)))
/* 162 */           .addGap(0, 0, 0)));
/*     */     
/* 164 */     layout.setVerticalGroup(layout
/* 165 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 166 */         .addGroup(layout.createSequentialGroup()
/* 167 */           .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 168 */             .addComponent(this.lblImageMob, -2, 75, -2)
/* 169 */             .addComponent(this.lblImageItem, -2, 75, -2))
/* 170 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 171 */           .addComponent(this.lblName, -2, 39, -2)
/* 172 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 173 */           .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 174 */             .addComponent(this.jLabel3, -1, -1, 32767)
/* 175 */             .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 176 */               .addComponent(this.txtQuanF)
/* 177 */               .addComponent(this.jLabel4, -1, -1, 32767)
/* 178 */               .addComponent(this.txtQuanT, -2, 39, -2)))
/* 179 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 180 */           .addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING)
/* 181 */             .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 182 */               .addComponent(this.jLabel5, -1, -1, 32767)
/* 183 */               .addComponent(this.txtRatio1, -1, 39, 32767))
/* 184 */             .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 185 */               .addComponent(this.jLabel6, -1, -1, 32767)
/* 186 */               .addComponent(this.txtRatio2, -2, 39, -2)))
/* 187 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 188 */           .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 189 */             .addComponent(this.Gender, -1, -1, 32767)
/* 190 */             .addComponent(this.cboGender, -1, 45, 32767))
/* 191 */           .addContainerGap(-1, 32767)));
/*     */ 
/*     */     
/* 194 */     layout.linkSize(1, new Component[] { this.txtQuanF, this.txtRatio2 });
/*     */     
/* 196 */     pack();
/*     */   }
/*     */   
/*     */   private void txtQuanFKeyReleased(KeyEvent evt) {
/*     */     try {
/* 201 */       this.item.setQuantity(new int[] { Integer.parseInt(this.txtQuanF.getText()), this.item.getQuantity()[1] });
/* 202 */       this.mobRewardScr.fillToTable();
/* 203 */     } catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */   
/*     */   private void txtQuanTKeyReleased(KeyEvent evt) {
/*     */     try {
/* 209 */       this.item.setQuantity(new int[] { this.item.getQuantity()[0], Integer.parseInt(this.txtQuanT.getText()) });
/* 210 */       this.mobRewardScr.fillToTable();
/* 211 */     } catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */   
/*     */   private void txtRatio1KeyReleased(KeyEvent evt) {
/*     */     try {
/* 217 */       this.item.setRatio(new int[] { Integer.parseInt(this.txtRatio1.getText()), this.item.getRatio()[1] });
/* 218 */       this.mobRewardScr.fillToTable();
/* 219 */     } catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */   
/*     */   private void txtRatio2KeyReleased(KeyEvent evt) {
/*     */     try {
/* 225 */       this.item.setRatio(new int[] { this.item.getRatio()[0], Integer.parseInt(this.txtRatio2.getText()) });
/* 226 */       this.mobRewardScr.fillToTable();
/* 227 */     } catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */   
/*     */   private void cboGenderActionPerformed(ActionEvent evt) {
/*     */     try {
/* 233 */       this.item.setGender(this.cboGender.getSelectedIndex() - 1);
/* 234 */       this.mobRewardScr.fillToTable();
/* 235 */     } catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */   
/*     */   private void setup() {
/* 240 */     setResizable(false);
/* 241 */     setLocationRelativeTo((Component)null);
/*     */   }
/*     */ }


/* Location:              D:\nro\server_luxu_nrp\vemap\GirlkunToolCBRO.jar!\com\girlkun\tool\screens\mob_reward_scr_1\ModifyItemMobReward.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */