/*    */ package com.girlkun.tool.screens.mob_reward_scr_1.models;
/*    */ 
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ 
/*    */ public class ItemReward {
/*    */   private ItemTemplate temp;
/*    */   private int[] mapId;
/*    */   private int mobId;
/*    */   private int[] quantity;
/*    */   private int[] ratio;
/*    */   private int gender;
/*    */   
/* 14 */   public void setTemp(ItemTemplate temp) { this.temp = temp; } public void setMapId(int[] mapId) { this.mapId = mapId; } public void setMobId(int mobId) { this.mobId = mobId; } public void setQuantity(int[] quantity) { this.quantity = quantity; } public void setRatio(int[] ratio) { this.ratio = ratio; } public void setGender(int gender) { this.gender = gender; } public void setOptions(List<ItemOptionReward> options) { this.options = options; } public boolean equals(Object o) { if (o == this) return true;  if (!(o instanceof ItemReward)) return false;  ItemReward other = (ItemReward)o; if (!other.canEqual(this)) return false;  if (getMobId() != other.getMobId()) return false;  if (getGender() != other.getGender()) return false;  Object this$temp = getTemp(), other$temp = other.getTemp(); if ((this$temp == null) ? (other$temp != null) : !this$temp.equals(other$temp)) return false;  if (!Arrays.equals(getMapId(), other.getMapId())) return false;  if (!Arrays.equals(getQuantity(), other.getQuantity())) return false;  if (!Arrays.equals(getRatio(), other.getRatio())) return false;  Object<ItemOptionReward> this$options = (Object<ItemOptionReward>)getOptions(), other$options = (Object<ItemOptionReward>)other.getOptions(); return !((this$options == null) ? (other$options != null) : !this$options.equals(other$options)); } protected boolean canEqual(Object other) { return other instanceof ItemReward; } public int hashCode() { int PRIME = 59; result = 1; result = result * 59 + getMobId(); result = result * 59 + getGender(); Object $temp = getTemp(); result = result * 59 + (($temp == null) ? 43 : $temp.hashCode()); result = result * 59 + Arrays.hashCode(getMapId()); result = result * 59 + Arrays.hashCode(getQuantity()); result = result * 59 + Arrays.hashCode(getRatio()); Object<ItemOptionReward> $options = (Object<ItemOptionReward>)getOptions(); return result * 59 + (($options == null) ? 43 : $options.hashCode()); } public String toString() { return "ItemReward(temp=" + getTemp() + ", mapId=" + Arrays.toString(getMapId()) + ", mobId=" + getMobId() + ", quantity=" + Arrays.toString(getQuantity()) + ", ratio=" + Arrays.toString(getRatio()) + ", gender=" + getGender() + ", options=" + getOptions() + ")"; }
/*    */ 
/*    */   
/* 17 */   public ItemTemplate getTemp() { return this.temp; }
/* 18 */   public int[] getMapId() { return this.mapId; }
/* 19 */   public int getMobId() { return this.mobId; }
/* 20 */   public int[] getQuantity() { return this.quantity; }
/* 21 */   public int[] getRatio() { return this.ratio; } public int getGender() {
/* 22 */     return this.gender;
/*    */   }
/* 24 */   private List<ItemOptionReward> options = new ArrayList<>(); public List<ItemOptionReward> getOptions() { return this.options; }
/*    */ 
/*    */ }


/* Location:              D:\nro\server_luxu_nrp\vemap\GirlkunToolCBRO.jar!\com\girlkun\tool\screens\mob_reward_scr_1\models\ItemReward.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */