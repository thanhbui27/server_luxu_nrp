/*      */ package com.girlkun.tool.screens.mob_reward_scr;
/*      */ 
/*      */ import com.girlkun.button.Button;
/*      */ import com.girlkun.tool.entities.item.ItemOptionTemplate;
/*      */ import com.girlkun.tool.entities.item.ItemTemplate;
/*      */ import com.girlkun.tool.entities.map.MapTemplate;
/*      */ import com.girlkun.tool.entities.map.MobTemplate;
/*      */ import com.girlkun.tool.main.Main;
/*      */ import com.girlkun.tool.main.Manager;
/*      */ import com.girlkun.tool.screens.mob_reward_scr.models.ItemCache;
/*      */ import com.girlkun.tool.screens.mob_reward_scr.models.ItemOptionReward;
/*      */ import com.girlkun.tool.screens.mob_reward_scr.models.ItemReward;
/*      */ import com.girlkun.tool.utils.NotifyUtil;
/*      */ import com.girlkun.tool.utils.StringUtil;
/*      */ import com.girlkun.tool.utils.Util;
/*      */ import java.awt.Color;
/*      */ import java.awt.Component;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.Font;
/*      */ import java.awt.datatransfer.DataFlavor;
/*      */ import java.awt.datatransfer.Transferable;
/*      */ import java.awt.dnd.DropTarget;
/*      */ import java.awt.dnd.DropTargetDragEvent;
/*      */ import java.awt.dnd.DropTargetDropEvent;
/*      */ import java.awt.dnd.DropTargetEvent;
/*      */ import java.awt.dnd.DropTargetListener;
/*      */ import java.awt.event.ActionEvent;
/*      */ import java.awt.event.ActionListener;
/*      */ import java.awt.event.KeyAdapter;
/*      */ import java.awt.event.KeyEvent;
/*      */ import java.awt.event.MouseAdapter;
/*      */ import java.awt.event.MouseEvent;
/*      */ import java.awt.image.BufferedImage;
/*      */ import java.io.DataInputStream;
/*      */ import java.io.DataOutputStream;
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.FileOutputStream;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.List;
/*      */ import java.util.logging.Level;
/*      */ import java.util.logging.Logger;
/*      */ import javax.swing.DefaultComboBoxModel;
/*      */ import javax.swing.GroupLayout;
/*      */ import javax.swing.ImageIcon;
/*      */ import javax.swing.JComboBox;
/*      */ import javax.swing.JFileChooser;
/*      */ import javax.swing.JFrame;
/*      */ import javax.swing.JInternalFrame;
/*      */ import javax.swing.JLabel;
/*      */ import javax.swing.JPanel;
/*      */ import javax.swing.JScrollPane;
/*      */ import javax.swing.JTable;
/*      */ import javax.swing.JTextArea;
/*      */ import javax.swing.JTextField;
/*      */ import javax.swing.LayoutStyle;
/*      */ import javax.swing.table.DefaultTableModel;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class MobRewardScr
/*      */   extends JInternalFrame
/*      */ {
/*      */   private ModifyItemMobReward itemMobReward;
/*      */   private ModifyAll modifyAll;
/*      */   private AddAllOptionScr addAllOptionScr;
/*      */   private int indexItemCache;
/*      */   private DefaultTableModel modelItemCache;
/*      */   private DefaultTableModel modelOption;
/*      */   private int indexOption;
/*      */   private DefaultTableModel model;
/*      */   private List<ItemReward> list;
/*      */   private int index;
/*      */   private List<ItemCache> listItemCache;
/*      */   private Button button1;
/*      */   private Button button10;
/*      */   private Button button11;
/*      */   private Button button13;
/*      */   private Button button14;
/*      */   private Button button2;
/*      */   private Button button3;
/*      */   private Button button4;
/*      */   private Button button5;
/*      */   private Button button6;
/*      */   private Button button7;
/*      */   private Button button8;
/*      */   private Button button9;
/*      */   private JComboBox<String> cboGender;
/*      */   private JComboBox<String> cboItemTemplate;
/*      */   private JComboBox<String> cboMap;
/*      */   private JComboBox<String> cboMobTemplate;
/*      */   private JComboBox<String> cboOption;
/*      */   private JLabel jLabel1;
/*      */   private JLabel jLabel10;
/*      */   private JLabel jLabel11;
/*      */   private JLabel jLabel13;
/*      */   private JLabel jLabel14;
/*      */   private JLabel jLabel15;
/*      */   private JLabel jLabel16;
/*      */   private JLabel jLabel2;
/*      */   private JLabel jLabel3;
/*      */   private JLabel jLabel4;
/*      */   private JLabel jLabel5;
/*      */   private JLabel jLabel6;
/*      */   private JLabel jLabel7;
/*      */   private JLabel jLabel8;
/*      */   private JLabel jLabel9;
/*      */   private JPanel jPanel1;
/*      */   private JPanel jPanel2;
/*      */   private JScrollPane jScrollPane1;
/*      */   private JScrollPane jScrollPane2;
/*      */   private JScrollPane jScrollPane3;
/*      */   private JScrollPane jScrollPane4;
/*      */   private JScrollPane jScrollPane5;
/*      */   private JLabel lblImageItem;
/*      */   private JLabel lblImageMob;
/*      */   private JLabel lblItemCache;
/*      */   private JTable tblItemCache;
/*      */   private JTable tblList;
/*      */   private JTable tblOption;
/*      */   private JTextField txtFindItemTemplate;
/*      */   private JTextField txtFindOption;
/*      */   private JTextArea txtInfoItem2;
/*      */   private JTextArea txtInfoItemCache;
/*      */   private JTextField txtMap;
/*      */   private JTextField txtMob;
/*      */   private JTextField txtParam;
/*      */   private JTextField txtQuanF;
/*      */   private JTextField txtQuanT;
/*      */   private JTextField txtR1;
/*      */   private JTextField txtR2;
/*      */   private JTextField txtRatio1;
/*      */   private JTextField txtRatio2;
/*      */   
/*      */   public MobRewardScr() {
/* 1465 */     this.indexItemCache = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1512 */     this.indexOption = -1;
/*      */     
/* 1514 */     this.list = new ArrayList<>();
/* 1515 */     this.index = -1;
/* 1516 */     this.listItemCache = new ArrayList<>();
/*      */     initComponents();
/*      */     setup();
/*      */     new DropTarget(this, new DropTargetListener() {
/*      */           public void dragEnter(DropTargetDragEvent dtde) {}
/*      */           
/*      */           public void dragOver(DropTargetDragEvent dtde) {}
/*      */           
/*      */           public void dropActionChanged(DropTargetDragEvent dtde) {}
/*      */           
/*      */           public void dragExit(DropTargetEvent dte) {}
/*      */           
/*      */           public void drop(DropTargetDropEvent ev) {
/*      */             ev.acceptDrop(1);
/*      */             Transferable t = ev.getTransferable();
/*      */             DataFlavor[] df = t.getTransferDataFlavors();
/*      */             for (DataFlavor f : df) {
/*      */               try {
/*      */                 if (f.isFlavorJavaFileListType()) {
/*      */                   List<File> files = (List<File>)t.getTransferData(f);
/*      */                   for (File file : files)
/*      */                     MobRewardScr.this.readFileSave(file); 
/*      */                 } 
/*      */               } catch (Exception exception) {}
/*      */             } 
/*      */           }
/*      */         });
/*      */   }
/*      */   
/*      */   private void initComponents() {
/*      */     this.jLabel1 = new JLabel();
/*      */     this.cboMobTemplate = new JComboBox<>();
/*      */     this.lblImageMob = new JLabel();
/*      */     this.jLabel2 = new JLabel();
/*      */     this.txtMob = new JTextField();
/*      */     this.jLabel3 = new JLabel();
/*      */     this.jLabel4 = new JLabel();
/*      */     this.cboMap = new JComboBox<>();
/*      */     this.txtMap = new JTextField();
/*      */     this.cboItemTemplate = new JComboBox<>();
/*      */     this.jLabel5 = new JLabel();
/*      */     this.jLabel6 = new JLabel();
/*      */     this.txtFindItemTemplate = new JTextField();
/*      */     this.lblImageItem = new JLabel();
/*      */     this.jLabel7 = new JLabel();
/*      */     this.txtQuanF = new JTextField();
/*      */     this.jLabel8 = new JLabel();
/*      */     this.txtQuanT = new JTextField();
/*      */     this.jLabel9 = new JLabel();
/*      */     this.txtRatio1 = new JTextField();
/*      */     this.jLabel10 = new JLabel();
/*      */     this.txtRatio2 = new JTextField();
/*      */     this.button1 = new Button();
/*      */     this.jLabel11 = new JLabel();
/*      */     this.cboGender = new JComboBox<>();
/*      */     this.jScrollPane1 = new JScrollPane();
/*      */     this.txtInfoItemCache = new JTextArea();
/*      */     this.button3 = new Button();
/*      */     this.button4 = new Button();
/*      */     this.jScrollPane3 = new JScrollPane();
/*      */     this.tblList = new JTable();
/*      */     this.jScrollPane4 = new JScrollPane();
/*      */     this.txtInfoItem2 = new JTextArea();
/*      */     this.button5 = new Button();
/*      */     this.button7 = new Button();
/*      */     this.button8 = new Button();
/*      */     this.jPanel1 = new JPanel();
/*      */     this.button6 = new Button();
/*      */     this.jScrollPane2 = new JScrollPane();
/*      */     this.tblOption = new JTable();
/*      */     this.button2 = new Button();
/*      */     this.txtParam = new JTextField();
/*      */     this.cboOption = new JComboBox<>();
/*      */     this.txtFindOption = new JTextField();
/*      */     this.jLabel13 = new JLabel();
/*      */     this.jLabel14 = new JLabel();
/*      */     this.jLabel15 = new JLabel();
/*      */     this.txtR1 = new JTextField();
/*      */     this.jLabel16 = new JLabel();
/*      */     this.txtR2 = new JTextField();
/*      */     this.button9 = new Button();
/*      */     this.jPanel2 = new JPanel();
/*      */     this.jScrollPane5 = new JScrollPane();
/*      */     this.tblItemCache = new JTable();
/*      */     this.button10 = new Button();
/*      */     this.lblItemCache = new JLabel();
/*      */     this.button11 = new Button();
/*      */     this.button13 = new Button();
/*      */     this.button14 = new Button();
/*      */     setClosable(true);
/*      */     setIconifiable(true);
/*      */     setResizable(true);
/*      */     this.jLabel1.setFont(new Font("SansSerif", 1, 12));
/*      */     this.jLabel1.setText("Mob template");
/*      */     this.cboMobTemplate.setBackground(new Color(255, 204, 255));
/*      */     this.cboMobTemplate.setFont(new Font("SansSerif", 1, 12));
/*      */     this.cboMobTemplate.setForeground(new Color(51, 0, 51));
/*      */     this.cboMobTemplate.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/*      */             MobRewardScr.this.cboMobTemplateActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     this.cboMobTemplate.addKeyListener(new KeyAdapter() {
/*      */           public void keyReleased(KeyEvent evt) {
/*      */             MobRewardScr.this.cboMobTemplateKeyReleased(evt);
/*      */           }
/*      */         });
/*      */     this.lblImageMob.setHorizontalAlignment(0);
/*      */     this.jLabel2.setFont(new Font("SansSerif", 1, 12));
/*      */     this.jLabel2.setText("Mob");
/*      */     this.txtMob.setFont(new Font("SansSerif", 1, 12));
/*      */     this.txtMob.setPreferredSize(new Dimension(17, 22));
/*      */     this.txtMob.addKeyListener(new KeyAdapter() {
/*      */           public void keyReleased(KeyEvent evt) {
/*      */             MobRewardScr.this.txtMobKeyReleased(evt);
/*      */           }
/*      */         });
/*      */     this.jLabel3.setFont(new Font("SansSerif", 1, 12));
/*      */     this.jLabel3.setText("Map");
/*      */     this.jLabel4.setFont(new Font("SansSerif", 1, 12));
/*      */     this.jLabel4.setText("Map template");
/*      */     this.cboMap.setBackground(new Color(255, 204, 255));
/*      */     this.cboMap.setFont(new Font("SansSerif", 1, 12));
/*      */     this.cboMap.setForeground(new Color(51, 0, 51));
/*      */     this.cboMap.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/*      */             MobRewardScr.this.cboMapActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     this.cboMap.addKeyListener(new KeyAdapter() {
/*      */           public void keyReleased(KeyEvent evt) {
/*      */             MobRewardScr.this.cboMapKeyReleased(evt);
/*      */           }
/*      */         });
/*      */     this.txtMap.setFont(new Font("SansSerif", 1, 12));
/*      */     this.txtMap.addKeyListener(new KeyAdapter() {
/*      */           public void keyReleased(KeyEvent evt) {
/*      */             MobRewardScr.this.txtMapKeyReleased(evt);
/*      */           }
/*      */         });
/*      */     this.cboItemTemplate.setBackground(new Color(255, 204, 255));
/*      */     this.cboItemTemplate.setFont(new Font("SansSerif", 1, 12));
/*      */     this.cboItemTemplate.setForeground(new Color(51, 0, 51));
/*      */     this.cboItemTemplate.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/*      */             MobRewardScr.this.cboItemTemplateActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     this.cboItemTemplate.addKeyListener(new KeyAdapter() {
/*      */           public void keyReleased(KeyEvent evt) {
/*      */             MobRewardScr.this.cboItemTemplateKeyReleased(evt);
/*      */           }
/*      */         });
/*      */     this.jLabel5.setFont(new Font("SansSerif", 1, 12));
/*      */     this.jLabel5.setText("Item template");
/*      */     this.jLabel6.setFont(new Font("SansSerif", 1, 12));
/*      */     this.jLabel6.setText("Search item");
/*      */     this.txtFindItemTemplate.setBackground(new Color(255, 204, 255));
/*      */     this.txtFindItemTemplate.setFont(new Font("SansSerif", 1, 12));
/*      */     this.txtFindItemTemplate.setForeground(new Color(51, 0, 51));
/*      */     this.txtFindItemTemplate.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/*      */             MobRewardScr.this.txtFindItemTemplateKeyPressed(evt);
/*      */           }
/*      */           
/*      */           public void keyReleased(KeyEvent evt) {
/*      */             MobRewardScr.this.txtFindItemTemplateKeyReleased(evt);
/*      */           }
/*      */         });
/*      */     this.lblImageItem.setHorizontalAlignment(0);
/*      */     this.jLabel7.setFont(new Font("SansSerif", 1, 12));
/*      */     this.jLabel7.setText("Quantity from");
/*      */     this.txtQuanF.setFont(new Font("SansSerif", 1, 12));
/*      */     this.txtQuanF.setText("1");
/*      */     this.txtQuanF.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/*      */             MobRewardScr.this.txtQuanFKeyPressed(evt);
/*      */           }
/*      */           
/*      */           public void keyReleased(KeyEvent evt) {
/*      */             MobRewardScr.this.txtQuanFKeyReleased(evt);
/*      */           }
/*      */         });
/*      */     this.jLabel8.setFont(new Font("SansSerif", 1, 12));
/*      */     this.jLabel8.setText("Quantity to");
/*      */     this.txtQuanT.setFont(new Font("SansSerif", 1, 12));
/*      */     this.txtQuanT.setText("1");
/*      */     this.txtQuanT.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/*      */             MobRewardScr.this.txtQuanTKeyPressed(evt);
/*      */           }
/*      */           
/*      */           public void keyReleased(KeyEvent evt) {
/*      */             MobRewardScr.this.txtQuanTKeyReleased(evt);
/*      */           }
/*      */         });
/*      */     this.jLabel9.setFont(new Font("SansSerif", 1, 12));
/*      */     this.jLabel9.setText("Ratio");
/*      */     this.txtRatio1.setFont(new Font("SansSerif", 1, 12));
/*      */     this.txtRatio1.setText("100");
/*      */     this.txtRatio1.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/*      */             MobRewardScr.this.txtRatio1KeyPressed(evt);
/*      */           }
/*      */           
/*      */           public void keyReleased(KeyEvent evt) {
/*      */             MobRewardScr.this.txtRatio1KeyReleased(evt);
/*      */           }
/*      */         });
/*      */     this.jLabel10.setText("/");
/*      */     this.txtRatio2.setFont(new Font("SansSerif", 1, 12));
/*      */     this.txtRatio2.setText("100");
/*      */     this.txtRatio2.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/*      */             MobRewardScr.this.txtRatio2KeyPressed(evt);
/*      */           }
/*      */           
/*      */           public void keyReleased(KeyEvent evt) {
/*      */             MobRewardScr.this.txtRatio2KeyReleased(evt);
/*      */           }
/*      */         });
/*      */     this.button1.setBackground(new Color(153, 0, 153));
/*      */     this.button1.setForeground(new Color(255, 255, 255));
/*      */     this.button1.setText("Add item cache");
/*      */     this.button1.setFont(new Font("SansSerif", 1, 12));
/*      */     this.button1.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/*      */             MobRewardScr.this.button1ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     this.jLabel11.setFont(new Font("SansSerif", 1, 12));
/*      */     this.jLabel11.setText("For gender");
/*      */     this.cboGender.setFont(new Font("SansSerif", 1, 12));
/*      */     this.cboGender.setModel(new DefaultComboBoxModel<>(new String[] { "All", "Trái đất", "Namếc", "Xayda" }));
/*      */     this.cboGender.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/*      */             MobRewardScr.this.cboGenderActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     this.cboGender.addKeyListener(new KeyAdapter() {
/*      */           public void keyReleased(KeyEvent evt) {
/*      */             MobRewardScr.this.cboGenderKeyReleased(evt);
/*      */           }
/*      */         });
/*      */     this.txtInfoItemCache.setEditable(false);
/*      */     this.txtInfoItemCache.setColumns(20);
/*      */     this.txtInfoItemCache.setFont(new Font("SansSerif", 1, 12));
/*      */     this.txtInfoItemCache.setLineWrap(true);
/*      */     this.txtInfoItemCache.setRows(5);
/*      */     this.txtInfoItemCache.setWrapStyleWord(true);
/*      */     this.jScrollPane1.setViewportView(this.txtInfoItemCache);
/*      */     this.button3.setBackground(new Color(153, 0, 153));
/*      */     this.button3.setForeground(new Color(255, 255, 255));
/*      */     this.button3.setText("Default option");
/*      */     this.button3.setFont(new Font("SansSerif", 1, 12));
/*      */     this.button4.setBackground(new Color(153, 0, 153));
/*      */     this.button4.setForeground(new Color(255, 255, 255));
/*      */     this.button4.setText("Add to list");
/*      */     this.button4.setFont(new Font("SansSerif", 1, 12));
/*      */     this.button4.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/*      */             MobRewardScr.this.button4ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     this.tblList.setModel(new DefaultTableModel(new Object[0][], (Object[])new String[0]));
/*      */     this.tblList.addMouseListener(new MouseAdapter() {
/*      */           public void mouseClicked(MouseEvent evt) {
/*      */             MobRewardScr.this.tblListMouseClicked(evt);
/*      */           }
/*      */         });
/*      */     this.tblList.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/*      */             MobRewardScr.this.tblListKeyPressed(evt);
/*      */           }
/*      */           
/*      */           public void keyReleased(KeyEvent evt) {
/*      */             MobRewardScr.this.tblListKeyReleased(evt);
/*      */           }
/*      */         });
/*      */     this.jScrollPane3.setViewportView(this.tblList);
/*      */     this.txtInfoItem2.setEditable(false);
/*      */     this.txtInfoItem2.setColumns(20);
/*      */     this.txtInfoItem2.setFont(new Font("SansSerif", 1, 12));
/*      */     this.txtInfoItem2.setLineWrap(true);
/*      */     this.txtInfoItem2.setRows(5);
/*      */     this.txtInfoItem2.setWrapStyleWord(true);
/*      */     this.jScrollPane4.setViewportView(this.txtInfoItem2);
/*      */     this.button5.setBackground(new Color(204, 0, 0));
/*      */     this.button5.setForeground(new Color(255, 255, 255));
/*      */     this.button5.setText("Remove item");
/*      */     this.button5.setFont(new Font("SansSerif", 1, 12));
/*      */     this.button5.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/*      */             MobRewardScr.this.button5ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     this.button7.setBackground(new Color(153, 0, 153));
/*      */     this.button7.setForeground(new Color(255, 255, 255));
/*      */     this.button7.setText("Export");
/*      */     this.button7.setFont(new Font("SansSerif", 1, 12));
/*      */     this.button7.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/*      */             MobRewardScr.this.button7ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     this.button8.setBackground(new Color(153, 0, 153));
/*      */     this.button8.setForeground(new Color(255, 255, 255));
/*      */     this.button8.setText("Import");
/*      */     this.button8.setFont(new Font("SansSerif", 1, 12));
/*      */     this.button8.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/*      */             MobRewardScr.this.button8ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     this.button6.setBackground(new Color(204, 0, 0));
/*      */     this.button6.setForeground(new Color(255, 255, 255));
/*      */     this.button6.setText("Remove option");
/*      */     this.button6.setFont(new Font("SansSerif", 1, 12));
/*      */     this.button6.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/*      */             MobRewardScr.this.button6ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     this.tblOption.setModel(new DefaultTableModel(new Object[0][], (Object[])new String[0]));
/*      */     this.tblOption.addMouseListener(new MouseAdapter() {
/*      */           public void mouseClicked(MouseEvent evt) {
/*      */             MobRewardScr.this.tblOptionMouseClicked(evt);
/*      */           }
/*      */           
/*      */           public void mousePressed(MouseEvent evt) {
/*      */             MobRewardScr.this.tblOptionMousePressed(evt);
/*      */           }
/*      */           
/*      */           public void mouseReleased(MouseEvent evt) {
/*      */             MobRewardScr.this.tblOptionMouseReleased(evt);
/*      */           }
/*      */         });
/*      */     this.jScrollPane2.setViewportView(this.tblOption);
/*      */     this.button2.setBackground(new Color(153, 0, 153));
/*      */     this.button2.setForeground(new Color(255, 255, 255));
/*      */     this.button2.setText("Add option");
/*      */     this.button2.setFont(new Font("SansSerif", 1, 12));
/*      */     this.button2.setMaximumSize(new Dimension(152, 39));
/*      */     this.button2.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/*      */             MobRewardScr.this.button2ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     this.txtParam.setFont(new Font("SansSerif", 1, 12));
/*      */     this.txtParam.setText("Eg: 752002 or 75-2002");
/*      */     this.txtParam.setMaximumSize(new Dimension(152, 39));
/*      */     this.txtParam.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/*      */             MobRewardScr.this.txtParamKeyPressed(evt);
/*      */           }
/*      */           
/*      */           public void keyReleased(KeyEvent evt) {
/*      */             MobRewardScr.this.txtParamKeyReleased(evt);
/*      */           }
/*      */         });
/*      */     this.cboOption.setBackground(new Color(255, 204, 255));
/*      */     this.cboOption.setFont(new Font("SansSerif", 1, 12));
/*      */     this.cboOption.setForeground(new Color(51, 0, 51));
/*      */     this.cboOption.setMaximumSize(new Dimension(152, 39));
/*      */     this.txtFindOption.setBackground(new Color(255, 204, 255));
/*      */     this.txtFindOption.setFont(new Font("SansSerif", 1, 12));
/*      */     this.txtFindOption.setForeground(new Color(51, 0, 51));
/*      */     this.txtFindOption.setMaximumSize(new Dimension(152, 39));
/*      */     this.txtFindOption.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/*      */             MobRewardScr.this.txtFindOptionKeyPressed(evt);
/*      */           }
/*      */           
/*      */           public void keyReleased(KeyEvent evt) {
/*      */             MobRewardScr.this.txtFindOptionKeyReleased(evt);
/*      */           }
/*      */         });
/*      */     this.jLabel13.setFont(new Font("SansSerif", 1, 12));
/*      */     this.jLabel13.setText("Search option");
/*      */     this.jLabel14.setFont(new Font("SansSerif", 1, 12));
/*      */     this.jLabel14.setText("Option template");
/*      */     this.jLabel15.setFont(new Font("SansSerif", 1, 12));
/*      */     this.jLabel15.setText("Param");
/*      */     this.txtR1.setFont(new Font("SansSerif", 1, 12));
/*      */     this.txtR1.setText("100");
/*      */     this.txtR1.setMaximumSize(new Dimension(152, 39));
/*      */     this.txtR1.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/*      */             MobRewardScr.this.txtR1KeyPressed(evt);
/*      */           }
/*      */           
/*      */           public void keyReleased(KeyEvent evt) {
/*      */             MobRewardScr.this.txtR1KeyReleased(evt);
/*      */           }
/*      */         });
/*      */     this.jLabel16.setFont(new Font("SansSerif", 1, 12));
/*      */     this.jLabel16.setText("Ratio");
/*      */     this.txtR2.setFont(new Font("SansSerif", 1, 12));
/*      */     this.txtR2.setText("100");
/*      */     this.txtR2.setMaximumSize(new Dimension(152, 39));
/*      */     this.txtR2.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/*      */             MobRewardScr.this.txtR2KeyPressed(evt);
/*      */           }
/*      */           
/*      */           public void keyReleased(KeyEvent evt) {
/*      */             MobRewardScr.this.txtR2KeyReleased(evt);
/*      */           }
/*      */         });
/*      */     GroupLayout jPanel1Layout = new GroupLayout(this.jPanel1);
/*      */     this.jPanel1.setLayout(jPanel1Layout);
/*      */     jPanel1Layout.setHorizontalGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jLabel13, -2, 100, -2).addComponent(this.jLabel14).addComponent(this.jLabel15, -2, 90, -2).addComponent(this.jLabel16, -2, 90, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent((Component)this.button2, -1, -1, 32767).addComponent(this.cboOption, 0, -1, 32767).addComponent(this.txtParam, -1, -1, 32767).addComponent(this.txtFindOption, -1, -1, 32767).addGroup(jPanel1Layout.createSequentialGroup().addComponent(this.txtR1, -2, 82, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtR2, -2, 82, -2).addGap(0, 111, 32767))).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jScrollPane2, -2, 212, -2).addComponent((Component)this.button6, -2, 212, -2))));
/*      */     jPanel1Layout.linkSize(0, new Component[] { this.jLabel13, this.jLabel14, this.jLabel15, this.jLabel16 });
/*      */     jPanel1Layout.setVerticalGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addComponent(this.jLabel13, -2, 39, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jLabel14, -2, 39, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jLabel15, -2, 39, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jLabel16, -2, 39, -2)).addGroup(jPanel1Layout.createSequentialGroup().addComponent(this.txtFindOption, -2, 39, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.cboOption, -2, 39, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtParam, -2, 39, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.txtR1, -2, 39, -2).addComponent(this.txtR2, -2, 39, -2)))).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent((Component)this.button2, -2, 39, -2).addComponent((Component)this.button6, -2, 39, -2))).addComponent(this.jScrollPane2, -2, 174, -2)).addContainerGap(-1, 32767)));
/*      */     this.button9.setBackground(new Color(204, 0, 0));
/*      */     this.button9.setForeground(new Color(255, 255, 255));
/*      */     this.button9.setText("Clear all item");
/*      */     this.button9.setFont(new Font("SansSerif", 1, 12));
/*      */     this.button9.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/*      */             MobRewardScr.this.button9ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     this.tblItemCache.setModel(new DefaultTableModel(new Object[0][], (Object[])new String[0]));
/*      */     this.tblItemCache.addMouseListener(new MouseAdapter() {
/*      */           public void mouseClicked(MouseEvent evt) {
/*      */             MobRewardScr.this.tblItemCacheMouseClicked(evt);
/*      */           }
/*      */         });
/*      */     this.tblItemCache.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/*      */             MobRewardScr.this.tblItemCacheKeyPressed(evt);
/*      */           }
/*      */           
/*      */           public void keyReleased(KeyEvent evt) {
/*      */             MobRewardScr.this.tblItemCacheKeyReleased(evt);
/*      */           }
/*      */         });
/*      */     this.jScrollPane5.setViewportView(this.tblItemCache);
/*      */     this.button10.setBackground(new Color(204, 0, 0));
/*      */     this.button10.setForeground(new Color(255, 255, 255));
/*      */     this.button10.setText("Remove");
/*      */     this.button10.setFont(new Font("SansSerif", 1, 12));
/*      */     this.button10.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/*      */             MobRewardScr.this.button10ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     this.lblItemCache.setHorizontalAlignment(0);
/*      */     this.button11.setBackground(new Color(204, 0, 0));
/*      */     this.button11.setForeground(new Color(255, 255, 255));
/*      */     this.button11.setText("Clear all");
/*      */     this.button11.setFont(new Font("SansSerif", 1, 12));
/*      */     this.button11.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/*      */             MobRewardScr.this.button11ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     GroupLayout jPanel2Layout = new GroupLayout(this.jPanel2);
/*      */     this.jPanel2.setLayout(jPanel2Layout);
/*      */     jPanel2Layout.setHorizontalGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel2Layout.createSequentialGroup().addComponent(this.jScrollPane5, -2, 175, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.lblItemCache, -2, 100, -2).addComponent((Component)this.button10, -2, 100, -2).addComponent((Component)this.button11, -2, 100, -2)).addGap(0, 285, 32767)));
/*      */     jPanel2Layout.setVerticalGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jScrollPane5, -2, 0, 32767).addGroup(jPanel2Layout.createSequentialGroup().addComponent(this.lblItemCache, -2, 89, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, -1, 32767).addComponent((Component)this.button11, -2, 39, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button10, -2, 39, -2)));
/*      */     this.button13.setBackground(new Color(153, 0, 153));
/*      */     this.button13.setForeground(new Color(255, 255, 255));
/*      */     this.button13.setText("Modify all");
/*      */     this.button13.setFont(new Font("SansSerif", 1, 12));
/*      */     this.button13.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/*      */             MobRewardScr.this.button13ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     this.button14.setBackground(new Color(153, 0, 153));
/*      */     this.button14.setForeground(new Color(255, 255, 255));
/*      */     this.button14.setText("Add all option");
/*      */     this.button14.setFont(new Font("SansSerif", 1, 12));
/*      */     this.button14.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/*      */             MobRewardScr.this.button14ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     GroupLayout layout = new GroupLayout(getContentPane());
/*      */     getContentPane().setLayout(layout);
/*      */     layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(GroupLayout.Alignment.TRAILING, layout.createSequentialGroup().addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addGroup(layout.createSequentialGroup().addComponent(this.jLabel9, -2, 102, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtRatio1, -2, 74, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jLabel10).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtRatio2)).addGroup(layout.createSequentialGroup().addComponent(this.jLabel8, -2, 102, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtQuanT)).addGroup(layout.createSequentialGroup().addComponent(this.jLabel7, -2, 102, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtQuanF)).addGroup(GroupLayout.Alignment.TRAILING, layout.createSequentialGroup().addComponent(this.jLabel2, -2, 102, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtMob, -1, -1, 32767)).addGroup(layout.createSequentialGroup().addComponent(this.jLabel1, -2, 102, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.cboMobTemplate, -2, 161, -2)).addGroup(GroupLayout.Alignment.TRAILING, layout.createSequentialGroup().addComponent(this.jLabel3, -2, 102, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtMap)).addGroup(GroupLayout.Alignment.TRAILING, layout.createSequentialGroup().addComponent(this.jLabel4, -2, 102, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.cboMap, -2, 161, -2)).addGroup(GroupLayout.Alignment.TRAILING, layout.createSequentialGroup().addComponent(this.jLabel6, -2, 102, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtFindItemTemplate)).addGroup(layout.createSequentialGroup().addComponent(this.jLabel5, -2, 102, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.cboItemTemplate, -2, 161, -2))).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addComponent(this.lblImageMob, -2, 83, -2).addGap(5, 5, 5)).addGroup(GroupLayout.Alignment.TRAILING, layout.createSequentialGroup().addComponent(this.lblImageItem, -2, 83, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)))).addGroup(layout.createSequentialGroup().addComponent(this.jLabel11, -2, 102, -2).addGap(4, 4, 4).addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false).addComponent((Component)this.button1, GroupLayout.Alignment.LEADING, -1, -1, 32767).addComponent(this.cboGender, 0, 161, 32767)).addGap(92, 92, 92)).addGroup(layout.createSequentialGroup().addComponent(this.jScrollPane4).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED))).addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addComponent(this.jScrollPane3, -1, 689, 32767).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent((Component)this.button5, -1, 100, 32767).addComponent((Component)this.button9, -1, 100, 32767).addComponent((Component)this.button13, -1, -1, 32767).addComponent((Component)this.button14, -1, -1, 32767))).addGroup(layout.createSequentialGroup().addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(this.jScrollPane1, -2, 0, 32767).addComponent((Component)this.button3, -1, -1, 32767).addComponent((Component)this.button4, -2, 176, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jPanel1, -1, -1, 32767)).addGroup(layout.createSequentialGroup().addGap(0, 0, 32767).addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent((Component)this.button7, GroupLayout.Alignment.TRAILING, -2, 87, -2).addComponent((Component)this.button8, GroupLayout.Alignment.TRAILING, -2, 87, -2))).addGroup(layout.createSequentialGroup().addComponent(this.jPanel2, -2, -1, -2).addGap(0, 0, 32767))).addContainerGap()))));
/*      */     layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap(144, 32767).addComponent((Component)this.button8, -2, 39, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button7, -2, 39, -2)).addComponent(this.jPanel2, -1, -1, 32767)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addComponent(this.jScrollPane1, -2, 180, -2).addGap(5, 5, 5).addComponent((Component)this.button3, -2, 39, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button4, -2, 39, -2)).addComponent(this.jPanel1, -2, -1, -2))).addGroup(layout.createSequentialGroup().addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(this.lblImageMob, -1, -1, 32767).addGroup(layout.createSequentialGroup().addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false).addComponent(this.cboMobTemplate).addComponent(this.jLabel1, -2, 39, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(this.jLabel2, -1, -1, 32767).addComponent(this.txtMob, -2, 39, -2)))).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false).addComponent(this.cboMap).addComponent(this.jLabel4, -2, 39, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(this.jLabel3, -1, -1, 32767).addComponent(this.txtMap, -2, 39, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(this.jLabel6, -1, -1, 32767).addComponent(this.txtFindItemTemplate, -2, 39, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false).addComponent(this.cboItemTemplate).addComponent(this.jLabel5, -2, 39, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(this.jLabel7, -1, -1, 32767).addComponent(this.txtQuanF, -2, 39, -2))).addComponent(this.lblImageItem, -2, 84, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(this.jLabel8, -1, -1, 32767).addComponent(this.txtQuanT, -2, 39, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(this.jLabel9, -1, -1, 32767).addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.txtRatio1, -2, 39, -2).addComponent(this.jLabel10, -1, -1, 32767).addComponent(this.txtRatio2, -2, 39, -2))).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel11, -2, 39, -2).addComponent(this.cboGender, -2, -1, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button1, -2, -1, -2))).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addGap(103, 103, 103).addComponent(this.jScrollPane4, -2, 183, -2)).addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(this.jScrollPane3, -2, 285, -2).addGroup(layout.createSequentialGroup().addComponent((Component)this.button13, -2, 39, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button14, -2, 39, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, -1, 32767).addComponent((Component)this.button9, -2, 39, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button5, -2, 39, -2))))));
/*      */     layout.linkSize(1, new Component[] { this.jLabel10, this.txtRatio1 });
/*      */     layout.linkSize(1, new Component[] { (Component)this.button1, this.txtRatio2 });
/*      */     layout.linkSize(1, new Component[] { this.cboGender, this.jLabel11 });
/*      */     pack();
/*      */   }
/*      */   
/*      */   private void findItemOption() {
/*      */     String text = this.txtFindOption.getText();
/*      */     try {
/*      */       int id = Integer.parseInt(text);
/*      */       for (int i = 0; i < Manager.gI().getItemOptionTemplates().size(); i++) {
/*      */         if (((ItemOptionTemplate)Manager.gI().getItemOptionTemplates().get(i)).getId() == id) {
/*      */           this.cboOption.setSelectedIndex(i);
/*      */           break;
/*      */         } 
/*      */       } 
/*      */     } catch (Exception e) {
/*      */       for (int i = 0; i < Manager.gI().getItemOptionTemplates().size(); i++) {
/*      */         try {
/*      */           String name = ((ItemOptionTemplate)Manager.gI().getItemOptionTemplates().get(i)).getName();
/*      */           if (StringUtil.removeAccent(name).toLowerCase().contains(StringUtil.removeAccent(text).toLowerCase())) {
/*      */             this.cboOption.setSelectedIndex(i);
/*      */             break;
/*      */           } 
/*      */         } catch (Exception exception) {}
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private void findItemTemplate() {
/*      */     String text = this.txtFindItemTemplate.getText();
/*      */     try {
/*      */       int id = Integer.parseInt(text);
/*      */       for (int i = 0; i < Manager.gI().getItemTemplates().size(); i++) {
/*      */         if (((ItemTemplate)Manager.gI().getItemTemplates().get(i)).getId() == id) {
/*      */           this.cboItemTemplate.setSelectedIndex(i);
/*      */           break;
/*      */         } 
/*      */       } 
/*      */     } catch (Exception e) {
/*      */       for (int i = 0; i < Manager.gI().getItemTemplates().size(); i++) {
/*      */         try {
/*      */           String name = ((ItemTemplate)Manager.gI().getItemTemplates().get(i)).getName();
/*      */           if (StringUtil.removeAccent(name).toLowerCase().contains(StringUtil.removeAccent(text).toLowerCase())) {
/*      */             this.cboItemTemplate.setSelectedIndex(i);
/*      */             break;
/*      */           } 
/*      */         } catch (Exception exception) {}
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private void cboMobTemplateActionPerformed(ActionEvent evt) {
/*      */     try {
/*      */       BufferedImage image = Util.getImageMobById(this.cboMobTemplate.getSelectedIndex(), 0);
/*      */       if (image.getWidth() > this.lblImageMob.getWidth())
/*      */         image = image.getSubimage((this.lblImageMob.getWidth() - this.lblImageMob.getWidth()) / 2, 0, this.lblImageMob.getWidth(), image.getHeight()); 
/*      */       if (image.getHeight() > this.lblImageMob.getHeight())
/*      */         image = image.getSubimage(0, 0, image.getWidth(), this.lblImageMob.getHeight()); 
/*      */       this.lblImageMob.setIcon(new ImageIcon(image));
/*      */     } catch (Exception exception) {}
/*      */   }
/*      */   
/*      */   private void cboMobTemplateKeyReleased(KeyEvent evt) {
/*      */     if (evt.getKeyCode() == 10) {
/*      */       String text = this.txtMob.getText();
/*      */       if (!text.equals(""))
/*      */         text = text + ";"; 
/*      */       this.txtMob.setText(text + ((MobTemplate)Manager.gI().getMobTemplates().get(this.cboMobTemplate.getSelectedIndex())).getId());
/*      */     } 
/*      */   }
/*      */   
/*      */   private void cboMapActionPerformed(ActionEvent evt) {}
/*      */   
/*      */   private void cboMapKeyReleased(KeyEvent evt) {
/*      */     if (evt.getKeyCode() == 10) {
/*      */       String text = this.txtMap.getText();
/*      */       if (!text.equals(""))
/*      */         text = text + ";"; 
/*      */       this.txtMap.setText(text + ((MapTemplate)Manager.gI().getMapTemplates().get(this.cboMap.getSelectedIndex())).getId());
/*      */     } 
/*      */   }
/*      */   
/*      */   private void cboItemTemplateActionPerformed(ActionEvent evt) {
/*      */     try {
/*      */       BufferedImage image = Util.getImageById(((ItemTemplate)Manager.gI().getItemTemplates().get(this.cboItemTemplate.getSelectedIndex())).getIconId(), 2);
/*      */       this.lblImageItem.setIcon(new ImageIcon(image));
/*      */     } catch (Exception ex) {
/*      */       Logger.getLogger(MobRewardScr.class.getName()).log(Level.SEVERE, (String)null, ex);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void cboItemTemplateKeyReleased(KeyEvent evt) {}
/*      */   
/*      */   private void txtFindItemTemplateKeyPressed(KeyEvent evt) {
/*      */     findItemTemplate();
/*      */   }
/*      */   
/*      */   private void txtFindItemTemplateKeyReleased(KeyEvent evt) {
/*      */     findItemTemplate();
/*      */   }
/*      */   
/*      */   private void txtQuanFKeyPressed(KeyEvent evt) {}
/*      */   
/*      */   private void txtQuanFKeyReleased(KeyEvent evt) {}
/*      */   
/*      */   private void txtQuanTKeyPressed(KeyEvent evt) {}
/*      */   
/*      */   private void txtQuanTKeyReleased(KeyEvent evt) {}
/*      */   
/*      */   private void txtRatio1KeyPressed(KeyEvent evt) {}
/*      */   
/*      */   private void txtRatio1KeyReleased(KeyEvent evt) {}
/*      */   
/*      */   private void txtRatio2KeyPressed(KeyEvent evt) {}
/*      */   
/*      */   private void txtRatio2KeyReleased(KeyEvent evt) {}
/*      */   
/*      */   private void cboGenderActionPerformed(ActionEvent evt) {}
/*      */   
/*      */   private void cboGenderKeyReleased(KeyEvent evt) {}
/*      */   
/*      */   private void button1ActionPerformed(ActionEvent evt) {
/*      */     if (this.txtMob.getText().equals("") || this.txtMap.getText().equals("") || this.txtRatio1.getText().equals("") || this.txtRatio2.getText().equals("")) {
/*      */       NotifyUtil.showMessageDialog((JFrame)Main.I, "Vui lòng nhập đầy đủ thông tin!");
/*      */       return;
/*      */     } 
/*      */     ItemCache itemReward = new ItemCache();
/*      */     itemReward.setTemp(Manager.gI().getItemTemplates().get(this.cboItemTemplate.getSelectedIndex()));
/*      */     itemReward.setGender(this.cboGender.getSelectedIndex() - 1);
/*      */     try {
/*      */       String[] arrMob = this.txtMob.getText().split(";");
/*      */       int[] mobId = new int[arrMob.length];
/*      */       for (int i = 0; i < mobId.length; i++)
/*      */         mobId[i] = Integer.parseInt(arrMob[i]); 
/*      */       itemReward.setMobId(mobId);
/*      */       String[] arrMap = this.txtMap.getText().split(";");
/*      */       int[] mapId = new int[arrMap.length];
/*      */       for (int j = 0; j < mapId.length; j++)
/*      */         mapId[j] = Integer.parseInt(arrMap[j]); 
/*      */       itemReward.setMapId(mapId);
/*      */       int quanF = Integer.parseInt(this.txtQuanF.getText());
/*      */       int quanT = Integer.parseInt(this.txtQuanT.getText());
/*      */       itemReward.setQuantity(new int[] { quanF, quanT });
/*      */       int r1 = Integer.parseInt(this.txtRatio1.getText());
/*      */       int r2 = Integer.parseInt(this.txtRatio2.getText());
/*      */       itemReward.setRatio(new int[] { r1, r2 });
/*      */       this.listItemCache.add(itemReward);
/*      */       fillToTableListItemCache();
/*      */       showInfoItemCache();
/*      */     } catch (Exception e) {
/*      */       e.printStackTrace();
/*      */       NotifyUtil.showMessageDialog((JFrame)Main.I, "Thông tin không hợp lệ!");
/*      */     } 
/*      */   }
/*      */   
/*      */   private void fillToTableListItemCache() {
/*      */     this.modelItemCache.setRowCount(0);
/*      */     for (ItemCache itemCache : this.listItemCache) {
/*      */       this.modelItemCache.addRow(new Object[] { itemCache.getTemp().getName() });
/*      */     } 
/*      */     try {
/*      */       this.tblItemCache.setRowSelectionInterval(this.indexItemCache, this.indexItemCache);
/*      */     } catch (Exception exception) {}
/*      */   }
/*      */   
/*      */   private void txtFindOptionKeyPressed(KeyEvent evt) {
/*      */     findItemOption();
/*      */   }
/*      */   
/*      */   private void txtFindOptionKeyReleased(KeyEvent evt) {
/*      */     findItemOption();
/*      */   }
/*      */   
/*      */   private void button2ActionPerformed(ActionEvent evt) {
/*      */     if (!this.listItemCache.isEmpty())
/*      */       try {
/*      */         String textParam = this.txtParam.getText();
/*      */         String[] arrParam = textParam.split("-");
/*      */         int[] param = new int[2];
/*      */         if (arrParam.length == 2) {
/*      */           param[0] = Integer.parseInt(arrParam[0]);
/*      */           param[1] = Integer.parseInt(arrParam[1]);
/*      */         } else {
/*      */           param[0] = Integer.parseInt(arrParam[0]);
/*      */           param[1] = Integer.parseInt(arrParam[0]);
/*      */         } 
/*      */         int[] ratio = { Integer.parseInt(this.txtR1.getText()), Integer.parseInt(this.txtR2.getText()) };
/*      */         for (ItemCache itemCache : this.listItemCache)
/*      */           itemCache.getOptions().add(new ItemOptionReward(((ItemOptionTemplate)Manager.gI().getItemOptionTemplates().get(this.cboOption.getSelectedIndex())).getId(), param, ratio)); 
/*      */         showInfoItemCache();
/*      */       } catch (Exception e) {
/*      */         NotifyUtil.showMessageDialog((JFrame)Main.I, "Vui lòng nhập thông tin hợp lệ!");
/*      */       }  
/*      */   }
/*      */   
/*      */   private void txtParamKeyPressed(KeyEvent evt) {}
/*      */   
/*      */   private void txtParamKeyReleased(KeyEvent evt) {}
/*      */   
/*      */   private void tblListMouseClicked(MouseEvent evt) {
/*      */     this.index = this.tblList.getSelectedRow();
/*      */     showInfoItem2();
/*      */   }
/*      */   
/*      */   private void showInfoItem2() {
/*      */     if (this.index != -1) {
/*      */       if (this.itemMobReward == null)
/*      */         this.itemMobReward = new ModifyItemMobReward(this); 
/*      */       ItemReward i = this.list.get(this.index);
/*      */       String info = i.getTemp().getName() + "\n-------Option-------\n";
/*      */       for (ItemOptionReward io : i.getOptions())
/*      */         info = info + io.getTemp().getName().replaceAll("#", "(" + io.getParam()[0] + " - " + io.getParam()[1] + ")") + "         [" + io.getParam()[0] + "/ " + io.getParam()[1] + "][" + io.getRatio()[0] + " - " + io.getRatio()[1] + "]\n"; 
/*      */       this.txtInfoItem2.setText(info);
/*      */       try {
/*      */         this.itemMobReward.show(i);
/*      */       } catch (Exception exception) {}
/*      */     } 
/*      */   }
/*      */   
/*      */   private void button4ActionPerformed(ActionEvent evt) {
/*      */     if (!this.listItemCache.isEmpty()) {
/*      */       for (ItemCache itemCache : this.listItemCache) {
/*      */         for (int mobId : itemCache.getMobId()) {
/*      */           ItemReward item = new ItemReward();
/*      */           item.setTemp(itemCache.getTemp());
/*      */           item.setGender(itemCache.getGender());
/*      */           item.setMapId(itemCache.getMapId());
/*      */           item.setMobId(mobId);
/*      */           item.setRatio(itemCache.getRatio());
/*      */           item.setQuantity(itemCache.getQuantity());
/*      */           item.setOptions(itemCache.getOptions());
/*      */           this.list.add(item);
/*      */         } 
/*      */       } 
/*      */       fillToTable();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void fillToTable() {
/*      */     this.index = -1;
/*      */     this.model.setRowCount(0);
/*      */     for (ItemReward item : this.list) {
/*      */       this.model.addRow(new Object[] { (item.getMobId() != -1) ? ((MobTemplate)Manager.gI().getMobTemplates().get(item.getMobId())).getName() : "All mob", item.getTemp().getName(), item.getQuantity()[0] + " - " + item.getQuantity()[1], item.getRatio()[0] + "/ " + item.getRatio()[1], (item.getGender() == -1) ? "All" : ((item.getGender() == 0) ? "Trái đất" : ((item.getGender() == 1) ? "Namếc" : "Xayda")), Arrays.toString(item.getMapId()) });
/*      */     } 
/*      */   }
/*      */   
/*      */   private void txtMobKeyReleased(KeyEvent evt) {
/*      */     String text = this.txtMob.getText().trim();
/*      */     if (text.equals("-1")) {
/*      */       String newText = "";
/*      */       for (MobTemplate mob : Manager.gI().getMobTemplates())
/*      */         newText = newText + mob.getId() + ";"; 
/*      */       newText = newText.substring(0, newText.length() - 1);
/*      */       this.txtMob.setText(newText);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void txtMapKeyReleased(KeyEvent evt) {}
/*      */   
/*      */   private void button5ActionPerformed(ActionEvent evt) {
/*      */     int[] selects = this.tblList.getSelectedRows();
/*      */     System.out.println(Arrays.toString(selects));
/*      */     for (int i = selects.length - 1; i >= 0; i--)
/*      */       this.list.remove(selects[i]); 
/*      */     fillToTable();
/*      */     try {
/*      */       this.itemMobReward.show((ItemReward)null);
/*      */     } catch (Exception exception) {}
/*      */   }
/*      */   
/*      */   private void button6ActionPerformed(ActionEvent evt) {
/*      */     if (this.indexOption != -1 && !this.listItemCache.isEmpty()) {
/*      */       for (ItemCache itemCache : this.listItemCache)
/*      */         itemCache.getOptions().remove(this.indexOption); 
/*      */       showInfoItemCache();
/*      */     } 
/*      */   }
/*      */   
/*      */   private void tblOptionMouseClicked(MouseEvent evt) {
/*      */     this.indexOption = this.tblOption.getSelectedRow();
/*      */   }
/*      */   
/*      */   private void tblOptionMousePressed(MouseEvent evt) {
/*      */     this.indexOption = this.tblOption.getSelectedRow();
/*      */   }
/*      */   
/*      */   private void tblOptionMouseReleased(MouseEvent evt) {
/*      */     this.indexOption = this.tblOption.getSelectedRow();
/*      */   }
/*      */   
/*      */   private void button7ActionPerformed(ActionEvent evt) {
/*      */     JFileChooser fileChooser = new JFileChooser("C:\\Users\\admin\\Desktop\\cbro\\data\\girlkun\\mob_reward");
/*      */     if (fileChooser.showSaveDialog((Component)Main.I) == 0)
/*      */       try {
/*      */         DataOutputStream dos = new DataOutputStream(new FileOutputStream(fileChooser.getSelectedFile()));
/*      */         dos.writeInt(this.list.size());
/*      */         for (ItemReward item : this.list) {
/*      */           dos.writeInt(item.getMobId());
/*      */           dos.writeInt(item.getTemp().getId());
/*      */           dos.writeUTF(item.getQuantity()[0] + "-" + item.getQuantity()[1]);
/*      */           dos.writeUTF(item.getRatio()[0] + "-" + item.getRatio()[1]);
/*      */           dos.writeInt(item.getGender());
/*      */           dos.writeUTF(Arrays.toString(item.getMapId()));
/*      */           dos.writeInt(item.getOptions().size());
/*      */           for (ItemOptionReward io : item.getOptions()) {
/*      */             dos.writeInt(io.getTemp().getId());
/*      */             dos.writeUTF(io.getParam()[0] + "-" + io.getParam()[1]);
/*      */             dos.writeUTF(io.getRatio()[0] + "-" + io.getRatio()[1]);
/*      */           } 
/*      */         } 
/*      */         dos.flush();
/*      */         dos.close();
/*      */         NotifyUtil.showMessageDialog((JFrame)Main.I, "Save thành công!");
/*      */       } catch (Exception exception) {} 
/*      */   }
/*      */   
/*      */   private void txtR1KeyPressed(KeyEvent evt) {}
/*      */   
/*      */   private void txtR1KeyReleased(KeyEvent evt) {}
/*      */   
/*      */   private void txtR2KeyPressed(KeyEvent evt) {}
/*      */   
/*      */   private void txtR2KeyReleased(KeyEvent evt) {}
/*      */   
/*      */   private void button8ActionPerformed(ActionEvent evt) {
/*      */     JFileChooser fileChooser = new JFileChooser();
/*      */     if (fileChooser.showOpenDialog((Component)Main.I) == 0)
/*      */       readFileSave(fileChooser.getSelectedFile()); 
/*      */   }
/*      */   
/*      */   private void readFileSave(File file) {
/*      */     try {
/*      */       DataInputStream dis = new DataInputStream(new FileInputStream(file));
/*      */       int size = dis.readInt();
/*      */       for (int i = 0; i < size; i++) {
/*      */         int mobId = dis.readInt();
/*      */         int itemId = dis.readInt();
/*      */         String[] quantity = dis.readUTF().split("-");
/*      */         String[] ratio = dis.readUTF().split("-");
/*      */         int gender = dis.readInt();
/*      */         String map = dis.readUTF();
/*      */         String[] arrMap = map.replaceAll("[\\]\\[]", "").split(",");
/*      */         int[] mapDrop = new int[arrMap.length];
/*      */         for (int g = 0; g < mapDrop.length; g++)
/*      */           mapDrop[g] = Integer.parseInt(arrMap[g].trim()); 
/*      */         ItemReward item = new ItemReward();
/*      */         item.setGender(gender);
/*      */         item.setMapId(mapDrop);
/*      */         item.setMobId(mobId);
/*      */         item.setQuantity(new int[] { Integer.parseInt(quantity[0]), Integer.parseInt(quantity[1]) });
/*      */         item.setRatio(new int[] { Integer.parseInt(ratio[0]), Integer.parseInt(ratio[1]) });
/*      */         item.setTemp(Manager.gI().getItemTemplates().get(itemId));
/*      */         int sizeOption = dis.readInt();
/*      */         for (int j = 0; j < sizeOption; j++) {
/*      */           int optionId = dis.readInt();
/*      */           String[] param = dis.readUTF().split("-");
/*      */           String[] ratioOption = dis.readUTF().split("-");
/*      */           ItemOptionReward io = new ItemOptionReward(optionId, new int[] { Integer.parseInt(param[0]), Integer.parseInt(param[1]) }, new int[] { Integer.parseInt(ratioOption[0]), Integer.parseInt(ratioOption[1]) });
/*      */           item.getOptions().add(io);
/*      */         } 
/*      */         this.list.add(item);
/*      */       } 
/*      */       fillToTable();
/*      */     } catch (Exception e) {
/*      */       e.printStackTrace();
/*      */     } 
/*      */   }
/*      */   
/*      */   private void button9ActionPerformed(ActionEvent evt) {
/*      */     if (NotifyUtil.showConfirmDialog((JFrame)Main.I, "Bạn có chắc chắn muốn xóa tất cả?") == 0) {
/*      */       this.list.clear();
/*      */       fillToTable();
/*      */       if (this.itemMobReward != null && this.itemMobReward.isVisible())
/*      */         try {
/*      */           this.itemMobReward.show((ItemReward)null);
/*      */         } catch (Exception ex) {
/*      */           Logger.getLogger(MobRewardScr.class.getName()).log(Level.SEVERE, (String)null, ex);
/*      */         }  
/*      */     } 
/*      */   }
/*      */   
/*      */   private void tblListKeyPressed(KeyEvent evt) {
/*      */     this.index = this.tblList.getSelectedRow();
/*      */     showInfoItem2();
/*      */   }
/*      */   
/*      */   private void tblListKeyReleased(KeyEvent evt) {
/*      */     this.index = this.tblList.getSelectedRow();
/*      */     showInfoItem2();
/*      */   }
/*      */   
/*      */   private void button10ActionPerformed(ActionEvent evt) {
/*      */     if (this.indexItemCache != -1) {
/*      */       this.listItemCache.remove(this.indexItemCache);
/*      */       fillToTableListItemCache();
/*      */       this.indexItemCache = -1;
/*      */     } 
/*      */   }
/*      */   
/*      */   private void tblItemCacheMouseClicked(MouseEvent evt) {
/*      */     this.indexItemCache = this.tblItemCache.getSelectedRow();
/*      */     showInfoItemCache();
/*      */   }
/*      */   
/*      */   private void tblItemCacheKeyPressed(KeyEvent evt) {
/*      */     this.indexItemCache = this.tblItemCache.getSelectedRow();
/*      */     showInfoItemCache();
/*      */   }
/*      */   
/*      */   private void tblItemCacheKeyReleased(KeyEvent evt) {
/*      */     this.indexItemCache = this.tblItemCache.getSelectedRow();
/*      */     showInfoItemCache();
/*      */   }
/*      */   
/*      */   private void button11ActionPerformed(ActionEvent evt) {
/*      */     if (NotifyUtil.showConfirmDialog((JFrame)Main.I, "Bạn có chắc chắn muốn xóa tất cả?") == 0) {
/*      */       this.listItemCache.clear();
/*      */       fillToTableListItemCache();
/*      */     } 
/*      */   }
/*      */   
/*      */   private void button13ActionPerformed(ActionEvent evt) {
/*      */     if (this.modifyAll == null)
/*      */       this.modifyAll = new ModifyAll(this, this.list); 
/*      */     this.modifyAll.setVisible(true);
/*      */   }
/*      */   
/*      */   private void button14ActionPerformed(ActionEvent evt) {
/*      */     if (this.addAllOptionScr == null)
/*      */       this.addAllOptionScr = new AddAllOptionScr(this, this.list); 
/*      */     this.addAllOptionScr.setVisible(true);
/*      */   }
/*      */   
/*      */   private void setup() {
/*      */     setTitle("Girlkun - Mob reward");
/*      */     setResizable(false);
/*      */     for (MobTemplate mob : Manager.gI().getMobTemplates())
/*      */       this.cboMobTemplate.addItem(mob.getId() + " - " + mob.getName()); 
/*      */     for (MapTemplate map : Manager.gI().getMapTemplates())
/*      */       this.cboMap.addItem(map.getId() + " - " + map.getName()); 
/*      */     for (ItemTemplate item : Manager.gI().getItemTemplates())
/*      */       this.cboItemTemplate.addItem(item.getId() + " - " + item.getName()); 
/*      */     for (ItemOptionTemplate io : Manager.gI().getItemOptionTemplates())
/*      */       this.cboOption.addItem(io.getId() + " - " + io.getName()); 
/*      */     try {
/*      */       this.lblImageMob.setIcon(new ImageIcon(Util.getImageMobById(0, 0)));
/*      */     } catch (Exception exception) {}
/*      */     Dimension d = new Dimension(161, 39);
/*      */     this.txtMob.setMaximumSize(d);
/*      */     this.txtMap.setMaximumSize(d);
/*      */     this.modelOption = new DefaultTableModel((Object[])new String[] { "Option", "Ratio" }, 0) {
/*      */         public boolean isCellEditable(int row, int column) {
/*      */           return false;
/*      */         }
/*      */       };
/*      */     this.tblOption.setModel(this.modelOption);
/*      */     this.model = new DefaultTableModel((Object[])new String[] { "Mob", "Item", "Quantity", "Ratio", "Gender", "Map" }, 0) {
/*      */         public boolean isCellEditable(int row, int column) {
/*      */           return false;
/*      */         }
/*      */       };
/*      */     this.tblList.setModel(this.model);
/*      */     this.modelItemCache = new DefaultTableModel((Object[])new String[] { "Item cache" }, 0) {
/*      */         public boolean isCellEditable(int row, int column) {
/*      */           return false;
/*      */         }
/*      */       };
/*      */     this.tblItemCache.setModel(this.modelItemCache);
/*      */   }
/*      */   
/*      */   private void showInfoItemCache() {
/*      */     this.modelOption.setRowCount(0);
/*      */     this.indexOption = -1;
/*      */     if (this.listItemCache.isEmpty())
/*      */       return; 
/*      */     if (this.indexItemCache == -1) {
/*      */       this.indexItemCache = 0;
/*      */       this.tblItemCache.setRowSelectionInterval(this.indexItemCache, this.indexItemCache);
/*      */     } 
/*      */     ItemCache itemCache = this.listItemCache.get(this.indexItemCache);
/*      */     if (itemCache != null) {
/*      */       try {
/*      */         this.lblItemCache.setIcon(new ImageIcon(Util.getImageById(itemCache.getTemp().getIconId(), 2)));
/*      */       } catch (Exception exception) {}
/*      */       String info = itemCache.getTemp().getId() + " - " + itemCache.getTemp().getName() + "\n";
/*      */       String mob = "Mob: ";
/*      */       for (int i : itemCache.getMobId())
/*      */         mob = mob + i + ";"; 
/*      */       info = info + mob + "\n";
/*      */       String map = "Map: ";
/*      */       for (int i : itemCache.getMapId())
/*      */         map = map + i + ";"; 
/*      */       info = info + map + "\n";
/*      */       String quantity = "Quantity: " + itemCache.getQuantity()[0] + " - " + itemCache.getQuantity()[1];
/*      */       info = info + quantity + "\n";
/*      */       info = info + "Ratio: " + itemCache.getRatio()[0] + "/ " + itemCache.getRatio()[1] + "\n";
/*      */       info = info + "Gender: " + ((itemCache.getGender() == -1) ? "All" : ((itemCache.getGender() == 0) ? "Trái đất" : ((itemCache.getGender() == 1) ? "Namếc" : "Xayda"))) + "\n";
/*      */       info = info + "-------------Option-------------\n";
/*      */       for (ItemOptionReward io : itemCache.getOptions()) {
/*      */         info = info + io.getTemp().getName().replaceAll("#", "(" + io.getParam()[0] + " - " + io.getParam()[1] + ")") + " [" + io.getRatio()[0] + "/ " + io.getRatio()[1] + "]\n";
/*      */         this.modelOption.addRow(new Object[] { io.getTemp().getName().replaceAll("#", "(" + io.getParam()[0] + " - " + io.getParam()[1] + ")"), io.getRatio()[0] + "/ " + io.getRatio()[1] });
/*      */       } 
/*      */       this.txtInfoItemCache.setText(info);
/*      */     } 
/*      */   }
/*      */ }


/* Location:              D:\nro\server_luxu_nrp\vemap\GirlkunToolCBRO.jar!\com\girlkun\tool\screens\mob_reward_scr\MobRewardScr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */