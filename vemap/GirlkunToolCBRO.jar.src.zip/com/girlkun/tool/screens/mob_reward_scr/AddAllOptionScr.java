/*     */ package com.girlkun.tool.screens.mob_reward_scr;
/*     */ import com.girlkun.button.Button;
/*     */ import com.girlkun.tool.screens.mob_reward_scr.models.ItemOptionReward;
/*     */ import com.girlkun.tool.screens.mob_reward_scr.models.ItemReward;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Font;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.KeyEvent;
/*     */ import javax.swing.GroupLayout;
/*     */ import javax.swing.LayoutStyle;
/*     */ 
/*     */ public class AddAllOptionScr extends JFrame {
/*     */   private MobRewardScr mobRewardScr;
/*     */   private List<ItemReward> list;
/*     */   private Button button10;
/*     */   private Button button11;
/*     */   private Button button12;
/*     */   private Button button2;
/*     */   
/*     */   public AddAllOptionScr(MobRewardScr mobRewardScr, List<ItemReward> list) {
/*  23 */     initComponents();
/*  24 */     setup();
/*  25 */     this.mobRewardScr = mobRewardScr;
/*  26 */     this.list = list;
/*  27 */     setAlwaysOnTop(true);
/*  28 */     setDefaultCloseOperation(2);
/*     */   }
/*     */   private Button button3; private Button button4; private Button button5; private Button button6; private Button button7; private Button button8; private Button button9; private JComboBox<String> cboOption; private JComboBox<String> cboOptionRemove; private JLabel jLabel13; private JLabel jLabel14; private JLabel jLabel15; private JLabel jLabel16; private JLabel jLabel17; private JPanel jPanel1; private JTextField txtFindOption; private JTextField txtParam;
/*     */   private JTextField txtR1;
/*     */   private JTextField txtR2;
/*     */   
/*     */   private void initComponents() {
/*  35 */     this.jPanel1 = new JPanel();
/*  36 */     this.button6 = new Button();
/*  37 */     this.button2 = new Button();
/*  38 */     this.txtParam = new JTextField();
/*  39 */     this.cboOption = new JComboBox<>();
/*  40 */     this.txtFindOption = new JTextField();
/*  41 */     this.jLabel13 = new JLabel();
/*  42 */     this.jLabel14 = new JLabel();
/*  43 */     this.jLabel15 = new JLabel();
/*  44 */     this.txtR1 = new JTextField();
/*  45 */     this.jLabel16 = new JLabel();
/*  46 */     this.txtR2 = new JTextField();
/*  47 */     this.cboOptionRemove = new JComboBox<>();
/*  48 */     this.jLabel17 = new JLabel();
/*  49 */     this.button3 = new Button();
/*  50 */     this.button4 = new Button();
/*  51 */     this.button5 = new Button();
/*  52 */     this.button7 = new Button();
/*  53 */     this.button8 = new Button();
/*  54 */     this.button9 = new Button();
/*  55 */     this.button10 = new Button();
/*  56 */     this.button11 = new Button();
/*  57 */     this.button12 = new Button();
/*     */     
/*  59 */     setDefaultCloseOperation(3);
/*     */     
/*  61 */     this.button6.setBackground(new Color(204, 0, 0));
/*  62 */     this.button6.setForeground(new Color(255, 255, 255));
/*  63 */     this.button6.setText("Remove option");
/*  64 */     this.button6.setFont(new Font("SansSerif", 1, 12));
/*  65 */     this.button6.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/*  67 */             AddAllOptionScr.this.button6ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     
/*  71 */     this.button2.setBackground(new Color(153, 0, 153));
/*  72 */     this.button2.setForeground(new Color(255, 255, 255));
/*  73 */     this.button2.setText("Add option");
/*  74 */     this.button2.setFont(new Font("SansSerif", 1, 12));
/*  75 */     this.button2.setMaximumSize(new Dimension(152, 39));
/*  76 */     this.button2.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/*  78 */             AddAllOptionScr.this.button2ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     
/*  82 */     this.txtParam.setFont(new Font("SansSerif", 1, 12));
/*  83 */     this.txtParam.setText("Eg: 752002 or 75-2002");
/*  84 */     this.txtParam.setMaximumSize(new Dimension(152, 39));
/*  85 */     this.txtParam.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/*  87 */             AddAllOptionScr.this.txtParamKeyPressed(evt);
/*     */           }
/*     */           public void keyReleased(KeyEvent evt) {
/*  90 */             AddAllOptionScr.this.txtParamKeyReleased(evt);
/*     */           }
/*     */         });
/*     */     
/*  94 */     this.cboOption.setBackground(new Color(255, 204, 255));
/*  95 */     this.cboOption.setFont(new Font("SansSerif", 1, 12));
/*  96 */     this.cboOption.setForeground(new Color(51, 0, 51));
/*  97 */     this.cboOption.setMaximumSize(new Dimension(152, 39));
/*     */     
/*  99 */     this.txtFindOption.setBackground(new Color(255, 204, 255));
/* 100 */     this.txtFindOption.setFont(new Font("SansSerif", 1, 12));
/* 101 */     this.txtFindOption.setForeground(new Color(51, 0, 51));
/* 102 */     this.txtFindOption.setMaximumSize(new Dimension(152, 39));
/* 103 */     this.txtFindOption.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/* 105 */             AddAllOptionScr.this.txtFindOptionKeyPressed(evt);
/*     */           }
/*     */           public void keyReleased(KeyEvent evt) {
/* 108 */             AddAllOptionScr.this.txtFindOptionKeyReleased(evt);
/*     */           }
/*     */         });
/*     */     
/* 112 */     this.jLabel13.setFont(new Font("SansSerif", 1, 12));
/* 113 */     this.jLabel13.setText("Search option");
/*     */     
/* 115 */     this.jLabel14.setFont(new Font("SansSerif", 1, 12));
/* 116 */     this.jLabel14.setText("Option template");
/*     */     
/* 118 */     this.jLabel15.setFont(new Font("SansSerif", 1, 12));
/* 119 */     this.jLabel15.setText("Param");
/*     */     
/* 121 */     this.txtR1.setFont(new Font("SansSerif", 1, 12));
/* 122 */     this.txtR1.setText("100");
/* 123 */     this.txtR1.setMaximumSize(new Dimension(152, 39));
/* 124 */     this.txtR1.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/* 126 */             AddAllOptionScr.this.txtR1KeyPressed(evt);
/*     */           }
/*     */           public void keyReleased(KeyEvent evt) {
/* 129 */             AddAllOptionScr.this.txtR1KeyReleased(evt);
/*     */           }
/*     */         });
/*     */     
/* 133 */     this.jLabel16.setFont(new Font("SansSerif", 1, 12));
/* 134 */     this.jLabel16.setText("Ratio");
/*     */     
/* 136 */     this.txtR2.setFont(new Font("SansSerif", 1, 12));
/* 137 */     this.txtR2.setText("100");
/* 138 */     this.txtR2.setMaximumSize(new Dimension(152, 39));
/* 139 */     this.txtR2.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/* 141 */             AddAllOptionScr.this.txtR2KeyPressed(evt);
/*     */           }
/*     */           public void keyReleased(KeyEvent evt) {
/* 144 */             AddAllOptionScr.this.txtR2KeyReleased(evt);
/*     */           }
/*     */         });
/*     */     
/* 148 */     this.cboOptionRemove.setBackground(new Color(255, 204, 255));
/* 149 */     this.cboOptionRemove.setFont(new Font("SansSerif", 1, 12));
/* 150 */     this.cboOptionRemove.setForeground(new Color(51, 0, 51));
/* 151 */     this.cboOptionRemove.setMaximumSize(new Dimension(152, 39));
/*     */     
/* 153 */     this.jLabel17.setFont(new Font("SansSerif", 1, 12));
/* 154 */     this.jLabel17.setText("Option template");
/*     */     
/* 156 */     this.button3.setBackground(new Color(255, 51, 255));
/* 157 */     this.button3.setForeground(new Color(255, 255, 255));
/* 158 */     this.button3.setText("Set songoku");
/* 159 */     this.button3.setFont(new Font("SansSerif", 1, 12));
/* 160 */     this.button3.setMaximumSize(new Dimension(152, 39));
/* 161 */     this.button3.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/* 163 */             AddAllOptionScr.this.button3ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     
/* 167 */     this.button4.setBackground(new Color(255, 51, 255));
/* 168 */     this.button4.setForeground(new Color(255, 255, 255));
/* 169 */     this.button4.setText("Set txh");
/* 170 */     this.button4.setFont(new Font("SansSerif", 1, 12));
/* 171 */     this.button4.setMaximumSize(new Dimension(152, 39));
/* 172 */     this.button4.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/* 174 */             AddAllOptionScr.this.button4ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     
/* 178 */     this.button5.setBackground(new Color(255, 51, 255));
/* 179 */     this.button5.setForeground(new Color(255, 255, 255));
/* 180 */     this.button5.setText("Set krilin");
/* 181 */     this.button5.setFont(new Font("SansSerif", 1, 12));
/* 182 */     this.button5.setMaximumSize(new Dimension(152, 39));
/* 183 */     this.button5.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/* 185 */             AddAllOptionScr.this.button5ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     
/* 189 */     this.button7.setBackground(new Color(255, 51, 255));
/* 190 */     this.button7.setForeground(new Color(255, 255, 255));
/* 191 */     this.button7.setText("Set pocolo");
/* 192 */     this.button7.setFont(new Font("SansSerif", 1, 12));
/* 193 */     this.button7.setMaximumSize(new Dimension(152, 39));
/* 194 */     this.button7.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/* 196 */             AddAllOptionScr.this.button7ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     
/* 200 */     this.button8.setBackground(new Color(255, 51, 255));
/* 201 */     this.button8.setForeground(new Color(255, 255, 255));
/* 202 */     this.button8.setText("Set pikoro");
/* 203 */     this.button8.setFont(new Font("SansSerif", 1, 12));
/* 204 */     this.button8.setMaximumSize(new Dimension(152, 39));
/* 205 */     this.button8.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/* 207 */             AddAllOptionScr.this.button8ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     
/* 211 */     this.button9.setBackground(new Color(255, 51, 255));
/* 212 */     this.button9.setForeground(new Color(255, 255, 255));
/* 213 */     this.button9.setText("Set ốc tiêu");
/* 214 */     this.button9.setFont(new Font("SansSerif", 1, 12));
/* 215 */     this.button9.setMaximumSize(new Dimension(152, 39));
/* 216 */     this.button9.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/* 218 */             AddAllOptionScr.this.button9ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     
/* 222 */     this.button10.setBackground(new Color(255, 51, 255));
/* 223 */     this.button10.setForeground(new Color(255, 255, 255));
/* 224 */     this.button10.setText("Set nappa");
/* 225 */     this.button10.setFont(new Font("SansSerif", 1, 12));
/* 226 */     this.button10.setMaximumSize(new Dimension(152, 39));
/* 227 */     this.button10.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/* 229 */             AddAllOptionScr.this.button10ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     
/* 233 */     this.button11.setBackground(new Color(255, 51, 255));
/* 234 */     this.button11.setForeground(new Color(255, 255, 255));
/* 235 */     this.button11.setText("Set kakarot");
/* 236 */     this.button11.setFont(new Font("SansSerif", 1, 12));
/* 237 */     this.button11.setMaximumSize(new Dimension(152, 39));
/* 238 */     this.button11.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/* 240 */             AddAllOptionScr.this.button11ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     
/* 244 */     this.button12.setBackground(new Color(255, 51, 255));
/* 245 */     this.button12.setForeground(new Color(255, 255, 255));
/* 246 */     this.button12.setText("Set cadic");
/* 247 */     this.button12.setFont(new Font("SansSerif", 1, 12));
/* 248 */     this.button12.setMaximumSize(new Dimension(152, 39));
/* 249 */     this.button12.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/* 251 */             AddAllOptionScr.this.button12ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     
/* 255 */     GroupLayout jPanel1Layout = new GroupLayout(this.jPanel1);
/* 256 */     this.jPanel1.setLayout(jPanel1Layout);
/* 257 */     jPanel1Layout.setHorizontalGroup(jPanel1Layout
/* 258 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 259 */         .addGroup(jPanel1Layout.createSequentialGroup()
/* 260 */           .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 261 */             .addComponent(this.jLabel13, -2, 100, -2)
/* 262 */             .addComponent(this.jLabel14)
/* 263 */             .addComponent(this.jLabel15, -2, 90, -2)
/* 264 */             .addComponent(this.jLabel16, -2, 90, -2))
/* 265 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 266 */           .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 267 */             .addGroup(jPanel1Layout.createSequentialGroup()
/* 268 */               .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 269 */                 .addComponent(this.txtParam, -2, 170, -2)
/* 270 */                 .addGroup(jPanel1Layout.createSequentialGroup()
/* 271 */                   .addComponent((Component)this.button2, -2, 170, -2)
/* 272 */                   .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 273 */                   .addComponent((Component)this.button9, -1, -1, 32767)
/* 274 */                   .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 275 */                   .addComponent((Component)this.button8, -2, 91, -2)
/* 276 */                   .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 277 */                   .addComponent((Component)this.button7, -2, 91, -2))
/* 278 */                 .addGroup(jPanel1Layout.createSequentialGroup()
/* 279 */                   .addGap(176, 176, 176)
/* 280 */                   .addComponent((Component)this.button10, -1, -1, 32767)
/* 281 */                   .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 282 */                   .addComponent((Component)this.button11, -2, 91, -2)
/* 283 */                   .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 284 */                   .addComponent((Component)this.button12, -2, 91, -2)))
/* 285 */               .addGap(104, 104, 104))
/* 286 */             .addGroup(jPanel1Layout.createSequentialGroup()
/* 287 */               .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false)
/* 288 */                 .addComponent(this.cboOption, GroupLayout.Alignment.LEADING, 0, 171, 32767)
/* 289 */                 .addGroup(GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
/* 290 */                   .addComponent(this.txtR1, -2, 82, -2)
/* 291 */                   .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 292 */                   .addComponent(this.txtR2, -2, 82, -2))
/* 293 */                 .addComponent(this.txtFindOption, GroupLayout.Alignment.LEADING, -1, -1, 32767))
/* 294 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 295 */               .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 296 */                 .addComponent(this.jLabel17, -1, -1, 32767)
/* 297 */                 .addComponent((Component)this.button3, -1, -1, 32767))
/* 298 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 299 */               .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 300 */                 .addGroup(jPanel1Layout.createSequentialGroup()
/* 301 */                   .addComponent(this.cboOptionRemove, 0, 180, 32767)
/* 302 */                   .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 303 */                   .addComponent((Component)this.button6, -2, 105, -2))
/* 304 */                 .addGroup(jPanel1Layout.createSequentialGroup()
/* 305 */                   .addComponent((Component)this.button4, -2, 91, -2)
/* 306 */                   .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 307 */                   .addComponent((Component)this.button5, -2, 91, -2)
/* 308 */                   .addGap(0, 0, 32767)))))));
/*     */ 
/*     */     
/* 311 */     jPanel1Layout.linkSize(0, new Component[] { (Component)this.button3, (Component)this.button4, (Component)this.button5 });
/*     */     
/* 313 */     jPanel1Layout.setVerticalGroup(jPanel1Layout
/* 314 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 315 */         .addGroup(jPanel1Layout.createSequentialGroup()
/* 316 */           .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 317 */             .addGroup(jPanel1Layout.createSequentialGroup()
/* 318 */               .addComponent(this.jLabel13, -2, 39, -2)
/* 319 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 320 */               .addComponent(this.jLabel14, -2, 39, -2)
/* 321 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 322 */               .addComponent(this.jLabel15, -2, 39, -2)
/* 323 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 324 */               .addComponent(this.jLabel16, -2, 39, -2))
/* 325 */             .addGroup(jPanel1Layout.createSequentialGroup()
/* 326 */               .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 327 */                 .addComponent(this.txtFindOption, -2, 39, -2)
/* 328 */                 .addComponent(this.jLabel17, -2, 39, -2)
/* 329 */                 .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 330 */                   .addComponent(this.cboOptionRemove, -2, 39, -2)
/* 331 */                   .addComponent((Component)this.button6, -2, 39, -2)))
/* 332 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 333 */               .addComponent(this.cboOption, -2, 39, -2)
/* 334 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 335 */               .addComponent(this.txtParam, -2, 39, -2)
/* 336 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 337 */               .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 338 */                 .addComponent(this.txtR1, -2, 39, -2)
/* 339 */                 .addComponent(this.txtR2, -2, 39, -2)
/* 340 */                 .addComponent((Component)this.button3, -2, 39, -2)
/* 341 */                 .addComponent((Component)this.button4, -2, 39, -2)
/* 342 */                 .addComponent((Component)this.button5, -2, 39, -2))))
/* 343 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 344 */           .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 345 */             .addComponent((Component)this.button2, -2, 39, -2)
/* 346 */             .addComponent((Component)this.button9, -2, 39, -2)
/* 347 */             .addComponent((Component)this.button8, -2, 39, -2)
/* 348 */             .addComponent((Component)this.button7, -2, 39, -2))
/* 349 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 350 */           .addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 351 */             .addComponent((Component)this.button10, -2, 39, -2)
/* 352 */             .addComponent((Component)this.button11, -2, 39, -2)
/* 353 */             .addComponent((Component)this.button12, -2, 39, -2))
/* 354 */           .addContainerGap(-1, 32767)));
/*     */ 
/*     */     
/* 357 */     GroupLayout layout = new GroupLayout(getContentPane());
/* 358 */     getContentPane().setLayout(layout);
/* 359 */     layout.setHorizontalGroup(layout
/* 360 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 361 */         .addGroup(layout.createSequentialGroup()
/* 362 */           .addComponent(this.jPanel1, -2, -1, -2)
/* 363 */           .addGap(0, 0, 0)));
/*     */     
/* 365 */     layout.setVerticalGroup(layout
/* 366 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 367 */         .addComponent(this.jPanel1, -2, -1, -2));
/*     */ 
/*     */     
/* 370 */     pack();
/*     */   }
/*     */   
/*     */   private void button2ActionPerformed(ActionEvent evt) {
/* 374 */     if (!this.list.isEmpty()) {
/*     */       try {
/* 376 */         String textParam = this.txtParam.getText();
/* 377 */         String[] arrParam = textParam.split("-");
/* 378 */         int[] param = new int[2];
/* 379 */         if (arrParam.length == 2) {
/* 380 */           param[0] = Integer.parseInt(arrParam[0]);
/* 381 */           param[1] = Integer.parseInt(arrParam[1]);
/*     */         } else {
/* 383 */           param[0] = Integer.parseInt(arrParam[0]);
/* 384 */           param[1] = Integer.parseInt(arrParam[0]);
/*     */         } 
/* 386 */         int[] ratio = { Integer.parseInt(this.txtR1.getText()), Integer.parseInt(this.txtR2.getText()) };
/* 387 */         for (ItemReward i : this.list) {
/* 388 */           i.getOptions().add(new ItemOptionReward(((ItemOptionTemplate)Manager.gI().getItemOptionTemplates().get(this.cboOption.getSelectedIndex())).getId(), param, ratio));
/*     */         }
/*     */       }
/* 391 */       catch (Exception e) {
/* 392 */         NotifyUtil.showMessageDialog(this, "Vui lòng nhập thông tin hợp lệ!");
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void txtParamKeyPressed(KeyEvent evt) {}
/*     */ 
/*     */   
/*     */   private void txtParamKeyReleased(KeyEvent evt) {}
/*     */ 
/*     */   
/*     */   private void txtFindOptionKeyPressed(KeyEvent evt) {
/* 406 */     findItemOption();
/*     */   }
/*     */   
/*     */   private void txtFindOptionKeyReleased(KeyEvent evt) {
/* 410 */     findItemOption();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void txtR1KeyPressed(KeyEvent evt) {}
/*     */ 
/*     */ 
/*     */   
/*     */   private void txtR1KeyReleased(KeyEvent evt) {}
/*     */ 
/*     */ 
/*     */   
/*     */   private void txtR2KeyPressed(KeyEvent evt) {}
/*     */ 
/*     */ 
/*     */   
/*     */   private void txtR2KeyReleased(KeyEvent evt) {}
/*     */ 
/*     */   
/*     */   private void button6ActionPerformed(ActionEvent evt) {
/* 431 */     for (ItemReward ir : this.list) {
/* 432 */       for (ItemOptionReward ior : ir.getOptions()) {
/* 433 */         if (ior.getTemp().getId() == this.cboOptionRemove.getSelectedIndex()) {
/* 434 */           ir.getOptions().remove(ior);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void button3ActionPerformed(ActionEvent evt) {
/* 441 */     for (ItemReward ir : this.list) {
/* 442 */       ir.getOptions().add(new ItemOptionReward(129, new int[] { 1, 1 }, new int[] { 100, 100 }));
/* 443 */       ir.getOptions().add(new ItemOptionReward(141, new int[] { 1, 1 }, new int[] { 100, 100 }));
/* 444 */       ir.getOptions().add(new ItemOptionReward(30, new int[] { 1, 1 }, new int[] { 100, 100 }));
/*     */     } 
/*     */   }
/*     */   
/*     */   private void button4ActionPerformed(ActionEvent evt) {
/* 449 */     for (ItemReward ir : this.list) {
/* 450 */       ir.getOptions().add(new ItemOptionReward(127, new int[] { 1, 1 }, new int[] { 100, 100 }));
/* 451 */       ir.getOptions().add(new ItemOptionReward(139, new int[] { 1, 1 }, new int[] { 100, 100 }));
/* 452 */       ir.getOptions().add(new ItemOptionReward(30, new int[] { 1, 1 }, new int[] { 100, 100 }));
/*     */     } 
/*     */   }
/*     */   
/*     */   private void button5ActionPerformed(ActionEvent evt) {
/* 457 */     for (ItemReward ir : this.list) {
/* 458 */       ir.getOptions().add(new ItemOptionReward(128, new int[] { 1, 1 }, new int[] { 100, 100 }));
/* 459 */       ir.getOptions().add(new ItemOptionReward(140, new int[] { 1, 1 }, new int[] { 100, 100 }));
/* 460 */       ir.getOptions().add(new ItemOptionReward(30, new int[] { 1, 1 }, new int[] { 100, 100 }));
/*     */     } 
/*     */   }
/*     */   
/*     */   private void button7ActionPerformed(ActionEvent evt) {
/* 465 */     for (ItemReward ir : this.list) {
/* 466 */       ir.getOptions().add(new ItemOptionReward(130, new int[] { 1, 1 }, new int[] { 100, 100 }));
/* 467 */       ir.getOptions().add(new ItemOptionReward(142, new int[] { 1, 1 }, new int[] { 100, 100 }));
/* 468 */       ir.getOptions().add(new ItemOptionReward(30, new int[] { 1, 1 }, new int[] { 100, 100 }));
/*     */     } 
/*     */   }
/*     */   
/*     */   private void button8ActionPerformed(ActionEvent evt) {
/* 473 */     for (ItemReward ir : this.list) {
/* 474 */       ir.getOptions().add(new ItemOptionReward(132, new int[] { 1, 1 }, new int[] { 100, 100 }));
/* 475 */       ir.getOptions().add(new ItemOptionReward(144, new int[] { 1, 1 }, new int[] { 100, 100 }));
/* 476 */       ir.getOptions().add(new ItemOptionReward(30, new int[] { 1, 1 }, new int[] { 100, 100 }));
/*     */     } 
/*     */   }
/*     */   
/*     */   private void button9ActionPerformed(ActionEvent evt) {
/* 481 */     for (ItemReward ir : this.list) {
/* 482 */       ir.getOptions().add(new ItemOptionReward(131, new int[] { 1, 1 }, new int[] { 100, 100 }));
/* 483 */       ir.getOptions().add(new ItemOptionReward(143, new int[] { 1, 1 }, new int[] { 100, 100 }));
/* 484 */       ir.getOptions().add(new ItemOptionReward(30, new int[] { 1, 1 }, new int[] { 100, 100 }));
/*     */     } 
/*     */   }
/*     */   
/*     */   private void button10ActionPerformed(ActionEvent evt) {
/* 489 */     for (ItemReward ir : this.list) {
/* 490 */       ir.getOptions().add(new ItemOptionReward(135, new int[] { 1, 1 }, new int[] { 100, 100 }));
/* 491 */       ir.getOptions().add(new ItemOptionReward(138, new int[] { 1, 1 }, new int[] { 100, 100 }));
/* 492 */       ir.getOptions().add(new ItemOptionReward(30, new int[] { 1, 1 }, new int[] { 100, 100 }));
/*     */     } 
/*     */   }
/*     */   
/*     */   private void button11ActionPerformed(ActionEvent evt) {
/* 497 */     for (ItemReward ir : this.list) {
/* 498 */       ir.getOptions().add(new ItemOptionReward(133, new int[] { 1, 1 }, new int[] { 100, 100 }));
/* 499 */       ir.getOptions().add(new ItemOptionReward(136, new int[] { 1, 1 }, new int[] { 100, 100 }));
/* 500 */       ir.getOptions().add(new ItemOptionReward(30, new int[] { 1, 1 }, new int[] { 100, 100 }));
/*     */     } 
/*     */   }
/*     */   
/*     */   private void button12ActionPerformed(ActionEvent evt) {
/* 505 */     for (ItemReward ir : this.list) {
/* 506 */       ir.getOptions().add(new ItemOptionReward(134, new int[] { 1, 1 }, new int[] { 100, 100 }));
/* 507 */       ir.getOptions().add(new ItemOptionReward(137, new int[] { 1, 1 }, new int[] { 100, 100 }));
/* 508 */       ir.getOptions().add(new ItemOptionReward(30, new int[] { 1, 1 }, new int[] { 100, 100 }));
/*     */     } 
/*     */   }
/*     */   
/*     */   private void setup() {
/* 513 */     setResizable(false);
/* 514 */     setLocationRelativeTo(null);
/* 515 */     for (ItemOptionTemplate io : Manager.gI().getItemOptionTemplates()) {
/* 516 */       this.cboOption.addItem(io.getId() + " - " + io.getName());
/*     */     }
/* 518 */     for (ItemOptionTemplate io : Manager.gI().getItemOptionTemplates()) {
/* 519 */       this.cboOptionRemove.addItem(io.getId() + " - " + io.getName());
/*     */     }
/*     */   }
/*     */   
/*     */   private void findItemOption() {
/* 524 */     String text = this.txtFindOption.getText();
/*     */     try {
/* 526 */       int id = Integer.parseInt(text);
/* 527 */       for (int i = 0; i < Manager.gI().getItemOptionTemplates().size(); i++) {
/* 528 */         if (((ItemOptionTemplate)Manager.gI().getItemOptionTemplates().get(i)).getId() == id) {
/* 529 */           this.cboOption.setSelectedIndex(i);
/*     */           break;
/*     */         } 
/*     */       } 
/* 533 */     } catch (Exception e) {
/* 534 */       for (int i = 0; i < Manager.gI().getItemOptionTemplates().size(); i++) {
/*     */         try {
/* 536 */           String name = ((ItemOptionTemplate)Manager.gI().getItemOptionTemplates().get(i)).getName();
/* 537 */           if (StringUtil.removeAccent(name).toLowerCase().contains(StringUtil.removeAccent(text).toLowerCase())) {
/* 538 */             this.cboOption.setSelectedIndex(i);
/*     */             break;
/*     */           } 
/* 541 */         } catch (Exception exception) {}
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\nro\server_luxu_nrp\vemap\GirlkunToolCBRO.jar!\com\girlkun\tool\screens\mob_reward_scr\AddAllOptionScr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */