/*     */ package com.girlkun.tool.screens.mob_reward_scr;
/*     */ import com.girlkun.tool.screens.mob_reward_scr.models.ItemReward;
/*     */ import java.awt.Component;
/*     */ import java.awt.Font;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.KeyAdapter;
/*     */ import java.awt.event.KeyEvent;
/*     */ import javax.swing.GroupLayout;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.LayoutStyle;
/*     */ 
/*     */ public class ModifyAll extends JFrame {
/*     */   private List<ItemReward> list;
/*     */   private MobRewardScr mobRewardScr;
/*     */   private JLabel Gender;
/*     */   
/*     */   public ModifyAll(MobRewardScr mobRewardScr, List<ItemReward> list) {
/*  20 */     initComponents();
/*  21 */     setup();
/*  22 */     this.list = list;
/*  23 */     this.mobRewardScr = mobRewardScr;
/*  24 */     setAlwaysOnTop(true);
/*  25 */     setDefaultCloseOperation(2);
/*     */   }
/*     */   private Button button1; private Button button2; private Button button3; private JComboBox<String> cboGender; private JLabel jLabel3; private JLabel jLabel4; private JLabel jLabel5; private JLabel jLabel6; private JTextField txtQuanF; private JTextField txtQuanT;
/*     */   private JTextField txtRatio1;
/*     */   private JTextField txtRatio2;
/*     */   
/*     */   private void initComponents() {
/*  32 */     this.jLabel3 = new JLabel();
/*  33 */     this.txtQuanF = new JTextField();
/*  34 */     this.jLabel4 = new JLabel();
/*  35 */     this.txtQuanT = new JTextField();
/*  36 */     this.txtRatio2 = new JTextField();
/*  37 */     this.jLabel6 = new JLabel();
/*  38 */     this.txtRatio1 = new JTextField();
/*  39 */     this.jLabel5 = new JLabel();
/*  40 */     this.Gender = new JLabel();
/*  41 */     this.cboGender = new JComboBox<>();
/*  42 */     this.button1 = new Button();
/*  43 */     this.button2 = new Button();
/*  44 */     this.button3 = new Button();
/*     */     
/*  46 */     setDefaultCloseOperation(3);
/*     */     
/*  48 */     this.jLabel3.setFont(new Font("SansSerif", 1, 12));
/*  49 */     this.jLabel3.setText("Quantity");
/*     */     
/*  51 */     this.txtQuanF.setFont(new Font("SansSerif", 1, 12));
/*  52 */     this.txtQuanF.addKeyListener(new KeyAdapter() {
/*     */           public void keyReleased(KeyEvent evt) {
/*  54 */             ModifyAll.this.txtQuanFKeyReleased(evt);
/*     */           }
/*     */         });
/*     */     
/*  58 */     this.jLabel4.setFont(new Font("SansSerif", 1, 12));
/*  59 */     this.jLabel4.setHorizontalAlignment(0);
/*  60 */     this.jLabel4.setText("to");
/*     */     
/*  62 */     this.txtQuanT.setFont(new Font("SansSerif", 1, 12));
/*  63 */     this.txtQuanT.addKeyListener(new KeyAdapter() {
/*     */           public void keyReleased(KeyEvent evt) {
/*  65 */             ModifyAll.this.txtQuanTKeyReleased(evt);
/*     */           }
/*     */         });
/*     */     
/*  69 */     this.txtRatio2.setFont(new Font("SansSerif", 1, 12));
/*  70 */     this.txtRatio2.addKeyListener(new KeyAdapter() {
/*     */           public void keyReleased(KeyEvent evt) {
/*  72 */             ModifyAll.this.txtRatio2KeyReleased(evt);
/*     */           }
/*     */         });
/*     */     
/*  76 */     this.jLabel6.setFont(new Font("SansSerif", 1, 12));
/*  77 */     this.jLabel6.setHorizontalAlignment(0);
/*  78 */     this.jLabel6.setText("/");
/*     */     
/*  80 */     this.txtRatio1.setFont(new Font("SansSerif", 1, 12));
/*  81 */     this.txtRatio1.addKeyListener(new KeyAdapter() {
/*     */           public void keyReleased(KeyEvent evt) {
/*  83 */             ModifyAll.this.txtRatio1KeyReleased(evt);
/*     */           }
/*     */         });
/*     */     
/*  87 */     this.jLabel5.setFont(new Font("SansSerif", 1, 12));
/*  88 */     this.jLabel5.setText("Ratio");
/*     */     
/*  90 */     this.Gender.setFont(new Font("SansSerif", 1, 12));
/*  91 */     this.Gender.setText("Gender");
/*     */     
/*  93 */     this.cboGender.setFont(new Font("SansSerif", 1, 12));
/*  94 */     this.cboGender.setModel(new DefaultComboBoxModel<>(new String[] { "All", "Trái đất", "Namếc", "Xayda" }));
/*  95 */     this.cboGender.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/*  97 */             ModifyAll.this.cboGenderActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     
/* 101 */     this.button1.setBackground(new Color(255, 153, 153));
/* 102 */     this.button1.setForeground(new Color(51, 0, 204));
/* 103 */     this.button1.setText("Update all");
/* 104 */     this.button1.setFont(new Font("SansSerif", 1, 14));
/* 105 */     this.button1.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/* 107 */             ModifyAll.this.button1ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     
/* 111 */     this.button2.setBackground(new Color(255, 153, 153));
/* 112 */     this.button2.setForeground(new Color(51, 0, 204));
/* 113 */     this.button2.setText("Update all");
/* 114 */     this.button2.setFont(new Font("SansSerif", 1, 14));
/* 115 */     this.button2.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/* 117 */             ModifyAll.this.button2ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     
/* 121 */     this.button3.setBackground(new Color(255, 153, 153));
/* 122 */     this.button3.setForeground(new Color(51, 0, 204));
/* 123 */     this.button3.setText("Update all");
/* 124 */     this.button3.setFont(new Font("SansSerif", 1, 14));
/* 125 */     this.button3.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/* 127 */             ModifyAll.this.button3ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     
/* 131 */     GroupLayout layout = new GroupLayout(getContentPane());
/* 132 */     getContentPane().setLayout(layout);
/* 133 */     layout.setHorizontalGroup(layout
/* 134 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 135 */         .addGroup(layout.createSequentialGroup()
/* 136 */           .addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING)
/* 137 */             .addGroup(GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
/* 138 */               .addComponent(this.Gender, -2, 54, -2)
/* 139 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 140 */               .addComponent(this.cboGender, 0, -1, 32767))
/* 141 */             .addGroup(GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
/* 142 */               .addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false)
/* 143 */                 .addGroup(layout.createSequentialGroup()
/* 144 */                   .addComponent(this.jLabel3, -2, 54, -2)
/* 145 */                   .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 146 */                   .addComponent(this.txtQuanF))
/* 147 */                 .addGroup(GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
/* 148 */                   .addComponent(this.jLabel5, -2, 54, -2)
/* 149 */                   .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 150 */                   .addComponent(this.txtRatio1, -2, 64, -2)))
/* 151 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 152 */               .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 153 */                 .addGroup(layout.createSequentialGroup()
/* 154 */                   .addComponent(this.jLabel6, -2, 54, -2)
/* 155 */                   .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 156 */                   .addComponent(this.txtRatio2))
/* 157 */                 .addGroup(layout.createSequentialGroup()
/* 158 */                   .addComponent(this.jLabel4, -2, 54, -2)
/* 159 */                   .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 160 */                   .addComponent(this.txtQuanT, -2, 81, -2)))))
/* 161 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 162 */           .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 163 */             .addComponent((Component)this.button1, -2, 88, -2)
/* 164 */             .addComponent((Component)this.button2, -2, 88, -2)
/* 165 */             .addComponent((Component)this.button3, -2, 88, -2))));
/*     */     
/* 167 */     layout.setVerticalGroup(layout
/* 168 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 169 */         .addGroup(layout.createSequentialGroup()
/* 170 */           .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 171 */             .addComponent(this.jLabel3, -1, -1, 32767)
/* 172 */             .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 173 */               .addComponent(this.txtQuanF)
/* 174 */               .addComponent(this.jLabel4, -1, -1, 32767)
/* 175 */               .addComponent(this.txtQuanT, -2, 39, -2)
/* 176 */               .addComponent((Component)this.button1, -2, -1, -2)))
/* 177 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 178 */           .addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING)
/* 179 */             .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 180 */               .addComponent(this.jLabel5, -1, -1, 32767)
/* 181 */               .addComponent(this.txtRatio1, -2, 39, -2))
/* 182 */             .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 183 */               .addComponent(this.jLabel6, -1, -1, 32767)
/* 184 */               .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 185 */                 .addComponent(this.txtRatio2, -2, 39, -2)
/* 186 */                 .addComponent((Component)this.button2, -2, -1, -2))))
/* 187 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 188 */           .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 189 */             .addComponent(this.Gender, -1, -1, 32767)
/* 190 */             .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
/* 191 */               .addComponent(this.cboGender, -2, 39, -2)
/* 192 */               .addComponent((Component)this.button3, -2, -1, -2)))
/* 193 */           .addGap(0, 0, 0)));
/*     */ 
/*     */     
/* 196 */     layout.linkSize(1, new Component[] { this.txtQuanF, this.txtRatio1 });
/*     */     
/* 198 */     layout.linkSize(1, new Component[] { (Component)this.button1, (Component)this.button2, (Component)this.button3, this.txtQuanT });
/*     */     
/* 200 */     pack();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void txtQuanFKeyReleased(KeyEvent evt) {}
/*     */ 
/*     */ 
/*     */   
/*     */   private void txtQuanTKeyReleased(KeyEvent evt) {}
/*     */ 
/*     */ 
/*     */   
/*     */   private void txtRatio2KeyReleased(KeyEvent evt) {}
/*     */ 
/*     */ 
/*     */   
/*     */   private void txtRatio1KeyReleased(KeyEvent evt) {}
/*     */ 
/*     */   
/*     */   private void cboGenderActionPerformed(ActionEvent evt) {}
/*     */ 
/*     */   
/*     */   private void button1ActionPerformed(ActionEvent evt) {
/* 224 */     if (NotifyUtil.showConfirmDialog(this, "Bạn có chắc chắn muốn sửa tất cả?") == 0) {
/*     */       try {
/* 226 */         boolean check = false;
/*     */         
/* 228 */         check = (Integer.parseInt(this.txtQuanF.getText()) <= 0 || Integer.parseInt(this.txtQuanT.getText()) <= 0);
/* 229 */         if (check) {
/* 230 */           NotifyUtil.showMessageDialog(this, "Vui lòng nhập đúng giá trị");
/*     */           return;
/*     */         } 
/* 233 */       } catch (Exception e) {
/* 234 */         NotifyUtil.showMessageDialog(this, "Vui lòng nhập đúng giá trị");
/*     */         return;
/*     */       } 
/* 237 */       for (ItemReward itemReward : this.list) {
/* 238 */         itemReward.setQuantity(new int[] { Integer.parseInt(this.txtQuanF.getText()), Integer.parseInt(this.txtQuanT.getText()) });
/*     */       } 
/* 240 */       this.mobRewardScr.fillToTable();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void button2ActionPerformed(ActionEvent evt) {
/* 245 */     if (NotifyUtil.showConfirmDialog(this, "Bạn có chắc chắn muốn sửa tất cả?") == 0) {
/*     */       try {
/* 247 */         boolean check = false;
/*     */         
/* 249 */         check = (Integer.parseInt(this.txtRatio1.getText()) <= 0 || Integer.parseInt(this.txtRatio1.getText()) <= 0);
/* 250 */         if (check) {
/* 251 */           NotifyUtil.showMessageDialog(this, "Vui lòng nhập đúng giá trị");
/*     */           return;
/*     */         } 
/* 254 */       } catch (Exception e) {
/* 255 */         NotifyUtil.showMessageDialog(this, "Vui lòng nhập đúng giá trị");
/*     */         return;
/*     */       } 
/* 258 */       for (ItemReward itemReward : this.list) {
/* 259 */         itemReward.setRatio(new int[] { Integer.parseInt(this.txtRatio1.getText()), Integer.parseInt(this.txtRatio2.getText()) });
/*     */       } 
/* 261 */       this.mobRewardScr.fillToTable();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void button3ActionPerformed(ActionEvent evt) {
/* 266 */     if (NotifyUtil.showConfirmDialog(this, "Bạn có chắc chắn muốn sửa tất cả?") == 0) {
/* 267 */       for (ItemReward itemReward : this.list) {
/* 268 */         itemReward.setGender(this.cboGender.getSelectedIndex() - 1);
/*     */       }
/* 270 */       this.mobRewardScr.fillToTable();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void setup() {
/* 275 */     setResizable(false);
/* 276 */     setLocationRelativeTo(null);
/*     */   }
/*     */ }


/* Location:              D:\nro\server_luxu_nrp\vemap\GirlkunToolCBRO.jar!\com\girlkun\tool\screens\mob_reward_scr\ModifyAll.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */