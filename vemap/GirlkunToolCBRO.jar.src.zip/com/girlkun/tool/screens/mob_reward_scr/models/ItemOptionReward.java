/*    */ package com.girlkun.tool.screens.mob_reward_scr.models;
/*    */ 
/*    */ import com.girlkun.tool.entities.item.ItemOptionTemplate;
/*    */ import com.girlkun.tool.main.Manager;
/*    */ import java.util.Arrays;
/*    */ 
/*    */ public class ItemOptionReward {
/*    */   private ItemOptionTemplate temp;
/*    */   private int[] param;
/*    */   private int[] ratio;
/*    */   
/* 12 */   public void setTemp(ItemOptionTemplate temp) { this.temp = temp; } public void setParam(int[] param) { this.param = param; } public void setRatio(int[] ratio) { this.ratio = ratio; } public boolean equals(Object o) { if (o == this) return true;  if (!(o instanceof ItemOptionReward)) return false;  ItemOptionReward other = (ItemOptionReward)o; if (!other.canEqual(this)) return false;  Object this$temp = getTemp(), other$temp = other.getTemp(); return ((this$temp == null) ? (other$temp != null) : !this$temp.equals(other$temp)) ? false : (!Arrays.equals(getParam(), other.getParam()) ? false : (!!Arrays.equals(getRatio(), other.getRatio()))); } protected boolean canEqual(Object other) { return other instanceof ItemOptionReward; } public int hashCode() { int PRIME = 59; result = 1; Object $temp = getTemp(); result = result * 59 + (($temp == null) ? 43 : $temp.hashCode()); result = result * 59 + Arrays.hashCode(getParam()); return result * 59 + Arrays.hashCode(getRatio()); } public String toString() { return "ItemOptionReward(temp=" + getTemp() + ", param=" + Arrays.toString(getParam()) + ", ratio=" + Arrays.toString(getRatio()) + ")"; }
/*    */   
/*    */   public ItemOptionTemplate getTemp() {
/* 15 */     return this.temp;
/*    */   } public int[] getParam() {
/* 17 */     return this.param;
/*    */   } public int[] getRatio() {
/* 19 */     return this.ratio;
/*    */   }
/*    */   public ItemOptionReward(int tempId, int[] param, int[] ratio) {
/* 22 */     this.temp = Manager.gI().getItemOptionTemplates().get(tempId);
/* 23 */     this.param = param;
/* 24 */     this.ratio = ratio;
/*    */   }
/*    */ }


/* Location:              D:\nro\server_luxu_nrp\vemap\GirlkunToolCBRO.jar!\com\girlkun\tool\screens\mob_reward_scr\models\ItemOptionReward.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */