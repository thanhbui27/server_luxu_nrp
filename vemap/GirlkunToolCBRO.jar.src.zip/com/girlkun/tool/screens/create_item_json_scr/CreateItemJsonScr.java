/*     */ package com.girlkun.tool.screens.create_item_json_scr;
/*     */ import com.girlkun.tool.main.Manager;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.KeyEvent;
/*     */ import javax.swing.GroupLayout;
/*     */ import javax.swing.LayoutStyle;
/*     */ 
/*     */ public class CreateItemJsonScr extends JInternalFrame {
/*     */   private Button button8;
/*     */   private JComboBox<String> cboItemTemplate;
/*     */   private JComboBox<String> cboOption;
/*     */   
/*     */   public CreateItemJsonScr() {
/*  16 */     initComponents();
/*  17 */     setup();
/*     */   }
/*     */   private JLabel jLabel13; private JLabel jLabel14; private JLabel jLabel15; private JLabel jLabel5; private JLabel jLabel6; private JScrollPane jScrollPane1; private JTable tblListItem; private JTextField txtFindItemTemplate;
/*     */   private JTextField txtFindOption;
/*     */   private JTextField txtParam;
/*     */   
/*     */   private void initComponents() {
/*  24 */     this.txtFindItemTemplate = new JTextField();
/*  25 */     this.cboItemTemplate = new JComboBox<>();
/*  26 */     this.jLabel5 = new JLabel();
/*  27 */     this.jLabel6 = new JLabel();
/*  28 */     this.jLabel14 = new JLabel();
/*  29 */     this.txtParam = new JTextField();
/*  30 */     this.cboOption = new JComboBox<>();
/*  31 */     this.jLabel15 = new JLabel();
/*  32 */     this.txtFindOption = new JTextField();
/*  33 */     this.jLabel13 = new JLabel();
/*  34 */     this.jScrollPane1 = new JScrollPane();
/*  35 */     this.tblListItem = new JTable();
/*  36 */     this.button8 = new Button();
/*     */     
/*  38 */     this.txtFindItemTemplate.setBackground(new Color(255, 204, 255));
/*  39 */     this.txtFindItemTemplate.setFont(new Font("SansSerif", 1, 12));
/*  40 */     this.txtFindItemTemplate.setForeground(new Color(51, 0, 51));
/*  41 */     this.txtFindItemTemplate.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/*  43 */             CreateItemJsonScr.this.txtFindItemTemplateKeyPressed(evt);
/*     */           }
/*     */           public void keyReleased(KeyEvent evt) {
/*  46 */             CreateItemJsonScr.this.txtFindItemTemplateKeyReleased(evt);
/*     */           }
/*     */         });
/*     */     
/*  50 */     this.cboItemTemplate.setBackground(new Color(255, 204, 255));
/*  51 */     this.cboItemTemplate.setFont(new Font("SansSerif", 1, 12));
/*  52 */     this.cboItemTemplate.setForeground(new Color(51, 0, 51));
/*  53 */     this.cboItemTemplate.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/*  55 */             CreateItemJsonScr.this.cboItemTemplateActionPerformed(evt);
/*     */           }
/*     */         });
/*  58 */     this.cboItemTemplate.addKeyListener(new KeyAdapter() {
/*     */           public void keyReleased(KeyEvent evt) {
/*  60 */             CreateItemJsonScr.this.cboItemTemplateKeyReleased(evt);
/*     */           }
/*     */         });
/*     */     
/*  64 */     this.jLabel5.setFont(new Font("SansSerif", 1, 12));
/*  65 */     this.jLabel5.setText("Item template");
/*     */     
/*  67 */     this.jLabel6.setFont(new Font("SansSerif", 1, 12));
/*  68 */     this.jLabel6.setText("Search item");
/*     */     
/*  70 */     this.jLabel14.setFont(new Font("SansSerif", 1, 12));
/*  71 */     this.jLabel14.setText("Option template");
/*     */     
/*  73 */     this.txtParam.setFont(new Font("SansSerif", 1, 12));
/*  74 */     this.txtParam.setMaximumSize(new Dimension(152, 39));
/*  75 */     this.txtParam.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/*  77 */             CreateItemJsonScr.this.txtParamKeyPressed(evt);
/*     */           }
/*     */           public void keyReleased(KeyEvent evt) {
/*  80 */             CreateItemJsonScr.this.txtParamKeyReleased(evt);
/*     */           }
/*     */         });
/*     */     
/*  84 */     this.cboOption.setBackground(new Color(255, 204, 255));
/*  85 */     this.cboOption.setFont(new Font("SansSerif", 1, 12));
/*  86 */     this.cboOption.setForeground(new Color(51, 0, 51));
/*  87 */     this.cboOption.setMaximumSize(new Dimension(152, 39));
/*     */     
/*  89 */     this.jLabel15.setFont(new Font("SansSerif", 1, 12));
/*  90 */     this.jLabel15.setText("Param");
/*     */     
/*  92 */     this.txtFindOption.setBackground(new Color(255, 204, 255));
/*  93 */     this.txtFindOption.setFont(new Font("SansSerif", 1, 12));
/*  94 */     this.txtFindOption.setForeground(new Color(51, 0, 51));
/*  95 */     this.txtFindOption.setMaximumSize(new Dimension(152, 39));
/*  96 */     this.txtFindOption.addKeyListener(new KeyAdapter() {
/*     */           public void keyPressed(KeyEvent evt) {
/*  98 */             CreateItemJsonScr.this.txtFindOptionKeyPressed(evt);
/*     */           }
/*     */           public void keyReleased(KeyEvent evt) {
/* 101 */             CreateItemJsonScr.this.txtFindOptionKeyReleased(evt);
/*     */           }
/*     */         });
/*     */     
/* 105 */     this.jLabel13.setFont(new Font("SansSerif", 1, 12));
/* 106 */     this.jLabel13.setText("Search option");
/*     */     
/* 108 */     this.tblListItem.setFont(new Font("SansSerif", 1, 12));
/* 109 */     this.tblListItem.setModel(new DefaultTableModel(new Object[0][], (Object[])new String[] { "Item id", "Name" })
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 117 */           boolean[] canEdit = new boolean[] { false, false };
/*     */ 
/*     */ 
/*     */           
/*     */           public boolean isCellEditable(int rowIndex, int columnIndex) {
/* 122 */             return this.canEdit[columnIndex];
/*     */           }
/*     */         });
/* 125 */     this.jScrollPane1.setViewportView(this.tblListItem);
/*     */     
/* 127 */     this.button8.setBackground(new Color(153, 0, 153));
/* 128 */     this.button8.setForeground(new Color(255, 255, 255));
/* 129 */     this.button8.setText("Add item");
/* 130 */     this.button8.setFont(new Font("SansSerif", 1, 12));
/* 131 */     this.button8.addActionListener(new ActionListener() {
/*     */           public void actionPerformed(ActionEvent evt) {
/* 133 */             CreateItemJsonScr.this.button8ActionPerformed(evt);
/*     */           }
/*     */         });
/*     */     
/* 137 */     GroupLayout layout = new GroupLayout(getContentPane());
/* 138 */     getContentPane().setLayout(layout);
/* 139 */     layout.setHorizontalGroup(layout
/* 140 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 141 */         .addGroup(layout.createSequentialGroup()
/* 142 */           .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 143 */             .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 144 */               .addGroup(GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
/* 145 */                 .addComponent(this.jLabel6, -2, 102, -2)
/* 146 */                 .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 147 */                 .addComponent(this.txtFindItemTemplate))
/* 148 */               .addGroup(layout.createSequentialGroup()
/* 149 */                 .addComponent(this.jLabel5, -2, 102, -2)
/* 150 */                 .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 151 */                 .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 152 */                   .addComponent((Component)this.button8, -1, -1, 32767)
/* 153 */                   .addComponent(this.cboItemTemplate, 0, 161, 32767))))
/* 154 */             .addComponent(this.jScrollPane1, -2, 0, 32767))
/* 155 */           .addGap(110, 110, 110)
/* 156 */           .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 157 */             .addGroup(layout.createSequentialGroup()
/* 158 */               .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 159 */                 .addComponent(this.jLabel14)
/* 160 */                 .addComponent(this.jLabel15, -2, 90, -2))
/* 161 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 162 */               .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 163 */                 .addComponent(this.cboOption, -2, 228, -2)
/* 164 */                 .addComponent(this.txtParam, -2, 228, -2)))
/* 165 */             .addGroup(layout.createSequentialGroup()
/* 166 */               .addComponent(this.jLabel13, -2, 100, -2)
/* 167 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 168 */               .addComponent(this.txtFindOption, -1, -1, 32767)))
/* 169 */           .addGap(0, 493, 32767)));
/*     */ 
/*     */     
/* 172 */     layout.linkSize(0, new Component[] { this.jLabel14, this.jLabel15, this.jLabel5, this.jLabel6 });
/*     */     
/* 174 */     layout.linkSize(0, new Component[] { this.cboItemTemplate, this.cboOption, this.txtFindItemTemplate });
/*     */     
/* 176 */     layout.setVerticalGroup(layout
/* 177 */         .createParallelGroup(GroupLayout.Alignment.LEADING)
/* 178 */         .addGroup(layout.createSequentialGroup()
/* 179 */           .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 180 */             .addGroup(layout.createSequentialGroup()
/* 181 */               .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
/* 182 */                 .addComponent(this.jLabel6, -1, -1, 32767)
/* 183 */                 .addComponent(this.txtFindItemTemplate, -2, 39, -2))
/* 184 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 185 */               .addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING, false)
/* 186 */                 .addComponent(this.cboItemTemplate)
/* 187 */                 .addComponent(this.jLabel5, -2, 39, -2))
/* 188 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 189 */               .addComponent((Component)this.button8, -2, 39, -2))
/* 190 */             .addGroup(layout.createSequentialGroup()
/* 191 */               .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 192 */                 .addComponent(this.jLabel13, -2, 39, -2)
/* 193 */                 .addComponent(this.txtFindOption, -2, 39, -2))
/* 194 */               .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 195 */               .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
/* 196 */                 .addGroup(layout.createSequentialGroup()
/* 197 */                   .addComponent(this.jLabel14, -2, 39, -2)
/* 198 */                   .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 199 */                   .addComponent(this.jLabel15, -2, 39, -2))
/* 200 */                 .addGroup(layout.createSequentialGroup()
/* 201 */                   .addComponent(this.cboOption, -2, 39, -2)
/* 202 */                   .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 203 */                   .addComponent(this.txtParam, -2, 39, -2)))))
/* 204 */           .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
/* 205 */           .addComponent(this.jScrollPane1, -2, -1, -2)
/* 206 */           .addContainerGap(180, 32767)));
/*     */ 
/*     */     
/* 209 */     pack();
/*     */   }
/*     */   
/*     */   private void txtFindItemTemplateKeyPressed(KeyEvent evt) {
/* 213 */     findItemTemplate();
/*     */   }
/*     */   
/*     */   private void txtFindItemTemplateKeyReleased(KeyEvent evt) {
/* 217 */     findItemTemplate();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void cboItemTemplateActionPerformed(ActionEvent evt) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void cboItemTemplateKeyReleased(KeyEvent evt) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void txtParamKeyPressed(KeyEvent evt) {}
/*     */ 
/*     */ 
/*     */   
/*     */   private void txtParamKeyReleased(KeyEvent evt) {}
/*     */ 
/*     */ 
/*     */   
/*     */   private void txtFindOptionKeyPressed(KeyEvent evt) {
/* 242 */     findItemOption();
/*     */   }
/*     */   
/*     */   private void txtFindOptionKeyReleased(KeyEvent evt) {
/* 246 */     findItemOption();
/*     */   }
/*     */ 
/*     */   
/*     */   private void button8ActionPerformed(ActionEvent evt) {}
/*     */   
/*     */   private void setup() {
/* 253 */     setTitle("Girlkun - Item Json");
/* 254 */     setResizable(false);
/*     */     
/* 256 */     for (ItemTemplate item : Manager.gI().getItemTemplates()) {
/* 257 */       this.cboItemTemplate.addItem(item.getId() + " - " + item.getName());
/*     */     }
/*     */ 
/*     */     
/* 261 */     for (ItemOptionTemplate io : Manager.gI().getItemOptionTemplates()) {
/* 262 */       this.cboOption.addItem(io.getId() + " - " + io.getName());
/*     */     }
/*     */   }
/*     */   
/*     */   private void findItemOption() {
/* 267 */     String text = this.txtFindOption.getText();
/*     */     try {
/* 269 */       int id = Integer.parseInt(text);
/* 270 */       for (int i = 0; i < Manager.gI().getItemOptionTemplates().size(); i++) {
/* 271 */         if (((ItemOptionTemplate)Manager.gI().getItemOptionTemplates().get(i)).getId() == id) {
/* 272 */           this.cboOption.setSelectedIndex(i);
/*     */           break;
/*     */         } 
/*     */       } 
/* 276 */     } catch (Exception e) {
/* 277 */       for (int i = 0; i < Manager.gI().getItemOptionTemplates().size(); i++) {
/*     */         try {
/* 279 */           String name = ((ItemOptionTemplate)Manager.gI().getItemOptionTemplates().get(i)).getName();
/* 280 */           if (StringUtil.removeAccent(name).toLowerCase().contains(StringUtil.removeAccent(text).toLowerCase())) {
/* 281 */             this.cboOption.setSelectedIndex(i);
/*     */             break;
/*     */           } 
/* 284 */         } catch (Exception exception) {}
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void findItemTemplate() {
/* 292 */     String text = this.txtFindItemTemplate.getText();
/*     */     try {
/* 294 */       int id = Integer.parseInt(text);
/* 295 */       for (int i = 0; i < Manager.gI().getItemTemplates().size(); i++) {
/* 296 */         if (((ItemTemplate)Manager.gI().getItemTemplates().get(i)).getId() == id) {
/* 297 */           this.cboItemTemplate.setSelectedIndex(i);
/*     */           break;
/*     */         } 
/*     */       } 
/* 301 */     } catch (Exception e) {
/* 302 */       for (int i = 0; i < Manager.gI().getItemTemplates().size(); i++) {
/*     */         try {
/* 304 */           String name = ((ItemTemplate)Manager.gI().getItemTemplates().get(i)).getName();
/* 305 */           if (StringUtil.removeAccent(name).toLowerCase().contains(StringUtil.removeAccent(text).toLowerCase())) {
/* 306 */             this.cboItemTemplate.setSelectedIndex(i);
/*     */             break;
/*     */           } 
/* 309 */         } catch (Exception exception) {}
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\nro\server_luxu_nrp\vemap\GirlkunToolCBRO.jar!\com\girlkun\tool\screens\create_item_json_scr\CreateItemJsonScr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */