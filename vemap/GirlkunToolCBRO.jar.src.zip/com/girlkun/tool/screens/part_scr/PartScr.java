/*      */ package com.girlkun.tool.screens.part_scr;
/*      */ import com.girlkun.button.Button;
/*      */ import com.girlkun.database.GirlkunDB;
/*      */ import com.girlkun.result.GirlkunResultSet;
/*      */ import com.girlkun.tool.main.Main;
/*      */ import com.girlkun.tool.screens.part_scr.models.Part;
/*      */ import com.girlkun.tool.screens.part_scr.models.PartInfo;
/*      */ import com.girlkun.tool.utils.NotifyUtil;
/*      */ import java.awt.Color;
/*      */ import java.awt.Component;
/*      */ import java.awt.Font;
/*      */ import java.awt.Graphics2D;
/*      */ import java.awt.event.ActionEvent;
/*      */ import java.awt.event.ActionListener;
/*      */ import java.awt.event.KeyAdapter;
/*      */ import java.awt.event.KeyEvent;
/*      */ import java.awt.image.BufferedImage;
/*      */ import java.awt.image.ImageObserver;
/*      */ import java.io.IOException;
/*      */ import javax.imageio.ImageIO;
/*      */ import javax.swing.GroupLayout;
/*      */ import javax.swing.ImageIcon;
/*      */ import javax.swing.JFileChooser;
/*      */ import javax.swing.JFrame;
/*      */ import javax.swing.JLabel;
/*      */ import javax.swing.JPanel;
/*      */ import javax.swing.JTabbedPane;
/*      */ import javax.swing.JTextField;
/*      */ import javax.swing.LayoutStyle;
/*      */ import org.json.simple.JSONArray;
/*      */ 
/*      */ public class PartScr extends JInternalFrame {
/*   33 */   String pathCache = "data/girlkun/icon/x2"; private Thread tDraw; private long st; private int fps; private long lastTimeCalFPS; private int timeCalFPS; private BufferedImage tamDem; private Color colorPink; private int typeChose; private int indexChose; private Button buttonChose; private int f; private Button button100; private Button button101; private Button button102; private Button button103; private Button button104; private Button button105; private Button button106; private Button button107; private Button button108; private Button button109; private Button button18; private Button button19; private Button button22; private Button button24; private Button button25; private Button button26; private Button button28; private Button button29; private Button button30; private Button button31; private Button button32; private Button button33; private Button button34; private Button button58; private Button button59; private Button button60; private Button button61;
/*      */   private Button button62;
/*      */   private Button button63;
/*      */   private Button button64;
/*      */   private Button button65;
/*      */   private Button button66;
/*      */   private Button button67;
/*      */   private Button button68;
/*      */   private Button button69;
/*      */   private Button button70;
/*      */   
/*      */   private void start() {
/*   45 */     this.button33.setVisible(false);
/*   46 */     this.button34.setVisible(false);
/*   47 */     this.lblF.setVisible(false);
/*      */   }
/*      */   
/*      */   private Button button71; private Button button72; private Button button73; private Button button74; private Button button75; private Button button76; private Button button77; private Button button78; private Button button79; private Button button80; private Button button81; private Button button82; private Button button83; private Button button84; private Button button85; private Button button86; private Button button87; private Button button88; private Button button89; private Button button90; private Button button91; private Button button92;
/*      */   private Button button93;
/*      */   
/*   53 */   public PartScr() { this.timeCalFPS = 100;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1249 */     this.colorPink = new Color(255, 204, 204);
/* 1250 */     this.typeChose = -1;
/* 1251 */     this.indexChose = -1;
/* 1252 */     this.buttonChose = null; initComponents(); setup(); initThread(); start(); }
/*      */   private Button button94;
/*      */   private Button button95; private Button button96; private Button button97; private Button button98; private Button button99; private JLabel jLabel1; private JLabel jLabel2; private JPanel jPanel1; private JPanel jPanel2; private JTabbedPane jTabbedPane1; private JLabel lblF; private JPanel panelBody; private JPanel panelHead; private JPanel panelLeg; private JPanel panelPartModify; private JPanel panelScreen; private JTextField txtDx; private JTextField txtDy; private Part dfHead; private Part dfBody; private Part dfLeg; private Part partModify; private PartInfo partInfo; private void initThread() { this.tDraw = new Thread(() -> { while (!this.isClosed) { try { if (this.isSelected && this.jTabbedPane1.getSelectedIndex() == 0) { this.st = System.currentTimeMillis(); draw(); }  Thread.sleep(1L); } catch (Exception e) { e.printStackTrace(); }  }
/*      */         
/*      */         }); } private void draw() { if (this.tamDem == null)
/* 1257 */       this.tamDem = new BufferedImage(this.panelScreen.getWidth(), this.panelScreen.getHeight(), 2);  drawToTamDem(); drawToScreen(); } private void drawToTamDem() {} private void addEventButton(final Button button, final int index, final int type) { button.addActionListener(new ActionListener()
/*      */         {
/*      */           public void actionPerformed(ActionEvent e)
/*      */           {
/* 1261 */             for (Component com : PartScr.this.panelHead.getComponents()) {
/* 1262 */               ((Button)com).setBackground(PartScr.this.colorPink);
/*      */             }
/* 1264 */             for (Component com : PartScr.this.panelBody.getComponents()) {
/* 1265 */               ((Button)com).setBackground(PartScr.this.colorPink);
/*      */             }
/* 1267 */             for (Component com : PartScr.this.panelLeg.getComponents()) {
/* 1268 */               ((Button)com).setBackground(PartScr.this.colorPink);
/*      */             }
/* 1270 */             button.setBackground(Color.red);
/* 1271 */             PartScr.this.typeChose = type;
/* 1272 */             PartScr.this.indexChose = index;
/* 1273 */             PartScr.this.buttonChose = button;
/*      */           }
/*      */         }); }
/*      */ 
/*      */   
/*      */   private void drawToScreen() {
/*      */     Graphics2D grphScreen = (Graphics2D)this.panelScreen.getGraphics();
/*      */     try {
/*      */       grphScreen.drawImage(this.tamDem, 0, 0, (ImageObserver)null);
/*      */     } catch (Exception exception) {}
/*      */     grphScreen.dispose();
/*      */   }
/*      */   
/*      */   private void initComponents() {
/*      */     this.jTabbedPane1 = new JTabbedPane();
/*      */     this.jPanel1 = new JPanel();
/*      */     this.panelHead = new JPanel();
/*      */     this.button109 = new Button();
/*      */     this.button107 = new Button();
/*      */     this.button108 = new Button();
/*      */     this.panelBody = new JPanel();
/*      */     this.button76 = new Button();
/*      */     this.button77 = new Button();
/*      */     this.button78 = new Button();
/*      */     this.button79 = new Button();
/*      */     this.button80 = new Button();
/*      */     this.button81 = new Button();
/*      */     this.button82 = new Button();
/*      */     this.button83 = new Button();
/*      */     this.button84 = new Button();
/*      */     this.button85 = new Button();
/*      */     this.button86 = new Button();
/*      */     this.button87 = new Button();
/*      */     this.button88 = new Button();
/*      */     this.button89 = new Button();
/*      */     this.button90 = new Button();
/*      */     this.button91 = new Button();
/*      */     this.button92 = new Button();
/*      */     this.panelLeg = new JPanel();
/*      */     this.button100 = new Button();
/*      */     this.button103 = new Button();
/*      */     this.button106 = new Button();
/*      */     this.button96 = new Button();
/*      */     this.button95 = new Button();
/*      */     this.button104 = new Button();
/*      */     this.button93 = new Button();
/*      */     this.button101 = new Button();
/*      */     this.button94 = new Button();
/*      */     this.button97 = new Button();
/*      */     this.button102 = new Button();
/*      */     this.button105 = new Button();
/*      */     this.button99 = new Button();
/*      */     this.button98 = new Button();
/*      */     this.button18 = new Button();
/*      */     this.button24 = new Button();
/*      */     this.button25 = new Button();
/*      */     this.button28 = new Button();
/*      */     this.button29 = new Button();
/*      */     this.button31 = new Button();
/*      */     this.button19 = new Button();
/*      */     this.button26 = new Button();
/*      */     this.button30 = new Button();
/*      */     this.panelScreen = new JPanel();
/*      */     this.button32 = new Button();
/*      */     this.button33 = new Button();
/*      */     this.button34 = new Button();
/*      */     this.lblF = new JLabel();
/*      */     this.jPanel2 = new JPanel();
/*      */     this.panelPartModify = new JPanel();
/*      */     this.button22 = new Button();
/*      */     this.button60 = new Button();
/*      */     this.button61 = new Button();
/*      */     this.button62 = new Button();
/*      */     this.button63 = new Button();
/*      */     this.button64 = new Button();
/*      */     this.button65 = new Button();
/*      */     this.button66 = new Button();
/*      */     this.button67 = new Button();
/*      */     this.button68 = new Button();
/*      */     this.button69 = new Button();
/*      */     this.button70 = new Button();
/*      */     this.button71 = new Button();
/*      */     this.button72 = new Button();
/*      */     this.button73 = new Button();
/*      */     this.button74 = new Button();
/*      */     this.button75 = new Button();
/*      */     this.button58 = new Button();
/*      */     this.button59 = new Button();
/*      */     this.jLabel1 = new JLabel();
/*      */     this.txtDx = new JTextField();
/*      */     this.txtDy = new JTextField();
/*      */     this.jLabel2 = new JLabel();
/*      */     setClosable(true);
/*      */     setIconifiable(true);
/*      */     this.jTabbedPane1.setFont(new Font("Tahoma", 1, 12));
/*      */     this.button109.setBackground(new Color(255, 204, 204));
/*      */     this.button107.setBackground(new Color(255, 204, 204));
/*      */     this.button108.setBackground(new Color(255, 204, 204));
/*      */     GroupLayout panelHeadLayout = new GroupLayout(this.panelHead);
/*      */     this.panelHead.setLayout(panelHeadLayout);
/*      */     panelHeadLayout.setHorizontalGroup(panelHeadLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(panelHeadLayout.createSequentialGroup().addContainerGap().addComponent((Component)this.button107, -2, 75, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button108, -2, 75, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button109, -2, 75, -2).addContainerGap(-1, 32767)));
/*      */     panelHeadLayout.setVerticalGroup(panelHeadLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(panelHeadLayout.createSequentialGroup().addContainerGap().addGroup(panelHeadLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent((Component)this.button109, -2, 73, -2).addComponent((Component)this.button108, -2, 73, -2).addComponent((Component)this.button107, -2, 73, -2)).addContainerGap(-1, 32767)));
/*      */     this.button76.setBackground(new Color(255, 204, 204));
/*      */     this.button77.setBackground(new Color(255, 204, 204));
/*      */     this.button78.setBackground(new Color(255, 204, 204));
/*      */     this.button79.setBackground(new Color(255, 204, 204));
/*      */     this.button80.setBackground(new Color(255, 204, 204));
/*      */     this.button81.setBackground(new Color(255, 204, 204));
/*      */     this.button82.setBackground(new Color(255, 204, 204));
/*      */     this.button83.setBackground(new Color(255, 204, 204));
/*      */     this.button84.setBackground(new Color(255, 204, 204));
/*      */     this.button85.setBackground(new Color(255, 204, 204));
/*      */     this.button86.setBackground(new Color(255, 204, 204));
/*      */     this.button87.setBackground(new Color(255, 204, 204));
/*      */     this.button88.setBackground(new Color(255, 204, 204));
/*      */     this.button89.setBackground(new Color(255, 204, 204));
/*      */     this.button90.setBackground(new Color(255, 204, 204));
/*      */     this.button91.setBackground(new Color(255, 204, 204));
/*      */     this.button92.setBackground(new Color(255, 204, 204));
/*      */     GroupLayout panelBodyLayout = new GroupLayout(this.panelBody);
/*      */     this.panelBody.setLayout(panelBodyLayout);
/*      */     panelBodyLayout.setHorizontalGroup(panelBodyLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(panelBodyLayout.createSequentialGroup().addContainerGap().addGroup(panelBodyLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(panelBodyLayout.createSequentialGroup().addComponent((Component)this.button76, -2, 75, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button77, -2, 75, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button78, -2, 75, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button79, -2, 75, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button80, -2, 75, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button81, -2, 75, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button82, -2, 75, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button83, -2, 75, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button84, -2, 75, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, -1, 32767).addComponent((Component)this.button85, -2, 75, -2)).addGroup(panelBodyLayout.createSequentialGroup().addComponent((Component)this.button86, -2, 75, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button87, -2, 75, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button88, -2, 75, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button89, -2, 75, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button90, -2, 75, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button91, -2, 75, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button92, -2, 75, -2).addGap(0, 0, 32767))).addContainerGap()));
/*      */     panelBodyLayout.setVerticalGroup(panelBodyLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(panelBodyLayout.createSequentialGroup().addContainerGap().addGroup(panelBodyLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent((Component)this.button85, -2, 73, -2).addComponent((Component)this.button84, -2, 73, -2).addComponent((Component)this.button83, -2, 73, -2).addComponent((Component)this.button82, -2, 73, -2).addComponent((Component)this.button81, -2, 73, -2).addComponent((Component)this.button80, -2, 73, -2).addComponent((Component)this.button79, -2, 73, -2).addComponent((Component)this.button78, -2, 73, -2).addComponent((Component)this.button77, -2, 73, -2).addComponent((Component)this.button76, -2, 73, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, -1, 32767).addGroup(panelBodyLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent((Component)this.button92, -2, 73, -2).addComponent((Component)this.button91, -2, 73, -2).addComponent((Component)this.button90, -2, 73, -2).addComponent((Component)this.button89, -2, 73, -2).addComponent((Component)this.button88, -2, 73, -2).addComponent((Component)this.button87, -2, 73, -2).addComponent((Component)this.button86, -2, 73, -2)).addContainerGap()));
/*      */     this.button100.setBackground(new Color(255, 204, 204));
/*      */     this.button103.setBackground(new Color(255, 204, 204));
/*      */     this.button106.setBackground(new Color(255, 204, 204));
/*      */     this.button96.setBackground(new Color(255, 204, 204));
/*      */     this.button95.setBackground(new Color(255, 204, 204));
/*      */     this.button104.setBackground(new Color(255, 204, 204));
/*      */     this.button93.setBackground(new Color(255, 204, 204));
/*      */     this.button101.setBackground(new Color(255, 204, 204));
/*      */     this.button94.setBackground(new Color(255, 204, 204));
/*      */     this.button97.setBackground(new Color(255, 204, 204));
/*      */     this.button102.setBackground(new Color(255, 204, 204));
/*      */     this.button105.setBackground(new Color(255, 204, 204));
/*      */     this.button99.setBackground(new Color(255, 204, 204));
/*      */     this.button98.setBackground(new Color(255, 204, 204));
/*      */     GroupLayout panelLegLayout = new GroupLayout(this.panelLeg);
/*      */     this.panelLeg.setLayout(panelLegLayout);
/*      */     panelLegLayout.setHorizontalGroup(panelLegLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(panelLegLayout.createSequentialGroup().addContainerGap().addGroup(panelLegLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(panelLegLayout.createSequentialGroup().addComponent((Component)this.button93, -2, 75, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button94, -2, 75, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button95, -2, 75, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button96, -2, 75, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button97, -2, 75, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button98, -2, 75, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button99, -2, 75, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button100, -2, 75, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button101, -2, 75, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, -1, 32767).addComponent((Component)this.button102, -2, 75, -2)).addGroup(panelLegLayout.createSequentialGroup().addComponent((Component)this.button103, -2, 75, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button104, -2, 75, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button105, -2, 75, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button106, -2, 75, -2).addGap(486, 486, 486))).addGap(20, 20, 20)));
/*      */     panelLegLayout.setVerticalGroup(panelLegLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(GroupLayout.Alignment.TRAILING, panelLegLayout.createSequentialGroup().addContainerGap().addGroup(panelLegLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent((Component)this.button102, -2, 73, -2).addComponent((Component)this.button101, -2, 73, -2).addComponent((Component)this.button100, -2, 73, -2).addComponent((Component)this.button99, -2, 73, -2).addComponent((Component)this.button98, -2, 73, -2).addComponent((Component)this.button97, -2, 73, -2).addComponent((Component)this.button96, -2, 73, -2).addComponent((Component)this.button95, -2, 73, -2).addComponent((Component)this.button94, -2, 73, -2).addComponent((Component)this.button93, -2, 73, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, -1, 32767).addGroup(panelLegLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent((Component)this.button106, -2, 73, -2).addComponent((Component)this.button105, -2, 73, -2).addComponent((Component)this.button104, -2, 73, -2).addComponent((Component)this.button103, -2, 73, -2)).addContainerGap()));
/*      */     this.button18.setBackground(new Color(255, 0, 255));
/*      */     this.button18.setForeground(new Color(255, 255, 255));
/*      */     this.button18.setText("Load part head");
/*      */     this.button18.setFont(new Font("SansSerif", 1, 12));
/*      */     this.button18.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/*      */             PartScr.this.button18ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     this.button24.setBackground(new Color(255, 0, 255));
/*      */     this.button24.setForeground(new Color(255, 255, 255));
/*      */     this.button24.setText("Add part head");
/*      */     this.button24.setFont(new Font("SansSerif", 1, 12));
/*      */     this.button24.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/*      */             PartScr.this.button24ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     this.button25.setBackground(new Color(255, 0, 255));
/*      */     this.button25.setForeground(new Color(255, 255, 255));
/*      */     this.button25.setText("Load part body");
/*      */     this.button25.setFont(new Font("SansSerif", 1, 12));
/*      */     this.button25.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/*      */             PartScr.this.button25ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     this.button28.setBackground(new Color(255, 0, 255));
/*      */     this.button28.setForeground(new Color(255, 255, 255));
/*      */     this.button28.setText("Add part body");
/*      */     this.button28.setFont(new Font("SansSerif", 1, 12));
/*      */     this.button28.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/*      */             PartScr.this.button28ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     this.button29.setBackground(new Color(255, 0, 255));
/*      */     this.button29.setForeground(new Color(255, 255, 255));
/*      */     this.button29.setText("Load part leg");
/*      */     this.button29.setFont(new Font("SansSerif", 1, 12));
/*      */     this.button29.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/*      */             PartScr.this.button29ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     this.button31.setBackground(new Color(255, 0, 255));
/*      */     this.button31.setForeground(new Color(255, 255, 255));
/*      */     this.button31.setText("Add part leg");
/*      */     this.button31.setFont(new Font("SansSerif", 1, 12));
/*      */     this.button31.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/*      */             PartScr.this.button31ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     this.button19.setBackground(new Color(255, 0, 255));
/*      */     this.button19.setForeground(new Color(255, 255, 255));
/*      */     this.button19.setText("Save part head");
/*      */     this.button19.setFont(new Font("SansSerif", 1, 12));
/*      */     this.button19.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/*      */             PartScr.this.button19ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     this.button26.setBackground(new Color(255, 0, 255));
/*      */     this.button26.setForeground(new Color(255, 255, 255));
/*      */     this.button26.setText("Save part body");
/*      */     this.button26.setFont(new Font("SansSerif", 1, 12));
/*      */     this.button26.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/*      */             PartScr.this.button26ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     this.button30.setBackground(new Color(255, 0, 255));
/*      */     this.button30.setForeground(new Color(255, 255, 255));
/*      */     this.button30.setText("Save part leg");
/*      */     this.button30.setFont(new Font("SansSerif", 1, 12));
/*      */     this.button30.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/*      */             PartScr.this.button30ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     GroupLayout panelScreenLayout = new GroupLayout(this.panelScreen);
/*      */     this.panelScreen.setLayout(panelScreenLayout);
/*      */     panelScreenLayout.setHorizontalGroup(panelScreenLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGap(0, 327, 32767));
/*      */     panelScreenLayout.setVerticalGroup(panelScreenLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGap(0, 0, 32767));
/*      */     this.button32.setBackground(new Color(0, 204, 0));
/*      */     this.button32.setForeground(new Color(255, 255, 255));
/*      */     this.button32.setText("Change image");
/*      */     this.button32.setFont(new Font("SansSerif", 1, 12));
/*      */     this.button32.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/*      */             PartScr.this.button32ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     this.button33.setBackground(new Color(255, 0, 255));
/*      */     this.button33.setForeground(new Color(255, 255, 255));
/*      */     this.button33.setText("Up");
/*      */     this.button33.setFont(new Font("SansSerif", 1, 12));
/*      */     this.button33.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/*      */             PartScr.this.button33ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     this.button34.setBackground(new Color(255, 0, 255));
/*      */     this.button34.setForeground(new Color(255, 255, 255));
/*      */     this.button34.setText("Down");
/*      */     this.button34.setFont(new Font("SansSerif", 1, 12));
/*      */     this.button34.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/*      */             PartScr.this.button34ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     this.lblF.setFont(new Font("SansSerif", 1, 14));
/*      */     this.lblF.setHorizontalAlignment(0);
/*      */     this.lblF.setText("0");
/*      */     GroupLayout jPanel1Layout = new GroupLayout(this.jPanel1);
/*      */     this.jPanel1.setLayout(jPanel1Layout);
/*      */     jPanel1Layout.setHorizontalGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addContainerGap().addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addGap(10, 10, 10).addComponent(this.panelScreen, -2, -1, -2).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent((Component)this.button33, -1, -1, 32767).addComponent((Component)this.button34, -1, -1, 32767).addComponent(this.lblF, -1, -1, 32767)).addGap(592, 592, 592)).addGroup(jPanel1Layout.createSequentialGroup().addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(this.panelHead, -1, -1, 32767).addComponent(this.panelLeg, -1, -1, 32767).addComponent(this.panelBody, -1, -1, 32767)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addComponent((Component)this.button18, -1, -1, 32767).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addComponent((Component)this.button24, -2, 79, -2)).addGroup(GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup().addComponent((Component)this.button25, -1, -1, 32767).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addComponent((Component)this.button28, -2, 79, -2)).addGroup(GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup().addComponent((Component)this.button29, -1, -1, 32767).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addComponent((Component)this.button31, -2, 79, -2)).addComponent((Component)this.button26, -1, -1, 32767).addComponent((Component)this.button19, -1, -1, 32767).addComponent((Component)this.button30, -1, -1, 32767).addComponent((Component)this.button32, -1, -1, 32767)).addContainerGap()))));
/*      */     jPanel1Layout.setVerticalGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.panelHead, -2, -1, -2).addGroup(jPanel1Layout.createSequentialGroup().addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent((Component)this.button18, -2, 42, -2).addComponent((Component)this.button24, -2, 42, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button19, -2, 42, -2))).addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addComponent(this.panelBody, -2, -1, -2)).addGroup(jPanel1Layout.createSequentialGroup().addGap(29, 29, 29).addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent((Component)this.button25, -2, 42, -2).addComponent((Component)this.button28, -2, 42, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button26, -2, 42, -2))).addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addGroup(jPanel1Layout.createSequentialGroup().addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addComponent(this.panelLeg, -2, -1, -2)).addGroup(jPanel1Layout.createSequentialGroup().addGap(25, 25, 25).addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent((Component)this.button29, -2, 35, -2).addComponent((Component)this.button31, -2, 42, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button30, -2, 35, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, -1, 32767).addComponent((Component)this.button32, -2, 35, -2))).addGap(18, 18, 18).addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.panelScreen, -1, -1, 32767).addGroup(jPanel1Layout.createSequentialGroup().addComponent((Component)this.button33, -2, 35, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.lblF, -2, 31, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button34, -2, 35, -2).addGap(0, 91, 32767)))));
/*      */     jPanel1Layout.linkSize(1, new Component[] { (Component)this.button18, (Component)this.button19, (Component)this.button24, (Component)this.button25, (Component)this.button26, (Component)this.button28, (Component)this.button29, (Component)this.button30, (Component)this.button31 });
/*      */     this.jTabbedPane1.addTab("Add part", this.jPanel1);
/*      */     this.button22.setBackground(new Color(255, 204, 204));
/*      */     this.button60.setBackground(new Color(255, 204, 204));
/*      */     this.button61.setBackground(new Color(255, 204, 204));
/*      */     this.button62.setBackground(new Color(255, 204, 204));
/*      */     this.button63.setBackground(new Color(255, 204, 204));
/*      */     this.button64.setBackground(new Color(255, 204, 204));
/*      */     this.button65.setBackground(new Color(255, 204, 204));
/*      */     this.button66.setBackground(new Color(255, 204, 204));
/*      */     this.button67.setBackground(new Color(255, 204, 204));
/*      */     this.button68.setBackground(new Color(255, 204, 204));
/*      */     this.button69.setBackground(new Color(255, 204, 204));
/*      */     this.button70.setBackground(new Color(255, 204, 204));
/*      */     this.button71.setBackground(new Color(255, 204, 204));
/*      */     this.button72.setBackground(new Color(255, 204, 204));
/*      */     this.button73.setBackground(new Color(255, 204, 204));
/*      */     this.button74.setBackground(new Color(255, 204, 204));
/*      */     this.button75.setBackground(new Color(255, 204, 204));
/*      */     GroupLayout panelPartModifyLayout = new GroupLayout(this.panelPartModify);
/*      */     this.panelPartModify.setLayout(panelPartModifyLayout);
/*      */     panelPartModifyLayout.setHorizontalGroup(panelPartModifyLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(panelPartModifyLayout.createSequentialGroup().addContainerGap().addGroup(panelPartModifyLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(panelPartModifyLayout.createSequentialGroup().addComponent((Component)this.button22, -2, 75, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button60, -2, 75, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button61, -2, 75, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button62, -2, 75, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button63, -2, 75, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button64, -2, 75, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button65, -2, 75, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button66, -2, 75, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button67, -2, 75, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button68, -2, 75, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button69, -2, 75, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button70, -2, 75, -2)).addGroup(panelPartModifyLayout.createSequentialGroup().addComponent((Component)this.button71, -2, 75, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button72, -2, 75, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button73, -2, 75, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button74, -2, 75, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button75, -2, 75, -2))).addContainerGap(-1, 32767)));
/*      */     panelPartModifyLayout.setVerticalGroup(panelPartModifyLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(panelPartModifyLayout.createSequentialGroup().addContainerGap().addGroup(panelPartModifyLayout.createParallelGroup(GroupLayout.Alignment.TRAILING).addComponent((Component)this.button70, -2, 73, -2).addComponent((Component)this.button69, -2, 73, -2).addComponent((Component)this.button68, -2, 73, -2).addComponent((Component)this.button67, -2, 73, -2).addComponent((Component)this.button66, -2, 73, -2).addComponent((Component)this.button65, -2, 73, -2).addComponent((Component)this.button64, -2, 73, -2).addComponent((Component)this.button63, -2, 73, -2).addComponent((Component)this.button62, -2, 73, -2).addComponent((Component)this.button61, -2, 73, -2).addComponent((Component)this.button60, -2, 73, -2).addComponent((Component)this.button22, -2, 73, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, -1, 32767).addGroup(panelPartModifyLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent((Component)this.button71, GroupLayout.Alignment.TRAILING, -2, 73, -2).addComponent((Component)this.button72, GroupLayout.Alignment.TRAILING, -2, 73, -2).addComponent((Component)this.button73, GroupLayout.Alignment.TRAILING, -2, 73, -2).addComponent((Component)this.button74, GroupLayout.Alignment.TRAILING, -2, 73, -2).addComponent((Component)this.button75, GroupLayout.Alignment.TRAILING, -2, 73, -2)).addContainerGap()));
/*      */     this.button58.setBackground(new Color(255, 0, 255));
/*      */     this.button58.setForeground(new Color(255, 255, 255));
/*      */     this.button58.setText("Load part");
/*      */     this.button58.setFont(new Font("SansSerif", 1, 12));
/*      */     this.button58.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/*      */             PartScr.this.button58ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     this.button59.setBackground(new Color(255, 0, 255));
/*      */     this.button59.setForeground(new Color(255, 255, 255));
/*      */     this.button59.setText("Save part");
/*      */     this.button59.setFont(new Font("SansSerif", 1, 12));
/*      */     this.button59.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent evt) {
/*      */             PartScr.this.button59ActionPerformed(evt);
/*      */           }
/*      */         });
/*      */     this.jLabel1.setFont(new Font("Tahoma", 1, 12));
/*      */     this.jLabel1.setText("dx");
/*      */     this.txtDx.setFont(new Font("Tahoma", 1, 12));
/*      */     this.txtDx.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/*      */             PartScr.this.txtDxKeyPressed(evt);
/*      */           }
/*      */           
/*      */           public void keyReleased(KeyEvent evt) {
/*      */             PartScr.this.txtDxKeyReleased(evt);
/*      */           }
/*      */         });
/*      */     this.txtDy.setFont(new Font("Tahoma", 1, 12));
/*      */     this.txtDy.addKeyListener(new KeyAdapter() {
/*      */           public void keyPressed(KeyEvent evt) {
/*      */             PartScr.this.txtDyKeyPressed(evt);
/*      */           }
/*      */           
/*      */           public void keyReleased(KeyEvent evt) {
/*      */             PartScr.this.txtDyKeyReleased(evt);
/*      */           }
/*      */         });
/*      */     this.jLabel2.setFont(new Font("Tahoma", 1, 12));
/*      */     this.jLabel2.setText("dy");
/*      */     GroupLayout jPanel2Layout = new GroupLayout(this.jPanel2);
/*      */     this.jPanel2.setLayout(jPanel2Layout);
/*      */     jPanel2Layout.setHorizontalGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel2Layout.createSequentialGroup().addContainerGap().addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel2Layout.createSequentialGroup().addComponent((Component)this.button58, -1, 95, 32767).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent((Component)this.button59, -2, 98, -2).addGap(825, 825, 825)).addGroup(jPanel2Layout.createSequentialGroup().addComponent(this.panelPartModify, -1, -1, 32767).addContainerGap()).addGroup(jPanel2Layout.createSequentialGroup().addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel2Layout.createSequentialGroup().addComponent(this.jLabel1, -2, 96, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtDx, -2, 192, -2)).addGroup(jPanel2Layout.createSequentialGroup().addComponent(this.jLabel2, -2, 96, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.txtDy, -2, 192, -2))).addGap(0, 0, 32767)))));
/*      */     jPanel2Layout.setVerticalGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel2Layout.createSequentialGroup().addContainerGap().addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent((Component)this.button58, -2, 51, -2).addComponent((Component)this.button59, -2, 51, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.panelPartModify, -2, -1, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(this.jLabel1, -1, -1, 32767).addComponent(this.txtDx, -1, 39, 32767)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(this.jLabel2, -1, -1, 32767).addComponent(this.txtDy, -1, 39, 32767)).addContainerGap(355, 32767)));
/*      */     this.jTabbedPane1.addTab("Part modify", this.jPanel2);
/*      */     GroupLayout layout = new GroupLayout(getContentPane());
/*      */     getContentPane().setLayout(layout);
/*      */     layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jTabbedPane1));
/*      */     layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jTabbedPane1));
/*      */     pack();
/*      */   }
/*      */   
/*      */   private void button18ActionPerformed(ActionEvent evt) {
/*      */     try {
/*      */       this.dfHead = Part.getPart(Integer.parseInt(NotifyUtil.showInputDialog((JFrame)Main.I, "Id")), 0);
/*      */       fillIconPart();
/*      */     } catch (Exception exception) {}
/*      */   }
/*      */   
/*      */   private void button25ActionPerformed(ActionEvent evt) {
/*      */     try {
/*      */       this.dfBody = Part.getPart(Integer.parseInt(NotifyUtil.showInputDialog((JFrame)Main.I, "Id")), 1);
/*      */       fillIconPart();
/*      */     } catch (Exception exception) {}
/*      */   }
/*      */   
/*      */   private void button29ActionPerformed(ActionEvent evt) {
/*      */     try {
/*      */       this.dfLeg = Part.getPart(Integer.parseInt(NotifyUtil.showInputDialog((JFrame)Main.I, "Id")), 2);
/*      */       fillIconPart();
/*      */     } catch (Exception exception) {}
/*      */   }
/*      */   
/*      */   private void button24ActionPerformed(ActionEvent evt) {
/*      */     if (this.dfHead != null) {
/*      */       JSONArray dataArray = new JSONArray();
/*      */       for (PartInfo pi : this.dfHead.getPi()) {
/*      */         JSONArray ja = new JSONArray();
/*      */         ja.add(Integer.valueOf(pi.getIconId()));
/*      */         ja.add(Integer.valueOf(pi.getDx()));
/*      */         ja.add(Integer.valueOf(pi.getDy()));
/*      */         dataArray.add(ja.toJSONString());
/*      */       } 
/*      */       String data = dataArray.toJSONString();
/*      */       try {
/*      */         GirlkunResultSet rs = GirlkunDB.executeQuery("GIRLKUN", "select id from part order by id desc limit 1");
/*      */         int id = -1;
/*      */         if (rs.first())
/*      */           id = rs.getInt("id") + 1; 
/*      */         GirlkunDB.executeUpdate("GIRLKUN", "insert into part(id, type, data) values()", new Object[] { Integer.valueOf(id), Integer.valueOf(0), data });
/*      */         NotifyUtil.showMessageDialog((JFrame)Main.I, "Thêm mới part head thành công! (Id: " + id + ")");
/*      */       } catch (Exception exception) {}
/*      */     } 
/*      */   }
/*      */   
/*      */   private void button28ActionPerformed(ActionEvent evt) {
/*      */     if (this.dfBody != null) {
/*      */       JSONArray dataArray = new JSONArray();
/*      */       for (PartInfo pi : this.dfBody.getPi()) {
/*      */         JSONArray ja = new JSONArray();
/*      */         ja.add(Integer.valueOf(pi.getIconId()));
/*      */         ja.add(Integer.valueOf(pi.getDx()));
/*      */         ja.add(Integer.valueOf(pi.getDy()));
/*      */         dataArray.add(ja.toJSONString());
/*      */       } 
/*      */       String data = dataArray.toJSONString();
/*      */       try {
/*      */         GirlkunResultSet rs = GirlkunDB.executeQuery("GIRLKUN", "select id from part order by id desc limit 1");
/*      */         int id = -1;
/*      */         if (rs.first())
/*      */           id = rs.getInt("id") + 1; 
/*      */         GirlkunDB.executeUpdate("GIRLKUN", "insert into part(id, type, data) values()", new Object[] { Integer.valueOf(id), Integer.valueOf(1), data });
/*      */         NotifyUtil.showMessageDialog((JFrame)Main.I, "Thêm mới part body thành công! (Id: " + id + ")");
/*      */       } catch (Exception exception) {}
/*      */     } 
/*      */   }
/*      */   
/*      */   private void button31ActionPerformed(ActionEvent evt) {
/*      */     if (this.dfLeg != null) {
/*      */       JSONArray dataArray = new JSONArray();
/*      */       for (PartInfo pi : this.dfLeg.getPi()) {
/*      */         JSONArray ja = new JSONArray();
/*      */         ja.add(Integer.valueOf(pi.getIconId()));
/*      */         ja.add(Integer.valueOf(pi.getDx()));
/*      */         ja.add(Integer.valueOf(pi.getDy()));
/*      */         dataArray.add(ja.toJSONString());
/*      */       } 
/*      */       String data = dataArray.toJSONString();
/*      */       try {
/*      */         GirlkunResultSet rs = GirlkunDB.executeQuery("GIRLKUN", "select id from part order by id desc limit 1");
/*      */         int id = -1;
/*      */         if (rs.first())
/*      */           id = rs.getInt("id") + 1; 
/*      */         GirlkunDB.executeUpdate("GIRLKUN", "insert into part(id, type, data) values()", new Object[] { Integer.valueOf(id), Integer.valueOf(2), data });
/*      */         NotifyUtil.showMessageDialog((JFrame)Main.I, "Thêm mới part body thành công! (Id: " + id + ")");
/*      */       } catch (Exception exception) {}
/*      */     } 
/*      */   }
/*      */   
/*      */   private void button58ActionPerformed(ActionEvent evt) {
/*      */     try {
/*      */       this.partModify = Part.getPart(Integer.parseInt(NotifyUtil.showInputDialog((JFrame)Main.I, "Id")));
/*      */       for (int i = 0; i < 17; i++)
/*      */         ((Button)this.panelPartModify.getComponent(i)).setBackground(new Color(255, 204, 204)); 
/*      */       this.txtDx.setText("");
/*      */       this.txtDy.setText("");
/*      */       this.partInfo = null;
/*      */       fillIconPartModify();
/*      */     } catch (Exception exception) {}
/*      */   }
/*      */   
/*      */   private void button59ActionPerformed(ActionEvent evt) {
/*      */     savePart();
/*      */   }
/*      */   
/*      */   private void txtDxKeyPressed(KeyEvent evt) {
/*      */     if (evt.getKeyCode() == 10) {
/*      */       this.txtDx.setBackground(Color.WHITE);
/*      */       this.txtDx.setForeground(Color.BLACK);
/*      */     } else {
/*      */       this.txtDx.setBackground(new Color(255, 204, 204));
/*      */     } 
/*      */   }
/*      */   
/*      */   private void txtDxKeyReleased(KeyEvent evt) {
/*      */     if (evt.getKeyCode() == 10) {
/*      */       this.txtDx.setBackground(Color.WHITE);
/*      */       this.txtDx.setForeground(Color.BLACK);
/*      */       if (this.partInfo != null)
/*      */         this.partInfo.setDx(Integer.parseInt(this.txtDx.getText())); 
/*      */       savePart();
/*      */     } else {
/*      */       this.txtDx.setBackground(new Color(255, 204, 204));
/*      */     } 
/*      */   }
/*      */   
/*      */   private void txtDyKeyPressed(KeyEvent evt) {
/*      */     if (evt.getKeyCode() == 10) {
/*      */       this.txtDy.setBackground(Color.WHITE);
/*      */       this.txtDy.setForeground(Color.BLACK);
/*      */     } else {
/*      */       this.txtDy.setBackground(new Color(255, 204, 204));
/*      */     } 
/*      */   }
/*      */   
/*      */   private void txtDyKeyReleased(KeyEvent evt) {
/*      */     if (evt.getKeyCode() == 10) {
/*      */       this.txtDy.setBackground(Color.WHITE);
/*      */       this.txtDy.setForeground(Color.BLACK);
/*      */       if (this.partInfo != null)
/*      */         this.partInfo.setDy(Integer.parseInt(this.txtDy.getText())); 
/*      */       savePart();
/*      */     } else {
/*      */       this.txtDy.setBackground(new Color(255, 204, 204));
/*      */     } 
/*      */   }
/*      */   
/*      */   private void button19ActionPerformed(ActionEvent evt) {
/*      */     if (this.dfHead != null) {
/*      */       JSONArray dataArray = new JSONArray();
/*      */       for (PartInfo pi : this.dfHead.getPi()) {
/*      */         JSONArray ja = new JSONArray();
/*      */         ja.add(Integer.valueOf(pi.getIconId()));
/*      */         ja.add(Integer.valueOf(pi.getDx()));
/*      */         ja.add(Integer.valueOf(pi.getDy()));
/*      */         dataArray.add(ja.toJSONString());
/*      */       } 
/*      */       String data = dataArray.toJSONString();
/*      */       try {
/*      */         GirlkunDB.executeUpdate("GIRLKUN", "update part set data = ? where id = ? and type = ?", new Object[] { data, Integer.valueOf(this.dfHead.getId()), Integer.valueOf(this.dfHead.getType()) });
/*      */         NotifyUtil.showMessageDialog((JFrame)Main.I, "Lưu part head thành công!");
/*      */       } catch (Exception exception) {}
/*      */     } 
/*      */   }
/*      */   
/*      */   private void button26ActionPerformed(ActionEvent evt) {
/*      */     if (this.dfBody != null) {
/*      */       JSONArray dataArray = new JSONArray();
/*      */       for (PartInfo pi : this.dfBody.getPi()) {
/*      */         JSONArray ja = new JSONArray();
/*      */         ja.add(Integer.valueOf(pi.getIconId()));
/*      */         ja.add(Integer.valueOf(pi.getDx()));
/*      */         ja.add(Integer.valueOf(pi.getDy()));
/*      */         dataArray.add(ja.toJSONString());
/*      */       } 
/*      */       String data = dataArray.toJSONString();
/*      */       try {
/*      */         GirlkunDB.executeUpdate("GIRLKUN", "update part set data = ? where id = ? and type = ?", new Object[] { data, Integer.valueOf(this.dfBody.getId()), Integer.valueOf(this.dfBody.getType()) });
/*      */         NotifyUtil.showMessageDialog((JFrame)Main.I, "Lưu part head thành công!");
/*      */       } catch (Exception exception) {}
/*      */     } 
/*      */   }
/*      */   
/*      */   private void button30ActionPerformed(ActionEvent evt) {
/*      */     if (this.dfLeg != null) {
/*      */       JSONArray dataArray = new JSONArray();
/*      */       for (PartInfo pi : this.dfLeg.getPi()) {
/*      */         JSONArray ja = new JSONArray();
/*      */         ja.add(Integer.valueOf(pi.getIconId()));
/*      */         ja.add(Integer.valueOf(pi.getDx()));
/*      */         ja.add(Integer.valueOf(pi.getDy()));
/*      */         dataArray.add(ja.toJSONString());
/*      */       } 
/*      */       String data = dataArray.toJSONString();
/*      */       try {
/*      */         GirlkunDB.executeUpdate("GIRLKUN", "update part set data = ? where id = ? and type = ?", new Object[] { data, Integer.valueOf(this.dfLeg.getId()), Integer.valueOf(this.dfLeg.getType()) });
/*      */         NotifyUtil.showMessageDialog((JFrame)Main.I, "Lưu part head thành công!");
/*      */       } catch (Exception exception) {}
/*      */     } 
/*      */   }
/*      */   
/*      */   private void button32ActionPerformed(ActionEvent evt) {
/*      */     if (this.typeChose == -1 || this.indexChose == -1)
/*      */       return; 
/*      */     JFileChooser fileChooserImage = new JFileChooser(this.pathCache);
/*      */     fileChooserImage.setFileFilter(new FileNameExtensionFilter("imaga", new String[] { "png" }));
/*      */     if (fileChooserImage.showOpenDialog((Component)Main.I) == 0)
/*      */       try {
/*      */         String path = fileChooserImage.getSelectedFile().getAbsoluteFile().getAbsolutePath();
/*      */         this.pathCache = path.substring(0, path.lastIndexOf("\\"));
/*      */         BufferedImage image = ImageIO.read(fileChooserImage.getSelectedFile());
/*      */         int iconId = Integer.parseInt(fileChooserImage.getSelectedFile().getName().substring(0, fileChooserImage.getSelectedFile().getName().lastIndexOf(".")));
/*      */         switch (this.typeChose) {
/*      */           case 0:
/*      */             this.dfHead.getPi()[this.indexChose].setIconId(iconId);
/*      */             break;
/*      */           case 1:
/*      */             this.dfBody.getPi()[this.indexChose].setIconId(iconId);
/*      */             break;
/*      */           case 2:
/*      */             this.dfLeg.getPi()[this.indexChose].setIconId(iconId);
/*      */             break;
/*      */         } 
/*      */         fillIconPart();
/*      */       } catch (IOException ex) {
/*      */         ex.printStackTrace();
/*      */       }  
/*      */   }
/*      */   
/*      */   private void button33ActionPerformed(ActionEvent evt) {
/*      */     this.f++;
/*      */     if (this.f > 16)
/*      */       this.f = 0; 
/*      */     this.lblF.setText(this.f + "");
/*      */   }
/*      */   
/*      */   private void button34ActionPerformed(ActionEvent evt) {
/*      */     this.f--;
/*      */     if (this.f < 0)
/*      */       this.f = 16; 
/*      */     this.lblF.setText(this.f + "");
/*      */   }
/*      */   
/*      */   private void savePart() {
/*      */     if (this.partModify != null) {
/*      */       JSONArray dataArray = new JSONArray();
/*      */       for (PartInfo pi : this.partModify.getPi()) {
/*      */         JSONArray ja = new JSONArray();
/*      */         ja.add(Integer.valueOf(pi.getIconId()));
/*      */         ja.add(Integer.valueOf(pi.getDx()));
/*      */         ja.add(Integer.valueOf(pi.getDy()));
/*      */         dataArray.add(ja.toJSONString());
/*      */       } 
/*      */       String data = dataArray.toJSONString();
/*      */       try {
/*      */         GirlkunDB.executeUpdate("GIRLKUN", "update part set data = ? where id = ? and type = ?", new Object[] { data, Integer.valueOf(this.partModify.getId()), Integer.valueOf(this.partModify.getType()) });
/*      */         System.out.println("update part set data = ? where id = ? and type = ?\n" + data + "," + this.partModify.getId() + "," + this.partModify.getType());
/*      */         System.out.println("done save part");
/*      */       } catch (Exception e) {
/*      */         e.printStackTrace();
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private void setup() {
/*      */     setTitle("Girlkun75 - Quản lý part");
/*      */     setResizable(false);
/*      */     try {
/*      */       this.dfHead = Part.getPart(0, 0);
/*      */       this.dfBody = Part.getPart(1, 1);
/*      */       this.dfLeg = Part.getPart(2, 2);
/*      */     } catch (Exception exception) {}
/*      */     int i;
/*      */     for (i = 0; i < 17; i++)
/*      */       addEventButton2((Button)this.panelPartModify.getComponent(i), i); 
/*      */     for (i = 0; i < 3; i++)
/*      */       addEventButton((Button)this.panelHead.getComponent(i), i, 0); 
/*      */     for (i = 0; i < 17; i++)
/*      */       addEventButton((Button)this.panelBody.getComponent(i), i, 1); 
/*      */     for (i = 0; i < 14; i++)
/*      */       addEventButton((Button)this.panelLeg.getComponent(i), i, 2); 
/*      */     fillIconPart();
/*      */   }
/*      */   
/*      */   private void fillIconPart() {
/*      */     if (this.dfHead != null)
/*      */       for (int i = 0; i < (this.dfHead.getPi()).length; i++)
/*      */         ((Button)this.panelHead.getComponent(i)).setIcon(new ImageIcon(this.dfHead.getPi()[i].getImageIcon()));  
/*      */     if (this.dfBody != null)
/*      */       for (int i = 0; i < (this.dfBody.getPi()).length; i++)
/*      */         ((Button)this.panelBody.getComponent(i)).setIcon(new ImageIcon(this.dfBody.getPi()[i].getImageIcon()));  
/*      */     if (this.dfLeg != null)
/*      */       for (int i = 0; i < (this.dfLeg.getPi()).length; i++)
/*      */         ((Button)this.panelLeg.getComponent(i)).setIcon(new ImageIcon(this.dfLeg.getPi()[i].getImageIcon()));  
/*      */   }
/*      */   
/*      */   private void fillIconPartModify() {
/*      */     if (this.partModify != null)
/*      */       for (int i = 0; i < 17; i++) {
/*      */         try {
/*      */           ((Button)this.panelPartModify.getComponent(i)).setIcon(new ImageIcon(this.partModify.getPi()[i].getImageIcon()));
/*      */         } catch (Exception e) {
/*      */           ((Button)this.panelPartModify.getComponent(i)).setIcon(null);
/*      */         } 
/*      */       }  
/*      */   }
/*      */   
/*      */   private void addEventButton2(final Button button, final int index) {
/*      */     button.addActionListener(new ActionListener() {
/*      */           public void actionPerformed(ActionEvent e) {
/*      */             for (int i = 0; i < 17; i++)
/*      */               ((Button)PartScr.this.panelPartModify.getComponent(i)).setBackground(new Color(255, 204, 204)); 
/*      */             button.setBackground(Color.red);
/*      */             if (PartScr.this.partModify != null)
/*      */               try {
/*      */                 PartScr.this.partInfo = PartScr.this.partModify.getPi()[index];
/*      */                 PartScr.this.txtDx.setText(PartScr.this.partInfo.getDx() + "");
/*      */                 PartScr.this.txtDy.setText(PartScr.this.partInfo.getDy() + "");
/*      */               } catch (Exception exception) {} 
/*      */           }
/*      */         });
/*      */   }
/*      */ }


/* Location:              D:\nro\server_luxu_nrp\vemap\GirlkunToolCBRO.jar!\com\girlkun\tool\screens\part_scr\PartScr.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */