/*    */ package com.girlkun.tool.screens.part_scr.models;
/*    */ 
/*    */ import com.girlkun.database.GirlkunDB;
/*    */ import com.girlkun.result.GirlkunResultSet;
/*    */ import java.util.Arrays;
/*    */ import org.json.simple.JSONArray;
/*    */ import org.json.simple.JSONValue;
/*    */ 
/*    */ public class Part {
/*    */   private int id;
/*    */   private int type;
/*    */   private PartInfo[] pi;
/*    */   
/*    */   public void setId(int id) {
/* 15 */     this.id = id; } public void setType(int type) { this.type = type; } public void setPi(PartInfo[] pi) { this.pi = pi; } public boolean equals(Object o) { if (o == this) return true;  if (!(o instanceof Part)) return false;  Part other = (Part)o; return !other.canEqual(this) ? false : ((getId() != other.getId()) ? false : ((getType() != other.getType()) ? false : (!!Arrays.deepEquals((Object[])getPi(), (Object[])other.getPi())))); } protected boolean canEqual(Object other) { return other instanceof Part; } public int hashCode() { int PRIME = 59; result = 1; result = result * 59 + getId(); result = result * 59 + getType(); return result * 59 + Arrays.deepHashCode((Object[])getPi()); } public String toString() {
/* 16 */     return "Part(id=" + getId() + ", type=" + getType() + ", pi=" + Arrays.deepToString((Object[])getPi()) + ")";
/*    */   }
/*    */   
/* 19 */   public int getId() { return this.id; }
/* 20 */   public int getType() { return this.type; } public PartInfo[] getPi() {
/* 21 */     return this.pi;
/*    */   }
/*    */   public Part(int id, int type) {
/* 24 */     this.id = id;
/* 25 */     this.type = type;
/* 26 */     if (type == 0) {
/* 27 */       this.pi = new PartInfo[3];
/* 28 */     } else if (type == 1) {
/* 29 */       this.pi = new PartInfo[17];
/* 30 */     } else if (type == 2) {
/* 31 */       this.pi = new PartInfo[14];
/*    */     } 
/*    */   }
/*    */   
/*    */   public static Part getPart(int id, int type) throws Exception {
/* 36 */     Part part = null;
/*    */     try {
/* 38 */       JSONArray dataArray = null;
/* 39 */       JSONValue jv = new JSONValue();
/* 40 */       GirlkunResultSet rs = GirlkunDB.executeQuery("GIRLKUN", "select * from part where id = ? and type = ?", new Object[] { Integer.valueOf(id), Integer.valueOf(type) });
/* 41 */       if (rs.first()) {
/* 42 */         part = new Part(id, rs.getInt("type"));
/* 43 */         dataArray = (JSONArray)JSONValue.parse(rs.getString("data"));
/* 44 */         for (int i = 0; i < part.pi.length; i++) {
/* 45 */           JSONArray data = (JSONArray)JSONValue.parse(String.valueOf(dataArray.get(i)));
/*    */           
/* 47 */           part.pi[i] = new PartInfo(Integer.parseInt(String.valueOf(data.get(0))), 
/* 48 */               Integer.parseInt(String.valueOf(data.get(1))), 
/* 49 */               Integer.parseInt(String.valueOf(data.get(2))));
/*    */         } 
/*    */       } 
/* 52 */     } catch (Exception e) {
/* 53 */       throw e;
/*    */     } 
/* 55 */     return part;
/*    */   }
/*    */   
/*    */   public static Part getPart(int id) throws Exception {
/* 59 */     Part part = null;
/*    */     try {
/* 61 */       JSONArray dataArray = null;
/* 62 */       JSONValue jv = new JSONValue();
/* 63 */       GirlkunResultSet rs = GirlkunDB.executeQuery("GIRLKUN", "select * from part where id = ?", new Object[] { Integer.valueOf(id) });
/* 64 */       if (rs.first()) {
/* 65 */         part = new Part(id, rs.getInt("type"));
/* 66 */         dataArray = (JSONArray)JSONValue.parse(rs.getString("data"));
/* 67 */         for (int i = 0; i < part.pi.length; i++) {
/* 68 */           JSONArray data = (JSONArray)JSONValue.parse(String.valueOf(dataArray.get(i)));
/*    */           
/* 70 */           part.pi[i] = new PartInfo(Integer.parseInt(String.valueOf(data.get(0))), 
/* 71 */               Integer.parseInt(String.valueOf(data.get(1))), 
/* 72 */               Integer.parseInt(String.valueOf(data.get(2))));
/*    */         } 
/*    */       } 
/* 75 */     } catch (Exception e) {
/* 76 */       throw e;
/*    */     } 
/* 78 */     return part;
/*    */   }
/*    */ }


/* Location:              D:\nro\server_luxu_nrp\vemap\GirlkunToolCBRO.jar!\com\girlkun\tool\screens\part_scr\models\Part.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */