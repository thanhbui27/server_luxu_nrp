/*     */ package com.girlkun.tool.mainz;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.awt.image.ImageObserver;
/*     */ import javax.swing.JPanel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Screen
/*     */   extends JPanel
/*     */   implements Runnable
/*     */ {
/*     */   private int width;
/*     */   private int height;
/*     */   private boolean start;
/*     */   private Thread loop;
/*     */   private BufferedImage imageScreen;
/*     */   private Graphics2D screenGrph;
/*     */   
/*     */   public Screen(int w, int h) {
/*  61 */     this.width = w;
/*  62 */     this.height = h;
/*     */     
/*  64 */     setPreferredSize(new Dimension(w, h));
/*  65 */     init();
/*  66 */     start();
/*     */   }
/*     */   
/*     */   private void init() {
/*  70 */     this.loop = new Thread(this);
/*  71 */     this.imageScreen = new BufferedImage(this.width, this.height, 2);
/*  72 */     this.screenGrph = this.imageScreen.createGraphics();
/*     */   }
/*     */   
/*     */   private void start() {
/*  76 */     if (!this.start) {
/*  77 */       this.start = true;
/*  78 */       this.loop.start();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void update() {}
/*     */ 
/*     */ 
/*     */   
/*     */   private void paint() {
/*  89 */     this.screenGrph.setColor(Color.WHITE);
/*  90 */     this.screenGrph.fillRect(0, 0, this.width, this.height);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  95 */     Graphics2D g2 = (Graphics2D)getGraphics();
/*  96 */     g2.drawImage(this.imageScreen, 0, 0, (ImageObserver)null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void run() {
/* 101 */     while (this.start) {
/*     */       try {
/* 103 */         update();
/* 104 */         paint();
/* 105 */         Thread.sleep(5L);
/* 106 */       } catch (Exception exception) {}
/*     */     } 
/*     */   }
/*     */ }


/* Location:              D:\nro\server_luxu_nrp\vemap\GirlkunToolCBRO.jar!\com\girlkun\tool\mainz\Screen.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */