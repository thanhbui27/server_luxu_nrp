/*    */ package com.girlkun.tool.mainz;
/*    */ 
/*    */ import org.json.simple.JSONArray;
/*    */ import org.json.simple.JSONValue;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class App
/*    */ {
/*    */   private static final int WIDTH = 750;
/*    */   private static final int HEIGHT = 400;
/*    */   
/*    */   public static void main(String[] args) {
/* 24 */     String text = "[\"[4,5]\",\"[4,5]\",\"[4,5]\",\"[4,5]\"]";
/*    */     
/* 26 */     JSONValue jv = new JSONValue();
/* 27 */     JSONArray ja = (JSONArray)JSONValue.parse(text);
/* 28 */     System.out.println(ja.toJSONString().equals(text));
/*    */   }
/*    */ }


/* Location:              D:\nro\server_luxu_nrp\vemap\GirlkunToolCBRO.jar!\com\girlkun\tool\mainz\App.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */