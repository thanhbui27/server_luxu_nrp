/*    */ package com.girlkun.tool.entities.item;
/*    */ 
/*    */ 
/*    */ public class ItemTemplate
/*    */ {
/*    */   private int id;
/*    */   private int type;
/*    */   private int gender;
/*    */   private String name;
/*    */   private String description;
/*    */   
/*    */   public void setId(int id) {
/* 13 */     this.id = id; } private int iconId; private int part; private boolean isUpToUp; private long powerRequire; private int gold; private int gem; public void setType(int type) { this.type = type; } public void setGender(int gender) { this.gender = gender; } public void setName(String name) { this.name = name; } public void setDescription(String description) { this.description = description; } public void setIconId(int iconId) { this.iconId = iconId; } public void setPart(int part) { this.part = part; } public void setUpToUp(boolean isUpToUp) { this.isUpToUp = isUpToUp; } public void setPowerRequire(long powerRequire) { this.powerRequire = powerRequire; } public void setGold(int gold) { this.gold = gold; } public void setGem(int gem) { this.gem = gem; } public boolean equals(Object o) { if (o == this) return true;  if (!(o instanceof ItemTemplate)) return false;  ItemTemplate other = (ItemTemplate)o; if (!other.canEqual(this)) return false;  if (getId() != other.getId()) return false;  if (getType() != other.getType()) return false;  if (getGender() != other.getGender()) return false;  if (getIconId() != other.getIconId()) return false;  if (getPart() != other.getPart()) return false;  if (isUpToUp() != other.isUpToUp()) return false;  if (getPowerRequire() != other.getPowerRequire()) return false;  if (getGold() != other.getGold()) return false;  if (getGem() != other.getGem()) return false;  Object this$name = getName(), other$name = other.getName(); if ((this$name == null) ? (other$name != null) : !this$name.equals(other$name)) return false;  Object this$description = getDescription(), other$description = other.getDescription(); return !((this$description == null) ? (other$description != null) : !this$description.equals(other$description)); } protected boolean canEqual(Object other) { return other instanceof ItemTemplate; } public int hashCode() { int PRIME = 59; result = 1; result = result * 59 + getId(); result = result * 59 + getType(); result = result * 59 + getGender(); result = result * 59 + getIconId(); result = result * 59 + getPart(); result = result * 59 + (isUpToUp() ? 79 : 97); long $powerRequire = getPowerRequire(); result = result * 59 + (int)($powerRequire >>> 32L ^ $powerRequire); result = result * 59 + getGold(); result = result * 59 + getGem(); Object $name = getName(); result = result * 59 + (($name == null) ? 43 : $name.hashCode()); Object $description = getDescription(); return result * 59 + (($description == null) ? 43 : $description.hashCode()); } public ItemTemplate(int id, int type, int gender, String name, String description, int iconId, int part, boolean isUpToUp, long powerRequire, int gold, int gem) {
/* 14 */     this.id = id; this.type = type; this.gender = gender; this.name = name; this.description = description; this.iconId = iconId; this.part = part; this.isUpToUp = isUpToUp; this.powerRequire = powerRequire; this.gold = gold; this.gem = gem;
/*    */   } public ItemTemplate() {} public String toString() {
/* 16 */     return "ItemTemplate(id=" + getId() + ", type=" + getType() + ", gender=" + getGender() + ", name=" + getName() + ", description=" + getDescription() + ", iconId=" + getIconId() + ", part=" + getPart() + ", isUpToUp=" + isUpToUp() + ", powerRequire=" + getPowerRequire() + ", gold=" + getGold() + ", gem=" + getGem() + ")";
/*    */   }
/*    */   
/* 19 */   public int getId() { return this.id; }
/* 20 */   public int getType() { return this.type; }
/* 21 */   public int getGender() { return this.gender; }
/* 22 */   public String getName() { return this.name; }
/* 23 */   public String getDescription() { return this.description; }
/* 24 */   public int getIconId() { return this.iconId; }
/* 25 */   public int getPart() { return this.part; }
/* 26 */   public boolean isUpToUp() { return this.isUpToUp; }
/* 27 */   public long getPowerRequire() { return this.powerRequire; }
/* 28 */   public int getGold() { return this.gold; } public int getGem() {
/* 29 */     return this.gem;
/*    */   }
/*    */ }


/* Location:              D:\nro\server_luxu_nrp\vemap\GirlkunToolCBRO.jar!\com\girlkun\tool\entities\item\ItemTemplate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */