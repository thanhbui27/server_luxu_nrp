/*    */ package com.girlkun.tool.entities.item;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ItemOptionTemplate
/*    */ {
/*    */   private int id;
/*    */   private String name;
/*    */   
/*    */   public void setId(int id) {
/* 12 */     this.id = id; } public void setName(String name) { this.name = name; } public boolean equals(Object o) { if (o == this) return true;  if (!(o instanceof ItemOptionTemplate)) return false;  ItemOptionTemplate other = (ItemOptionTemplate)o; if (!other.canEqual(this)) return false;  if (getId() != other.getId()) return false;  Object this$name = getName(), other$name = other.getName(); return !((this$name == null) ? (other$name != null) : !this$name.equals(other$name)); } protected boolean canEqual(Object other) { return other instanceof ItemOptionTemplate; } public int hashCode() { int PRIME = 59; result = 1; result = result * 59 + getId(); Object $name = getName(); return result * 59 + (($name == null) ? 43 : $name.hashCode()); } public String toString() { return "ItemOptionTemplate(id=" + getId() + ", name=" + getName() + ")"; } public ItemOptionTemplate(int id, String name) {
/* 13 */     this.id = id; this.name = name;
/*    */   }
/*    */   
/*    */   public ItemOptionTemplate() {}
/* 17 */   public int getId() { return this.id; } public String getName() {
/* 18 */     return this.name;
/*    */   }
/*    */ }


/* Location:              D:\nro\server_luxu_nrp\vemap\GirlkunToolCBRO.jar!\com\girlkun\tool\entities\item\ItemOptionTemplate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */