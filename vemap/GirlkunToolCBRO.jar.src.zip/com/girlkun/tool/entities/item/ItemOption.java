/*    */ package com.girlkun.tool.entities.item;
/*    */ 
/*    */ import com.girlkun.tool.main.Manager;
/*    */ 
/*    */ public class ItemOption
/*    */ {
/*    */   private ItemOptionTemplate itemOptionTemplate;
/*    */   private int param;
/*    */   
/*    */   public void setItemOptionTemplate(ItemOptionTemplate itemOptionTemplate) {
/* 11 */     this.itemOptionTemplate = itemOptionTemplate; } public void setParam(int param) { this.param = param; } public boolean equals(Object o) { if (o == this) return true;  if (!(o instanceof ItemOption)) return false;  ItemOption other = (ItemOption)o; if (!other.canEqual(this)) return false;  if (getParam() != other.getParam()) return false;  Object this$itemOptionTemplate = getItemOptionTemplate(), other$itemOptionTemplate = other.getItemOptionTemplate(); return !((this$itemOptionTemplate == null) ? (other$itemOptionTemplate != null) : !this$itemOptionTemplate.equals(other$itemOptionTemplate)); } protected boolean canEqual(Object other) { return other instanceof ItemOption; } public int hashCode() { int PRIME = 59; result = 1; result = result * 59 + getParam(); Object $itemOptionTemplate = getItemOptionTemplate(); return result * 59 + (($itemOptionTemplate == null) ? 43 : $itemOptionTemplate.hashCode()); } public String toString() { return "ItemOption(itemOptionTemplate=" + getItemOptionTemplate() + ", param=" + getParam() + ")"; }
/*    */ 
/*    */   
/* 14 */   public ItemOptionTemplate getItemOptionTemplate() { return this.itemOptionTemplate; } public int getParam() {
/* 15 */     return this.param;
/*    */   }
/*    */   public ItemOption(int optionId, int param) {
/* 18 */     this.itemOptionTemplate = Manager.gI().getItemOptionTemplates().get(optionId);
/* 19 */     this.param = param;
/*    */   }
/*    */ }


/* Location:              D:\nro\server_luxu_nrp\vemap\GirlkunToolCBRO.jar!\com\girlkun\tool\entities\item\ItemOption.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */