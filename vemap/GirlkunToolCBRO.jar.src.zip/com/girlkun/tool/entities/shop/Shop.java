/*    */ package com.girlkun.tool.entities.shop;
/*    */ 
/*    */ import com.girlkun.tool.entities.map.NpcTemplate;
/*    */ import com.girlkun.tool.main.Manager;
/*    */ import java.util.List;
/*    */ 
/*    */ public class Shop {
/*    */   private int id;
/*    */   private NpcTemplate npc;
/*    */   private String tagName;
/*    */   private int typeShop;
/*    */   private List<TabShop> tabShops;
/*    */   
/* 14 */   public void setId(int id) { this.id = id; } public void setNpc(NpcTemplate npc) { this.npc = npc; } public void setTagName(String tagName) { this.tagName = tagName; } public void setTypeShop(int typeShop) { this.typeShop = typeShop; } public void setTabShops(List<TabShop> tabShops) { this.tabShops = tabShops; } public boolean equals(Object o) { if (o == this) return true;  if (!(o instanceof Shop)) return false;  Shop other = (Shop)o; if (!other.canEqual(this)) return false;  if (getId() != other.getId()) return false;  if (getTypeShop() != other.getTypeShop()) return false;  Object this$npc = getNpc(), other$npc = other.getNpc(); if ((this$npc == null) ? (other$npc != null) : !this$npc.equals(other$npc)) return false;  Object this$tagName = getTagName(), other$tagName = other.getTagName(); if ((this$tagName == null) ? (other$tagName != null) : !this$tagName.equals(other$tagName)) return false;  Object<TabShop> this$tabShops = (Object<TabShop>)getTabShops(), other$tabShops = (Object<TabShop>)other.getTabShops(); return !((this$tabShops == null) ? (other$tabShops != null) : !this$tabShops.equals(other$tabShops)); } protected boolean canEqual(Object other) { return other instanceof Shop; } public int hashCode() { int PRIME = 59; result = 1; result = result * 59 + getId(); result = result * 59 + getTypeShop(); Object $npc = getNpc(); result = result * 59 + (($npc == null) ? 43 : $npc.hashCode()); Object $tagName = getTagName(); result = result * 59 + (($tagName == null) ? 43 : $tagName.hashCode()); Object<TabShop> $tabShops = (Object<TabShop>)getTabShops(); return result * 59 + (($tabShops == null) ? 43 : $tabShops.hashCode()); } public String toString() { return "Shop(id=" + getId() + ", npc=" + getNpc() + ", tagName=" + getTagName() + ", typeShop=" + getTypeShop() + ", tabShops=" + getTabShops() + ")"; }
/*    */ 
/*    */   
/* 17 */   public int getId() { return this.id; }
/* 18 */   public NpcTemplate getNpc() { return this.npc; }
/* 19 */   public String getTagName() { return this.tagName; }
/* 20 */   public int getTypeShop() { return this.typeShop; } public List<TabShop> getTabShops() {
/* 21 */     return this.tabShops;
/*    */   }
/*    */   public Shop(int id, int npcId, String tagName, int typeShop) {
/* 24 */     this.id = id;
/*    */     try {
/* 26 */       this.npc = Manager.gI().getNpcTemplateById(npcId);
/* 27 */     } catch (Exception exception) {}
/*    */     
/* 29 */     this.tagName = tagName;
/* 30 */     this.typeShop = typeShop;
/* 31 */     this.tabShops = new ArrayList<>();
/*    */   }
/*    */ }


/* Location:              D:\nro\server_luxu_nrp\vemap\GirlkunToolCBRO.jar!\com\girlkun\tool\entities\shop\Shop.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */