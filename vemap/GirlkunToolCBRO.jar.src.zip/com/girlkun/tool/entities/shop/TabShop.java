/*    */ package com.girlkun.tool.entities.shop;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class TabShop {
/*    */   private Shop shop;
/*    */   private int id;
/*    */   private String name;
/*    */   private List<ItemShop> items;
/*    */   
/* 12 */   public void setShop(Shop shop) { this.shop = shop; } public void setId(int id) { this.id = id; } public void setName(String name) { this.name = name; } public void setItems(List<ItemShop> items) { this.items = items; } public boolean equals(Object o) { if (o == this) return true;  if (!(o instanceof TabShop)) return false;  TabShop other = (TabShop)o; if (!other.canEqual(this)) return false;  if (getId() != other.getId()) return false;  Object this$shop = getShop(), other$shop = other.getShop(); if ((this$shop == null) ? (other$shop != null) : !this$shop.equals(other$shop)) return false;  Object this$name = getName(), other$name = other.getName(); if ((this$name == null) ? (other$name != null) : !this$name.equals(other$name)) return false;  Object<ItemShop> this$items = (Object<ItemShop>)getItems(), other$items = (Object<ItemShop>)other.getItems(); return !((this$items == null) ? (other$items != null) : !this$items.equals(other$items)); } protected boolean canEqual(Object other) { return other instanceof TabShop; } public int hashCode() { int PRIME = 59; result = 1; result = result * 59 + getId(); Object $shop = getShop(); result = result * 59 + (($shop == null) ? 43 : $shop.hashCode()); Object $name = getName(); result = result * 59 + (($name == null) ? 43 : $name.hashCode()); Object<ItemShop> $items = (Object<ItemShop>)getItems(); return result * 59 + (($items == null) ? 43 : $items.hashCode()); } public String toString() { return "TabShop(shop=" + getShop() + ", id=" + getId() + ", name=" + getName() + ", items=" + getItems() + ")"; }
/*    */ 
/*    */   
/* 15 */   public Shop getShop() { return this.shop; }
/* 16 */   public int getId() { return this.id; }
/* 17 */   public String getName() { return this.name; } public List<ItemShop> getItems() {
/* 18 */     return this.items;
/*    */   }
/*    */   public TabShop(Shop shop, int id, String name) {
/* 21 */     this.shop = shop;
/* 22 */     this.id = id;
/* 23 */     this.name = name;
/* 24 */     this.items = new ArrayList<>();
/*    */   }
/*    */ }


/* Location:              D:\nro\server_luxu_nrp\vemap\GirlkunToolCBRO.jar!\com\girlkun\tool\entities\shop\TabShop.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */