/*    */ package com.girlkun.tool.entities.shop;
/*    */ 
/*    */ import com.girlkun.tool.entities.item.ItemOption;
/*    */ import com.girlkun.tool.entities.item.ItemTemplate;
/*    */ import com.girlkun.tool.main.Manager;
/*    */ import java.util.List;
/*    */ 
/*    */ public class ItemShop {
/*    */   private TabShop tabShop;
/*    */   private int id;
/*    */   private ItemTemplate itemTemplate;
/*    */   private boolean isNew;
/*    */   private boolean isSell;
/*    */   
/* 15 */   public void setTabShop(TabShop tabShop) { this.tabShop = tabShop; } private int typeSell; private int cost; private long createTime; private List<ItemOption> options; private ItemTemplate itemSpec; public void setId(int id) { this.id = id; } public void setItemTemplate(ItemTemplate itemTemplate) { this.itemTemplate = itemTemplate; } public void setNew(boolean isNew) { this.isNew = isNew; } public void setSell(boolean isSell) { this.isSell = isSell; } public void setTypeSell(int typeSell) { this.typeSell = typeSell; } public void setCost(int cost) { this.cost = cost; } public void setCreateTime(long createTime) { this.createTime = createTime; } public void setOptions(List<ItemOption> options) { this.options = options; } public void setItemSpec(ItemTemplate itemSpec) { this.itemSpec = itemSpec; } public boolean equals(Object o) { if (o == this) return true;  if (!(o instanceof ItemShop)) return false;  ItemShop other = (ItemShop)o; if (!other.canEqual(this)) return false;  if (getId() != other.getId()) return false;  if (isNew() != other.isNew()) return false;  if (isSell() != other.isSell()) return false;  if (getTypeSell() != other.getTypeSell()) return false;  if (getCost() != other.getCost()) return false;  if (getCreateTime() != other.getCreateTime()) return false;  Object this$tabShop = getTabShop(), other$tabShop = other.getTabShop(); if ((this$tabShop == null) ? (other$tabShop != null) : !this$tabShop.equals(other$tabShop)) return false;  Object this$itemTemplate = getItemTemplate(), other$itemTemplate = other.getItemTemplate(); if ((this$itemTemplate == null) ? (other$itemTemplate != null) : !this$itemTemplate.equals(other$itemTemplate)) return false;  Object<ItemOption> this$options = (Object<ItemOption>)getOptions(), other$options = (Object<ItemOption>)other.getOptions(); if ((this$options == null) ? (other$options != null) : !this$options.equals(other$options)) return false;  Object this$itemSpec = getItemSpec(), other$itemSpec = other.getItemSpec(); return !((this$itemSpec == null) ? (other$itemSpec != null) : !this$itemSpec.equals(other$itemSpec)); } protected boolean canEqual(Object other) { return other instanceof ItemShop; } public int hashCode() { int PRIME = 59; result = 1; result = result * 59 + getId(); result = result * 59 + (isNew() ? 79 : 97); result = result * 59 + (isSell() ? 79 : 97); result = result * 59 + getTypeSell(); result = result * 59 + getCost(); long $createTime = getCreateTime(); result = result * 59 + (int)($createTime >>> 32L ^ $createTime); Object $tabShop = getTabShop(); result = result * 59 + (($tabShop == null) ? 43 : $tabShop.hashCode()); Object $itemTemplate = getItemTemplate(); result = result * 59 + (($itemTemplate == null) ? 43 : $itemTemplate.hashCode()); Object<ItemOption> $options = (Object<ItemOption>)getOptions(); result = result * 59 + (($options == null) ? 43 : $options.hashCode()); Object $itemSpec = getItemSpec(); return result * 59 + (($itemSpec == null) ? 43 : $itemSpec.hashCode()); } public String toString() { return "ItemShop(tabShop=" + getTabShop() + ", id=" + getId() + ", itemTemplate=" + getItemTemplate() + ", isNew=" + isNew() + ", isSell=" + isSell() + ", typeSell=" + getTypeSell() + ", cost=" + getCost() + ", createTime=" + getCreateTime() + ", options=" + getOptions() + ", itemSpec=" + getItemSpec() + ")"; }
/*    */ 
/*    */   
/* 18 */   public TabShop getTabShop() { return this.tabShop; }
/* 19 */   public int getId() { return this.id; }
/* 20 */   public ItemTemplate getItemTemplate() { return this.itemTemplate; }
/* 21 */   public boolean isNew() { return this.isNew; }
/* 22 */   public boolean isSell() { return this.isSell; }
/* 23 */   public int getTypeSell() { return this.typeSell; }
/* 24 */   public int getCost() { return this.cost; }
/* 25 */   public long getCreateTime() { return this.createTime; }
/* 26 */   public List<ItemOption> getOptions() { return this.options; } public ItemTemplate getItemSpec() {
/* 27 */     return this.itemSpec;
/*    */   }
/*    */   public ItemShop(TabShop tabShop, int id, int tempId, boolean isNew, boolean isSell, int typeSell, int cost, ItemTemplate itemSpec, long createTime) {
/* 30 */     this.tabShop = tabShop;
/* 31 */     this.id = id;
/* 32 */     this.itemTemplate = Manager.gI().getItemTemplates().get(tempId);
/* 33 */     this.isNew = isNew;
/* 34 */     this.isSell = isSell;
/* 35 */     this.typeSell = typeSell;
/* 36 */     this.cost = cost;
/* 37 */     this.itemSpec = itemSpec;
/* 38 */     this.createTime = createTime;
/* 39 */     this.options = new ArrayList<>();
/*    */   }
/*    */ }


/* Location:              D:\nro\server_luxu_nrp\vemap\GirlkunToolCBRO.jar!\com\girlkun\tool\entities\shop\ItemShop.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */