/*    */ package com.girlkun.tool.entities.map;
/*    */ 
/*    */ import com.girlkun.tool.utils.Util;
/*    */ import java.awt.image.BufferedImage;
/*    */ 
/*    */ public class BgItemTemplate {
/*    */   private BufferedImage image;
/*    */   private int id;
/*    */   private int imageId;
/*    */   private int layer;
/*    */   private int dx;
/*    */   private int dy;
/*    */   
/*    */   public void setImage(BufferedImage image) {
/* 15 */     this.image = image; } public void setId(int id) { this.id = id; } public void setImageId(int imageId) { this.imageId = imageId; } public void setLayer(int layer) { this.layer = layer; } public void setDx(int dx) { this.dx = dx; } public void setDy(int dy) { this.dy = dy; } public boolean equals(Object o) { if (o == this) return true;  if (!(o instanceof BgItemTemplate)) return false;  BgItemTemplate other = (BgItemTemplate)o; if (!other.canEqual(this)) return false;  if (getId() != other.getId()) return false;  if (getImageId() != other.getImageId()) return false;  if (getLayer() != other.getLayer()) return false;  if (getDx() != other.getDx()) return false;  if (getDy() != other.getDy()) return false;  Object this$image = getImage(), other$image = other.getImage(); return !((this$image == null) ? (other$image != null) : !this$image.equals(other$image)); } protected boolean canEqual(Object other) { return other instanceof BgItemTemplate; } public int hashCode() { int PRIME = 59; result = 1; result = result * 59 + getId(); result = result * 59 + getImageId(); result = result * 59 + getLayer(); result = result * 59 + getDx(); result = result * 59 + getDy(); Object $image = getImage(); return result * 59 + (($image == null) ? 43 : $image.hashCode()); } public String toString() {
/* 16 */     return "BgItemTemplate(image=" + getImage() + ", id=" + getId() + ", imageId=" + getImageId() + ", layer=" + getLayer() + ", dx=" + getDx() + ", dy=" + getDy() + ")";
/*    */   }
/*    */ 
/*    */   
/*    */   public int getId() {
/* 21 */     return this.id;
/*    */   } public int getImageId() {
/* 23 */     return this.imageId;
/*    */   } public int getLayer() {
/* 25 */     return this.layer;
/*    */   } public int getDx() {
/* 27 */     return this.dx;
/*    */   } public int getDy() {
/* 29 */     return this.dy;
/*    */   }
/*    */   public BufferedImage getImage() {
/* 32 */     if (this.image == null) {
/*    */       try {
/* 34 */         this.image = Util.getBgImageById(this.imageId, 1);
/* 35 */       } catch (Exception exception) {}
/*    */     }
/*    */     
/* 38 */     return this.image;
/*    */   }
/*    */   
/*    */   public BgItemTemplate(int id, int imageId, int layer, int dx, int dy) {
/* 42 */     this.id = id;
/* 43 */     this.imageId = imageId;
/* 44 */     this.layer = layer;
/* 45 */     this.dx = dx;
/* 46 */     this.dy = dy;
/*    */   }
/*    */ }


/* Location:              D:\nro\server_luxu_nrp\vemap\GirlkunToolCBRO.jar!\com\girlkun\tool\entities\map\BgItemTemplate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */