/*    */ package com.girlkun.tool.entities.map;
/*    */ 
/*    */ import com.girlkun.tool.screens.part_scr.models.Part;
/*    */ import java.awt.image.BufferedImage;
/*    */ 
/*    */ public class NpcTemplate {
/*    */   private int id;
/*    */   private String name;
/*    */   private int head;
/*    */   private int body;
/*    */   private int leg;
/*    */   private int avatar;
/*    */   private Part pHead;
/*    */   
/* 15 */   public void setId(int id) { this.id = id; } private Part pBody; private Part pLeg; private BufferedImage iHead; private BufferedImage iBody; private BufferedImage iLeg; private boolean eH; private boolean eB; private boolean eL; public void setName(String name) { this.name = name; } public void setHead(int head) { this.head = head; } public void setBody(int body) { this.body = body; } public void setLeg(int leg) { this.leg = leg; } public void setAvatar(int avatar) { this.avatar = avatar; } public void setPHead(Part pHead) { this.pHead = pHead; } public void setPBody(Part pBody) { this.pBody = pBody; } public void setPLeg(Part pLeg) { this.pLeg = pLeg; } public void setIHead(BufferedImage iHead) { this.iHead = iHead; } public void setIBody(BufferedImage iBody) { this.iBody = iBody; } public void setILeg(BufferedImage iLeg) { this.iLeg = iLeg; } public void setEH(boolean eH) { this.eH = eH; } public void setEB(boolean eB) { this.eB = eB; } public void setEL(boolean eL) { this.eL = eL; } public boolean equals(Object o) { if (o == this) return true;  if (!(o instanceof NpcTemplate)) return false;  NpcTemplate other = (NpcTemplate)o; if (!other.canEqual(this)) return false;  if (getId() != other.getId()) return false;  if (getHead() != other.getHead()) return false;  if (getBody() != other.getBody()) return false;  if (getLeg() != other.getLeg()) return false;  if (getAvatar() != other.getAvatar()) return false;  if (isEH() != other.isEH()) return false;  if (isEB() != other.isEB()) return false;  if (isEL() != other.isEL()) return false;  Object this$name = getName(), other$name = other.getName(); if ((this$name == null) ? (other$name != null) : !this$name.equals(other$name)) return false;  Object this$pHead = getPHead(), other$pHead = other.getPHead(); if ((this$pHead == null) ? (other$pHead != null) : !this$pHead.equals(other$pHead)) return false;  Object this$pBody = getPBody(), other$pBody = other.getPBody(); if ((this$pBody == null) ? (other$pBody != null) : !this$pBody.equals(other$pBody)) return false;  Object this$pLeg = getPLeg(), other$pLeg = other.getPLeg(); if ((this$pLeg == null) ? (other$pLeg != null) : !this$pLeg.equals(other$pLeg)) return false;  Object this$iHead = getIHead(), other$iHead = other.getIHead(); if ((this$iHead == null) ? (other$iHead != null) : !this$iHead.equals(other$iHead)) return false;  Object this$iBody = getIBody(), other$iBody = other.getIBody(); if ((this$iBody == null) ? (other$iBody != null) : !this$iBody.equals(other$iBody)) return false;  Object this$iLeg = getILeg(), other$iLeg = other.getILeg(); return !((this$iLeg == null) ? (other$iLeg != null) : !this$iLeg.equals(other$iLeg)); } protected boolean canEqual(Object other) { return other instanceof NpcTemplate; } public int hashCode() { int PRIME = 59; result = 1; result = result * 59 + getId(); result = result * 59 + getHead(); result = result * 59 + getBody(); result = result * 59 + getLeg(); result = result * 59 + getAvatar(); result = result * 59 + (isEH() ? 79 : 97); result = result * 59 + (isEB() ? 79 : 97); result = result * 59 + (isEL() ? 79 : 97); Object $name = getName(); result = result * 59 + (($name == null) ? 43 : $name.hashCode()); Object $pHead = getPHead(); result = result * 59 + (($pHead == null) ? 43 : $pHead.hashCode()); Object $pBody = getPBody(); result = result * 59 + (($pBody == null) ? 43 : $pBody.hashCode()); Object $pLeg = getPLeg(); result = result * 59 + (($pLeg == null) ? 43 : $pLeg.hashCode()); Object $iHead = getIHead(); result = result * 59 + (($iHead == null) ? 43 : $iHead.hashCode()); Object $iBody = getIBody(); result = result * 59 + (($iBody == null) ? 43 : $iBody.hashCode()); Object $iLeg = getILeg(); return result * 59 + (($iLeg == null) ? 43 : $iLeg.hashCode()); } public String toString() { return "NpcTemplate(id=" + getId() + ", name=" + getName() + ", head=" + getHead() + ", body=" + getBody() + ", leg=" + getLeg() + ", avatar=" + getAvatar() + ", pHead=" + getPHead() + ", pBody=" + getPBody() + ", pLeg=" + getPLeg() + ", iHead=" + getIHead() + ", iBody=" + getIBody() + ", iLeg=" + getILeg() + ", eH=" + isEH() + ", eB=" + isEB() + ", eL=" + isEL() + ")"; }
/*    */   
/*    */   public NpcTemplate() {}
/*    */   
/* 19 */   public int getId() { return this.id; }
/* 20 */   public String getName() { return this.name; }
/* 21 */   public int getHead() { return this.head; }
/* 22 */   public int getBody() { return this.body; }
/* 23 */   public int getLeg() { return this.leg; } public int getAvatar() {
/* 24 */     return this.avatar;
/*    */   }
/* 26 */   public Part getPHead() { return this.pHead; }
/* 27 */   public Part getPBody() { return this.pBody; } public Part getPLeg() {
/* 28 */     return this.pLeg;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public NpcTemplate(int id, String name, int head, int body, int leg, int avatar) {
/* 35 */     this.id = id;
/* 36 */     this.name = name;
/* 37 */     this.head = head;
/* 38 */     this.body = body;
/* 39 */     this.leg = leg;
/* 40 */     this.avatar = avatar;
/*    */   }
/*    */   
/* 43 */   public boolean isEH() { return this.eH; } public boolean isEB() { return this.eB; } public boolean isEL() { return this.eL; }
/*    */   
/*    */   public BufferedImage getIHead() {
/* 46 */     if (this.iHead == null && !this.eH) {
/*    */       try {
/* 48 */         this.pHead = Part.getPart(this.head);
/* 49 */         this.iHead = Util.getImageById(this.pHead.getPi()[0].getIconId(), 1);
/* 50 */       } catch (Exception ex) {
/* 51 */         this.eH = true;
/*    */       } 
/*    */     }
/* 54 */     return this.iHead;
/*    */   }
/*    */   public BufferedImage getIBody() {
/* 57 */     if (this.iBody == null && !this.eB) {
/*    */       try {
/* 59 */         this.pBody = Part.getPart(this.body);
/* 60 */         this.iBody = Util.getImageById(this.pBody.getPi()[1].getIconId(), 1);
/* 61 */       } catch (Exception ex) {
/* 62 */         this.eB = true;
/*    */       } 
/*    */     }
/* 65 */     return this.iBody;
/*    */   }
/*    */   public BufferedImage getILeg() {
/* 68 */     if (this.iLeg == null && !this.eL) {
/*    */       try {
/* 70 */         this.pLeg = Part.getPart(this.leg);
/* 71 */         this.iLeg = Util.getImageById(this.pLeg.getPi()[1].getIconId(), 1);
/* 72 */       } catch (Exception ex) {
/* 73 */         this.eL = true;
/*    */       } 
/*    */     }
/* 76 */     return this.iLeg;
/*    */   }
/*    */ }


/* Location:              D:\nro\server_luxu_nrp\vemap\GirlkunToolCBRO.jar!\com\girlkun\tool\entities\map\NpcTemplate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */