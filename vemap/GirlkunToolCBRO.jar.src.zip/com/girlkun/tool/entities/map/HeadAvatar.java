/*    */ package com.girlkun.tool.entities.map;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HeadAvatar
/*    */ {
/*    */   private int head;
/*    */   private int avatar;
/*    */   
/*    */   public void setHead(int head) {
/* 11 */     this.head = head; } public void setAvatar(int avatar) { this.avatar = avatar; } public boolean equals(Object o) { if (o == this) return true;  if (!(o instanceof HeadAvatar)) return false;  HeadAvatar other = (HeadAvatar)o; return !other.canEqual(this) ? false : ((getHead() != other.getHead()) ? false : (!(getAvatar() != other.getAvatar()))); } protected boolean canEqual(Object other) { return other instanceof HeadAvatar; } public int hashCode() { int PRIME = 59; result = 1; result = result * 59 + getHead(); return result * 59 + getAvatar(); } public String toString() { return "HeadAvatar(head=" + getHead() + ", avatar=" + getAvatar() + ")"; } public HeadAvatar(int head, int avatar) {
/* 12 */     this.head = head; this.avatar = avatar;
/*    */   }
/*    */   
/* 15 */   public int getHead() { return this.head; } public int getAvatar() {
/* 16 */     return this.avatar;
/*    */   }
/*    */ }


/* Location:              D:\nro\server_luxu_nrp\vemap\GirlkunToolCBRO.jar!\com\girlkun\tool\entities\map\HeadAvatar.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */