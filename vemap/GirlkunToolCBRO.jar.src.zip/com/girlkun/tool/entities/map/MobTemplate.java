/*    */ package com.girlkun.tool.entities.map;
/*    */ 
/*    */ import com.girlkun.tool.utils.Util;
/*    */ import java.awt.image.BufferedImage;
/*    */ import java.util.Arrays;
/*    */ 
/*    */ public class MobTemplate {
/*    */   private int id;
/*    */   private int type;
/*    */   private String name;
/*    */   
/* 12 */   public void setId(int id) { this.id = id; } private BufferedImage[] images; private int rangeMove; private int speed; public void setType(int type) { this.type = type; } public void setName(String name) { this.name = name; } public void setImages(BufferedImage[] images) { this.images = images; } public void setRangeMove(int rangeMove) { this.rangeMove = rangeMove; } public void setSpeed(int speed) { this.speed = speed; } public boolean equals(Object o) { if (o == this) return true;  if (!(o instanceof MobTemplate)) return false;  MobTemplate other = (MobTemplate)o; if (!other.canEqual(this)) return false;  if (getId() != other.getId()) return false;  if (getType() != other.getType()) return false;  if (getRangeMove() != other.getRangeMove()) return false;  if (getSpeed() != other.getSpeed()) return false;  Object this$name = getName(), other$name = other.getName(); return ((this$name == null) ? (other$name != null) : !this$name.equals(other$name)) ? false : (!!Arrays.deepEquals((Object[])getImages(), (Object[])other.getImages())); } protected boolean canEqual(Object other) { return other instanceof MobTemplate; } public int hashCode() { int PRIME = 59; result = 1; result = result * 59 + getId(); result = result * 59 + getType(); result = result * 59 + getRangeMove(); result = result * 59 + getSpeed(); Object $name = getName(); result = result * 59 + (($name == null) ? 43 : $name.hashCode()); return result * 59 + Arrays.deepHashCode((Object[])getImages()); } public String toString() { return "MobTemplate(id=" + getId() + ", type=" + getType() + ", name=" + getName() + ", images=" + Arrays.deepToString((Object[])getImages()) + ", rangeMove=" + getRangeMove() + ", speed=" + getSpeed() + ")"; }
/*    */ 
/*    */   
/* 15 */   public int getId() { return this.id; }
/* 16 */   public int getType() { return this.type; } public String getName() {
/* 17 */     return this.name;
/*    */   }
/* 19 */   public int getRangeMove() { return this.rangeMove; } public int getSpeed() {
/* 20 */     return this.speed;
/*    */   }
/*    */   public MobTemplate(int id, int type, String name, int rangeMove, int speed) {
/* 23 */     this.id = id;
/* 24 */     this.type = type;
/* 25 */     this.name = name;
/* 26 */     this.rangeMove = rangeMove;
/* 27 */     this.speed = speed;
/*    */   }
/*    */   
/*    */   public BufferedImage[] getImages() {
/* 31 */     if (this.images == null) {
/*    */       try {
/* 33 */         this.images = new BufferedImage[3];
/* 34 */         this.images[0] = Util.getImageMobById(this.id, 1);
/* 35 */         this.images[1] = Util.getImageMobById(this.id, 2);
/* 36 */         this.images[2] = Util.getImageMobById(this.id, 3);
/* 37 */       } catch (Exception exception) {}
/*    */     }
/*    */     
/* 40 */     return this.images;
/*    */   }
/*    */ }


/* Location:              D:\nro\server_luxu_nrp\vemap\GirlkunToolCBRO.jar!\com\girlkun\tool\entities\map\MobTemplate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */